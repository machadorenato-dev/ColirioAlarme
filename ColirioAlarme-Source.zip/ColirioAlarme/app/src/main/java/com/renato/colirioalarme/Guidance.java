package com.renato.colirioalarme;

import java.util.UUID;

public class Guidance {
    public String id;
    public String title;
    public String text;
    public String videoUrl;

    public Guidance(String title, String text) {
        this(UUID.randomUUID().toString(), title, text, "");
    }

    public Guidance(String title, String text, String videoUrl) {
        this(UUID.randomUUID().toString(), title, text, videoUrl);
    }


    public Guidance(String id, String title, String text, String videoUrl) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.videoUrl = videoUrl == null ? "" : videoUrl.trim();
    }
}
