package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Mantém a cópia local dos dados do médico vinculada à conta Firebase autenticada.
 * Evita misturar pacientes/catálogos quando mais de um médico usa o mesmo aparelho.
 */
public final class DoctorDataScope {
    private static final String PREFS = "colirio_doctor_data_scope_v1";
    private static final String KEY_UID = "doctor_uid";

    private DoctorDataScope() {}

    public static void prepareForSignedInDoctor(Context context) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null || user.isAnonymous()) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String previous = prefs.getString(KEY_UID, "");
        String current = user.getUid();

        // Na primeira execução da V15 preserva a cópia local existente para migração segura.
        if (!previous.isEmpty() && !previous.equals(current)) clearLocalDoctorData(context);
        prefs.edit().putString(KEY_UID, current).apply();
    }

    private static void clearLocalDoctorData(Context context) {
        try {
            JSONObject medicine = new JSONObject();
            medicine.put("plans", new JSONArray());
            medicine.put("customMedicines", new JSONArray());
            medicine.put("hiddenMedicines", new JSONArray());
            PlanStore.importDoctorData(context, medicine);
        } catch (Exception ignored) {}
        ProtocolStore.importDoctorData(context, new JSONArray());
        GuidanceStore.importDoctorData(context, new JSONArray());
        GuidanceStore.clearActive(context);
        DoctorRecipeProfileStore.importJson(context, new JSONObject());
        PatientStore.replaceFromCloud(context, new java.util.ArrayList<>());
    }
}
