package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class DoctorRecipeProfileActivity extends Activity {
    private static final int PICK_LOGO = 3101;
    private static final int PICK_SIGNATURE = 3102;

    private EditText name;
    private EditText crm;
    private EditText specialty;
    private EditText clinic;
    private EditText details;
    private TextView logoStatus;
    private TextView signatureStatus;
    private String logoBase64 = "";
    private String signatureBase64 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    private void build() {
        DoctorRecipeProfileStore.Profile current = DoctorRecipeProfileStore.get(this);
        logoBase64 = current.logoBase64;
        signatureBase64 = current.signatureBase64;

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Área do médico");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Dados da receita"));
        page.addView(Ui.subtitle(this, "Cadastre uma vez os dados que aparecerão nas receitas em PDF. Logotipo e assinatura são opcionais."));

        name = field("Nome do médico", current.name);
        crm = field("CRM/UF (ex.: CRM-SP 123456)", current.crm);
        specialty = field("Especialidade", current.specialty);
        clinic = field("Nome do consultório / clínica", current.clinic);
        details = field("Dados do consultório (endereço, telefone, site etc.)", current.details);
        details.setMinLines(3);

        page.addView(name); page.addView(crm); page.addView(specialty); page.addView(clinic); page.addView(details);
        page.addView(Ui.space(this, 10));

        Button logo = Ui.secondaryButton(this, "Selecionar logotipo");
        logo.setOnClickListener(v -> pickImage(PICK_LOGO));
        page.addView(logo);
        logoStatus = Ui.subtitle(this, logoBase64.isEmpty() ? "Nenhum logotipo selecionado." : "Logotipo selecionado.");
        page.addView(logoStatus);

        Button signature = Ui.secondaryButton(this, "Selecionar assinatura");
        signature.setOnClickListener(v -> pickImage(PICK_SIGNATURE));
        page.addView(signature);
        signatureStatus = Ui.subtitle(this, signatureBase64.isEmpty() ? "Nenhuma assinatura selecionada." : "Assinatura selecionada.");
        page.addView(signatureStatus);

        Button save = Ui.primaryButton(this, "Salvar dados da receita");
        save.setOnClickListener(v -> save());
        page.addView(save);
        setContentView(scroll);
    }

    private EditText field(String hint, String value) {
        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setText(value == null ? "" : value);
        edit.setTextSize(16);
        edit.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));
        return edit;
    }

    private void pickImage(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == PICK_LOGO) {
                logoBase64 = ImageDataUtil.readCompressedBase64(this, uri, 900, 420);
                logoStatus.setText("Logotipo selecionado.");
            } else if (requestCode == PICK_SIGNATURE) {
                signatureBase64 = ImageDataUtil.readCompressedBase64(this, uri, 900, 350);
                signatureStatus.setText("Assinatura selecionada.");
            }
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível ler a imagem.", Toast.LENGTH_LONG).show();
        }
    }

    private void save() {
        DoctorRecipeProfileStore.Profile p = new DoctorRecipeProfileStore.Profile(
                name.getText().toString(), crm.getText().toString(), specialty.getText().toString(),
                clinic.getText().toString(), details.getText().toString(), logoBase64, signatureBase64);
        if (p.name.isEmpty() || p.crm.isEmpty()) {
            Toast.makeText(this, "Informe pelo menos o nome do médico e o CRM/UF.", Toast.LENGTH_LONG).show();
            return;
        }
        DoctorRecipeProfileStore.save(this, p);
        FirebaseRepository.syncDoctorRecipeProfile(this, (ok, msg) -> runOnUiThread(() ->
                Toast.makeText(this, ok ? "Dados da receita salvos." : "Dados salvos neste aparelho. A cópia online será tentada depois.", Toast.LENGTH_LONG).show()));
        // Atualiza silenciosamente os protocolos já publicados para que o paciente receba os dados da receita.
        for (Patient patient : PatientStore.getAll(this)) {
            if (patient != null && !patient.assignments.isEmpty() && PatientAccessUtil.hasPassword(patient)) {
                ProgramTransfer.publishPatientState(this, patient, true, null);
            }
        }
    }
}
