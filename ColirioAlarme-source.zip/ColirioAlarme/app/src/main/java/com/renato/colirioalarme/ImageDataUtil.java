package com.renato.colirioalarme;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public final class ImageDataUtil {
    private ImageDataUtil() {}

    /** Lê uma imagem escolhida pelo usuário, reduz a resolução e devolve JPEG Base64 para caber no Firestore. */
    public static String readCompressedBase64(Context context, Uri uri, int maxWidth, int maxHeight) throws Exception {
        if (uri == null) return "";
        Bitmap bitmap;
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            bitmap = BitmapFactory.decodeStream(in);
        }
        if (bitmap == null) throw new Exception("Imagem inválida");
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        float scale = Math.min(1f, Math.min(maxWidth / (float) Math.max(1, w), maxHeight / (float) Math.max(1, h)));
        Bitmap scaled = bitmap;
        if (scale < 1f) scaled = Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)), true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out);
        if (scaled != bitmap) scaled.recycle();
        bitmap.recycle();
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }
}
