package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/** Dados usados no cabeçalho/rodapé das receitas em PDF geradas pelo médico. */
public final class DoctorRecipeProfileStore {
    private static final String PREFS = "colirio_doctor_recipe_profile_v1";
    private static final String K_NAME = "name";
    private static final String K_CRM = "crm";
    private static final String K_SPECIALTY = "specialty";
    private static final String K_CLINIC = "clinic";
    private static final String K_DETAILS = "details";
    private static final String K_LOGO = "logo_b64";
    private static final String K_SIGNATURE = "signature_b64";

    private DoctorRecipeProfileStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void save(Context context, Profile p) {
        if (p == null) return;
        prefs(context).edit()
                .putString(K_NAME, clean(p.name))
                .putString(K_CRM, clean(p.crm))
                .putString(K_SPECIALTY, clean(p.specialty))
                .putString(K_CLINIC, clean(p.clinic))
                .putString(K_DETAILS, p.details == null ? "" : p.details.trim())
                .putString(K_LOGO, p.logoBase64 == null ? "" : p.logoBase64)
                .putString(K_SIGNATURE, p.signatureBase64 == null ? "" : p.signatureBase64)
                .apply();
    }

    public static Profile get(Context context) {
        SharedPreferences p = prefs(context);
        return new Profile(
                p.getString(K_NAME, ""),
                p.getString(K_CRM, ""),
                p.getString(K_SPECIALTY, ""),
                p.getString(K_CLINIC, ""),
                p.getString(K_DETAILS, ""),
                p.getString(K_LOGO, ""),
                p.getString(K_SIGNATURE, "")
        );
    }

    public static JSONObject toJson(Context context) {
        return get(context).toJson();
    }

    public static void importJson(Context context, JSONObject o) {
        if (o == null) return;
        save(context, Profile.fromJson(o));
    }

    public static boolean hasMinimumData(Context context) {
        Profile p = get(context);
        return !p.name.trim().isEmpty() && !p.crm.trim().isEmpty();
    }

    private static String clean(String s) { return s == null ? "" : s.trim(); }

    public static final class Profile {
        public String name;
        public String crm;
        public String specialty;
        public String clinic;
        public String details;
        public String logoBase64;
        public String signatureBase64;

        public Profile(String name, String crm, String specialty, String clinic, String details,
                       String logoBase64, String signatureBase64) {
            this.name = clean(name);
            this.crm = clean(crm);
            this.specialty = clean(specialty);
            this.clinic = clean(clinic);
            this.details = details == null ? "" : details.trim();
            this.logoBase64 = logoBase64 == null ? "" : logoBase64;
            this.signatureBase64 = signatureBase64 == null ? "" : signatureBase64;
        }

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("name", name);
                o.put("crm", crm);
                o.put("specialty", specialty);
                o.put("clinic", clinic);
                o.put("details", details);
                o.put("logoBase64", logoBase64);
                o.put("signatureBase64", signatureBase64);
            } catch (Exception ignored) {}
            return o;
        }

        public static Profile fromJson(JSONObject o) {
            if (o == null) return new Profile("", "", "", "", "", "", "");
            return new Profile(o.optString("name", ""), o.optString("crm", ""),
                    o.optString("specialty", ""), o.optString("clinic", ""),
                    o.optString("details", ""), o.optString("logoBase64", ""),
                    o.optString("signatureBase64", ""));
        }
    }
}
