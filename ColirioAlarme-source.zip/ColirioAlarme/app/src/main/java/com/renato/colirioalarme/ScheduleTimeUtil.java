package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

/** Utilitários para distribuir tomadas de forma uniforme ao longo de 24 horas. */
public final class ScheduleTimeUtil {
    private ScheduleTimeUtil() {}

    public static ArrayList<String> generateTimes(int frequency, int startHour, int startMinute) {
        ArrayList<String> result = new ArrayList<>();
        int f = Math.max(1, Math.min(24, frequency));
        int start = ((Math.max(0, Math.min(23, startHour)) * 60)
                + Math.max(0, Math.min(59, startMinute))) % 1440;
        for (int i = 0; i < f; i++) {
            int offset = Math.round(i * (1440f / f));
            int total = (start + offset) % 1440;
            String value = String.format(Locale.getDefault(), "%02d:%02d", total / 60, total % 60);
            if (!result.contains(value)) result.add(value);
        }
        Collections.sort(result);
        return result;
    }
}
