package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PatientAssignment {
    public String id;
    public String protocolId;
    public String protocolName;
    public String eye;
    public long assignedAt;
    public ArrayList<ProtocolMedication> medications;
    public String guidanceTitle;
    public String guidanceText;

    public PatientAssignment(String protocolId, String protocolName, String eye,
                             List<ProtocolMedication> medications,
                             String guidanceTitle, String guidanceText) {
        this(UUID.randomUUID().toString(), protocolId, protocolName, eye,
                System.currentTimeMillis(), medications, guidanceTitle, guidanceText);
    }

    public PatientAssignment(String id, String protocolId, String protocolName, String eye,
                             long assignedAt, List<ProtocolMedication> medications,
                             String guidanceTitle, String guidanceText) {
        this.id = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
        this.protocolId = protocolId == null ? "" : protocolId;
        this.protocolName = protocolName == null ? "" : protocolName;
        this.eye = eye == null ? "Ambos os olhos" : eye;
        this.assignedAt = assignedAt > 0 ? assignedAt : System.currentTimeMillis();
        this.medications = new ArrayList<>();
        if (medications != null) {
            for (ProtocolMedication med : medications) {
                this.medications.add(new ProtocolMedication(med.medicine, med.phases,
                        med.startDelayDays, med.startsAfterMedicine));
            }
        }
        this.guidanceTitle = guidanceTitle == null ? "" : guidanceTitle;
        this.guidanceText = guidanceText == null ? "" : guidanceText;
    }
}
