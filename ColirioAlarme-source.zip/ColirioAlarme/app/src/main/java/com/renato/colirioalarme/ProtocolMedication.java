package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;

public class ProtocolMedication {
    public String medicine;
    public ArrayList<String> times;
    public ArrayList<TreatmentPhase> phases;
    public int startDelayDays;
    public String startsAfterMedicine;

    public ProtocolMedication(String medicine, List<String> times) {
        this.medicine = medicine;
        this.phases = new ArrayList<>();
        this.phases.add(new TreatmentPhase(7, times));
        this.startDelayDays = 0;
        this.startsAfterMedicine = "";
        syncLegacyTimes();
    }

    public ProtocolMedication(String medicine, List<TreatmentPhase> phases,
                              int startDelayDays, String startsAfterMedicine) {
        this.medicine = medicine;
        this.phases = new ArrayList<>();
        if (phases != null) for (TreatmentPhase phase : phases) this.phases.add(phase.copy());
        if (this.phases.isEmpty()) this.phases.add(new TreatmentPhase(7, new ArrayList<>()));
        this.startDelayDays = Math.max(0, startDelayDays);
        this.startsAfterMedicine = startsAfterMedicine == null ? "" : startsAfterMedicine;
        syncLegacyTimes();
    }

    public void syncLegacyTimes() {
        times = new ArrayList<>();
        if (!phases.isEmpty()) times.addAll(phases.get(0).times);
    }
}
