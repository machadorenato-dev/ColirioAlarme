package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;

public class ProtocolMedication {
    public String medicine;
    public ArrayList<String> times;

    public ProtocolMedication(String medicine, List<String> times) {
        this.medicine = medicine;
        this.times = new ArrayList<>(times);
    }
}
