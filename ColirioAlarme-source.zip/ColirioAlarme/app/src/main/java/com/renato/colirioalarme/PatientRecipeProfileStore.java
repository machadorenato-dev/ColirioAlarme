package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

/** Cópia local, no aparelho do paciente, dos dados profissionais enviados pelo médico. */
public final class PatientRecipeProfileStore {
    private static final String PREFS = "colirio_patient_recipe_profile_v1";
    private static final String KEY_JSON = "profile_json";

    private PatientRecipeProfileStore() {}

    public static void save(Context context, JSONObject profile) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_JSON, profile == null ? "" : profile.toString()).apply();
    }

    public static DoctorRecipeProfileStore.Profile get(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, "");
        if (raw == null || raw.trim().isEmpty()) {
            return new DoctorRecipeProfileStore.Profile("", "", "", "", "", "", "");
        }
        try { return DoctorRecipeProfileStore.Profile.fromJson(new JSONObject(raw)); }
        catch (Exception ignored) { return new DoctorRecipeProfileStore.Profile("", "", "", "", "", "", ""); }
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
