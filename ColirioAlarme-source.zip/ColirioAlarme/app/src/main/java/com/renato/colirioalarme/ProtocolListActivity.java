package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.List;

public class ProtocolListActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (list != null) render();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Protocolos"));

        Button create = Ui.primaryButton(this, "+ Novo protocolo");
        create.setOnClickListener(v -> createProtocol());
        page.addView(create);
        page.addView(Ui.space(this, 12));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        render();
        setContentView(scroll);
    }

    private void createProtocol() {
        EditText input = new EditText(this);
        input.setHint("Ex.: FACO");
        new AlertDialog.Builder(this)
                .setTitle("Nome do protocolo")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Criar", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) return;
                    SurgeryProtocol p = new SurgeryProtocol(name);
                    ProtocolStore.save(this, p);
                    openEdit(p.id);
                }).show();
    }

    private void render() {
        list.removeAllViews();
        List<SurgeryProtocol> all = ProtocolStore.getAll(this);
        if (all.isEmpty()) {
            list.addView(Ui.subtitle(this, "Nenhum protocolo cadastrado."));
            return;
        }
        for (SurgeryProtocol p : all) {
            Button protocol = Ui.primaryButton(this, p.name);
            protocol.setOnClickListener(v -> openProtocol(p.id));
            list.addView(protocol);
            list.addView(Ui.space(this, 8));
        }
    }

    private void openProtocol(String id) {
        Intent intent = new Intent(this, ProtocolViewActivity.class);
        intent.putExtra("protocolId", id);
        startActivity(intent);
    }

    private void openEdit(String id) {
        Intent intent = new Intent(this, ProtocolEditActivity.class);
        intent.putExtra("protocolId", id);
        startActivity(intent);
    }
}
