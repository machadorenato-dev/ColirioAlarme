package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ProtocolListActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (list != null) render();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Protocolos"));
        page.addView(Ui.subtitle(this, "Salve protocolos completos com colírios, duração, desmame, início programado e orientações pós-operatórias."));

        Button create = Ui.primaryButton(this, "+ Novo protocolo");
        create.setOnClickListener(v -> createProtocol());
        page.addView(create);
        page.addView(Ui.space(this, 12));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        render();
        setContentView(scroll);
    }

    private void createProtocol() {
        EditText input = new EditText(this);
        input.setHint("Ex.: FACO");
        new AlertDialog.Builder(this)
                .setTitle("Nome do protocolo")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Criar", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) return;
                    SurgeryProtocol p = new SurgeryProtocol(name);
                    ProtocolStore.save(this, p);
                    openEdit(p.id);
                }).show();
    }

    private void render() {
        list.removeAllViews();
        List<SurgeryProtocol> all = ProtocolStore.getAll(this);
        if (all.isEmpty()) {
            list.addView(Ui.subtitle(this, "Nenhum protocolo cadastrado."));
            return;
        }
        for (SurgeryProtocol p : all) {
            LinearLayout card = Ui.card(this);
            TextView name = new TextView(this);
            name.setText(p.name);
            name.setTextSize(21);
            name.setTypeface(null, android.graphics.Typeface.BOLD);
            name.setTextColor(Ui.TEXT);
            card.addView(name);

            TextView details = new TextView(this);
            details.setText(protocolSummary(p));
            details.setTextSize(15);
            details.setTextColor(Ui.MUTED);
            details.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 8));
            card.addView(details);

            Button use = Ui.primaryButton(this, "Usar protocolo");
            use.setOnClickListener(v -> chooseEye(p));
            card.addView(use);
            card.addView(Ui.space(this, 6));

            Button edit = Ui.secondaryButton(this, "Editar protocolo");
            edit.setOnClickListener(v -> openEdit(p.id));
            card.addView(edit);
            list.addView(card);
        }
    }

    private String protocolSummary(SurgeryProtocol p) {
        if (p.medications.isEmpty()) return "Nenhum colírio cadastrado";
        ArrayList<String> names = new ArrayList<>();
        for (ProtocolMedication m : p.medications) names.add(m.medicine);
        String result = String.join(" • ", names);
        Guidance g = GuidanceStore.getById(this, p.guidanceId);
        if (g != null) result += "\nOrientação: " + g.title;
        return result;
    }

    private void openEdit(String id) {
        Intent intent = new Intent(this, ProtocolEditActivity.class);
        intent.putExtra("protocolId", id);
        startActivity(intent);
    }

    private void chooseEye(SurgeryProtocol p) {
        if (p.medications.isEmpty()) {
            Toast.makeText(this, "Cadastre colírios neste protocolo primeiro.", Toast.LENGTH_LONG).show();
            return;
        }
        for (ProtocolMedication med : p.medications) {
            if (med.phases == null || med.phases.isEmpty()) {
                Toast.makeText(this, "Cadastre o esquema de " + med.medicine + " antes de usar o protocolo.", Toast.LENGTH_LONG).show();
                return;
            }
            for (TreatmentPhase phase : med.phases) {
                if (phase.times.isEmpty()) {
                    Toast.makeText(this, "Cadastre os horários de " + med.medicine + " antes de usar o protocolo.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
        String[] eyes = {"Olho direito", "Olho esquerdo", "Ambos os olhos"};
        new AlertDialog.Builder(this)
                .setTitle(p.name + " — qual olho?")
                .setItems(eyes, (d, which) -> applyProtocol(p, eyes[which]))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void applyProtocol(SurgeryProtocol p, String eye) {
        int count = 0;
        ArrayList<MedicationPlan> applied = new ArrayList<>();
        long anchor = System.currentTimeMillis();
        // Salva todos primeiro para que regras como "iniciar após Vigadexa" possam ser resolvidas.
        for (ProtocolMedication med : p.medications) {
            MedicationPlan old = PlanStore.getPlanForMedicine(this, med.medicine);
            if (old != null) AlarmScheduler.cancelPlan(this, old);
            MedicationPlan plan = old == null
                    ? new MedicationPlan(med.medicine, eye, med.phases, med.startDelayDays, med.startsAfterMedicine, anchor)
                    : new MedicationPlan(old.id, med.medicine, eye, med.phases, med.startDelayDays, med.startsAfterMedicine, anchor);
            PlanStore.savePlan(this, plan);
            applied.add(plan);
            count++;
        }
        for (MedicationPlan plan : applied) AlarmScheduler.schedulePlan(this, plan);

        Guidance g = GuidanceStore.getById(this, p.guidanceId);
        if (g != null) GuidanceStore.setActive(this, g.id);
        else GuidanceStore.clearActive(this);

        Toast.makeText(this, p.name + " aplicado: " + count + " colírio(s) + orientações.", Toast.LENGTH_LONG).show();
        Intent home = new Intent(this, PatientHomeActivity.class);
        home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(home);
        finish();
    }
}
