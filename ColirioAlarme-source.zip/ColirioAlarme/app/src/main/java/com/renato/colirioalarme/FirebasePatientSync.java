package com.renato.colirioalarme;

import android.content.Context;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Sincronização do aparelho do paciente. O paciente usa autenticação anônima e um token recebido no protocolo. */
public final class FirebasePatientSync {
    private FirebasePatientSync() {}

    public static void activateLink(Context context, String token, FirebaseRepository.ResultCallback callback) {
        if (token == null || token.trim().isEmpty()) {
            if (callback != null) callback.onResult(false, "Protocolo sem vínculo Firebase.");
            return;
        }
        PatientProfileStore.saveLinkToken(context, token);
        ensureSignedIn(context, () -> FirebaseFirestore.getInstance().collection("patientLinks").document(token).get()
                .addOnSuccessListener(doc -> {
                    if (!doc.exists() || !Boolean.TRUE.equals(doc.getBoolean("active"))) {
                        if (callback != null) callback.onResult(false, "Vínculo não encontrado ou desativado.");
                        return;
                    }
                    String patientId = doc.getString("patientId");
                    if (patientId != null && !patientId.equals(PatientProfileStore.getId(context))) {
                        if (callback != null) callback.onResult(false, "Este vínculo pertence a outro paciente.");
                        return;
                    }
                    uploadCurrentPlans(context);
                    if (callback != null) callback.onResult(true, "Aparelho vinculado ao médico.");
                }).addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); }));
    }

    public static void uploadDoseEntry(Context context, JSONObject entry) {
        String token = PatientProfileStore.getLinkToken(context);
        if (token.isEmpty() || entry == null) return;
        ensureSignedIn(context, () -> {
            try {
                Map<String, Object> data = new HashMap<>();
                data.put("timestamp", entry.optLong("timestamp", System.currentTimeMillis()));
                data.put("patientId", entry.optString("patientId", PatientProfileStore.getId(context)));
                data.put("medicine", entry.optString("medicine", ""));
                data.put("eye", entry.optString("eye", ""));
                data.put("time", entry.optString("time", ""));
                data.put("status", entry.optString("status", ""));
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                data.put("patientUid", user == null ? "" : user.getUid());
                data.put("uploadedAt", FieldValue.serverTimestamp());
                FirebaseFirestore.getInstance().collection("patientLinks").document(token).collection("doseLog")
                        .document(UUID.randomUUID().toString()).set(data);
            } catch (Exception ignored) {}
        });
    }

    public static void uploadCurrentPlans(Context context) {
        String token = PatientProfileStore.getLinkToken(context);
        if (token.isEmpty()) return;
        ensureSignedIn(context, () -> {
            try {
                JSONArray plans = ProgramTransfer.plansFromCurrentDeviceForSync(context);
                Map<String, Object> data = new HashMap<>();
                data.put("patientId", PatientProfileStore.getId(context));
                data.put("plansJson", plans.toString());
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                data.put("patientUid", user == null ? "" : user.getUid());
                data.put("updatedAt", FieldValue.serverTimestamp());
                FirebaseFirestore.getInstance().collection("patientLinks").document(token).collection("status")
                        .document("current").set(data, SetOptions.merge());
            } catch (Exception ignored) {}
        });
    }

    private static void uploadExistingLogs(Context context) {
        for (JSONObject entry : DoseLog.getEntries(context, PatientProfileStore.getId(context))) uploadDoseEntry(context, entry);
    }

    private static void ensureSignedIn(Context context, Runnable after) {
        FirebaseUser current = FirebaseAuth.getInstance().getCurrentUser();
        if (current != null) { after.run(); return; }
        FirebaseAuth.getInstance().signInAnonymously().addOnSuccessListener(result -> after.run());
    }
}
