package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class PlanStore {
    private static final String PREFS = "colirio_programacao_v2";
    private static final String KEY_PLANS = "plans";
    private static final String KEY_CUSTOM = "custom_medicines";
    private static final String KEY_HIDDEN = "hidden_medicines";

    private static final String[] DEFAULT_MEDICINES = {
            "Alphagan P", "Atropina", "Azopt", "Brimonidina", "Combigan", "Cosopt",
            "Dorzolamida", "Drenatan", "Ecofilm", "Evotears", "Hyabak", "Lacrifilm",
            "Lumigan", "Nevanac", "Oftpred", "Patanol S", "Pred Fort", "Sensilacri",
            "Simbrinza", "Systane Complete", "Systane UL", "Travatan", "Tropicamida",
            "Vigamox", "Vizz", "Xalatan", "Zymar"
    };

    private PlanStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<MedicationPlan> getPlans(Context context) {
        ArrayList<MedicationPlan> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_PLANS, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                JSONArray timesJson = obj.optJSONArray("times");
                ArrayList<String> times = new ArrayList<>();
                if (timesJson != null) {
                    for (int j = 0; j < timesJson.length(); j++) {
                        String time = timesJson.optString(j, "");
                        if (!time.isEmpty()) times.add(time);
                    }
                }
                String id = obj.optString("id", "");
                String medicine = obj.optString("medicine", "").trim();
                String eye = obj.optString("eye", "Ambos os olhos");
                if (!id.isEmpty() && !medicine.isEmpty()) {
                    result.add(new MedicationPlan(id, medicine, eye, times));
                }
            }
        } catch (Exception ignored) {
        }
        sortPlans(result);
        return result;
    }

    public static MedicationPlan getPlanById(Context context, String id) {
        if (id == null) return null;
        for (MedicationPlan plan : getPlans(context)) {
            if (id.equals(plan.id)) return plan;
        }
        return null;
    }

    public static MedicationPlan getPlanForMedicine(Context context, String medicine) {
        if (medicine == null) return null;
        for (MedicationPlan plan : getPlans(context)) {
            if (medicine.equalsIgnoreCase(plan.medicine)) return plan;
        }
        return null;
    }

    public static void savePlan(Context context, MedicationPlan plan) {
        List<MedicationPlan> plans = getPlans(context);
        boolean replaced = false;
        for (int i = 0; i < plans.size(); i++) {
            MedicationPlan old = plans.get(i);
            if (old.id.equals(plan.id) || old.medicine.equalsIgnoreCase(plan.medicine)) {
                plans.set(i, plan);
                replaced = true;
                break;
            }
        }
        if (!replaced) plans.add(plan);
        saveAll(context, plans);
    }

    public static void deletePlan(Context context, String id) {
        List<MedicationPlan> plans = getPlans(context);
        for (int i = plans.size() - 1; i >= 0; i--) {
            if (plans.get(i).id.equals(id)) plans.remove(i);
        }
        saveAll(context, plans);
    }

    private static void saveAll(Context context, List<MedicationPlan> plans) {
        JSONArray array = new JSONArray();
        try {
            for (MedicationPlan plan : plans) {
                JSONObject obj = new JSONObject();
                obj.put("id", plan.id);
                obj.put("medicine", plan.medicine);
                obj.put("eye", plan.eye);
                JSONArray times = new JSONArray();
                for (String time : plan.times) times.put(time);
                obj.put("times", times);
                array.put(obj);
            }
        } catch (Exception ignored) {
        }
        prefs(context).edit().putString(KEY_PLANS, array.toString()).apply();
    }

    public static List<String> getMedicines(Context context) {
        Set<String> names = new HashSet<>();
        Collections.addAll(names, DEFAULT_MEDICINES);
        for (String custom : getCustomMedicines(context)) names.add(custom);
        for (MedicationPlan plan : getPlans(context)) names.add(plan.medicine);

        List<String> hidden = getHiddenMedicines(context);
        ArrayList<String> list = new ArrayList<>();
        for (String name : names) {
            boolean isHidden = false;
            for (String h : hidden) {
                if (h.equalsIgnoreCase(name)) {
                    isHidden = true;
                    break;
                }
            }
            if (!isHidden) list.add(name);
        }
        final Collator collator = Collator.getInstance(new Locale("pt", "BR"));
        collator.setStrength(Collator.PRIMARY);
        list.sort(collator::compare);
        return list;
    }

    public static boolean addCustomMedicine(Context context, String medicine) {
        String value = medicine == null ? "" : medicine.trim();
        if (value.isEmpty()) return false;

        ArrayList<String> hidden = new ArrayList<>(getHiddenMedicines(context));
        boolean restored = hidden.removeIf(item -> item.equalsIgnoreCase(value));
        if (restored) {
            saveHiddenMedicines(context, hidden);
            return true;
        }

        List<String> current = getMedicines(context);
        for (String item : current) {
            if (item.equalsIgnoreCase(value)) return false;
        }
        ArrayList<String> custom = new ArrayList<>(getCustomMedicines(context));
        custom.add(value);
        saveCustomMedicines(context, custom);
        return true;
    }

    public static boolean isCustomMedicine(Context context, String medicine) {
        for (String item : getCustomMedicines(context)) {
            if (item.equalsIgnoreCase(medicine)) return true;
        }
        return false;
    }

    public static void renameCustomMedicine(Context context, String oldName, String newName) {
        String clean = newName == null ? "" : newName.trim();
        if (clean.isEmpty()) return;
        ArrayList<String> custom = new ArrayList<>(getCustomMedicines(context));
        for (int i = 0; i < custom.size(); i++) {
            if (custom.get(i).equalsIgnoreCase(oldName)) custom.set(i, clean);
        }
        saveCustomMedicines(context, custom);

        MedicationPlan plan = getPlanForMedicine(context, oldName);
        if (plan != null) {
            plan.medicine = clean;
            savePlan(context, plan);
        }
    }


    public static void hideMedicine(Context context, String medicine) {
        if (medicine == null || medicine.trim().isEmpty()) return;
        String value = medicine.trim();

        ArrayList<String> custom = new ArrayList<>(getCustomMedicines(context));
        custom.removeIf(item -> item.equalsIgnoreCase(value));
        saveCustomMedicines(context, custom);

        ArrayList<String> hidden = new ArrayList<>(getHiddenMedicines(context));
        boolean exists = false;
        for (String item : hidden) if (item.equalsIgnoreCase(value)) exists = true;
        if (!exists) hidden.add(value);
        saveHiddenMedicines(context, hidden);
    }

    public static List<String> getHiddenMedicines(Context context) {
        ArrayList<String> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_HIDDEN, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty()) result.add(value);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private static void saveHiddenMedicines(Context context, List<String> medicines) {
        JSONArray array = new JSONArray();
        for (String medicine : medicines) array.put(medicine);
        prefs(context).edit().putString(KEY_HIDDEN, array.toString()).apply();
    }

    private static List<String> getCustomMedicines(Context context) {
        ArrayList<String> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_CUSTOM, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty()) result.add(value);
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    private static void saveCustomMedicines(Context context, List<String> medicines) {
        JSONArray array = new JSONArray();
        for (String medicine : medicines) array.put(medicine);
        prefs(context).edit().putString(KEY_CUSTOM, array.toString()).apply();
    }

    private static void sortPlans(List<MedicationPlan> plans) {
        final Collator collator = Collator.getInstance(new Locale("pt", "BR"));
        collator.setStrength(Collator.PRIMARY);
        plans.sort((a, b) -> collator.compare(a.medicine, b.medicine));
    }
}
