package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class GuidanceViewActivity extends Activity {
    private String guidanceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        guidanceId = getIntent().getStringExtra("guidanceId");
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        Guidance guidance = GuidanceStore.getById(this, guidanceId);
        if (guidance == null) { finish(); return; }

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Orientações");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, guidance.title));

        LinearLayout card = Ui.card(this);
        TextView text = new TextView(this);
        text.setText(guidance.text == null || guidance.text.trim().isEmpty()
                ? "Nenhum texto cadastrado." : guidance.text);
        text.setTextSize(17);
        text.setTextColor(Ui.TEXT);
        card.addView(text);
        page.addView(card);

        page.addView(Ui.space(this, 16));
        Button edit = Ui.primaryButton(this, "Editar");
        edit.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuidanceEditActivity.class);
            intent.putExtra("guidanceId", guidance.id);
            startActivity(intent);
        });
        page.addView(edit);
        setContentView(scroll);
    }
}
