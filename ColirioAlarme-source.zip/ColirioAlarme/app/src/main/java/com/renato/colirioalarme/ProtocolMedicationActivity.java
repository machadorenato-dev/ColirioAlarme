package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Locale;

public class ProtocolMedicationActivity extends Activity {
    private SurgeryProtocol protocol;
    private ProtocolMedication medication;
    private LinearLayout phaseList;
    private TextView startLabel;
    private final ArrayList<TreatmentPhase> phases = new ArrayList<>();
    private int startDelayDays;
    private String startsAfterMedicine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        protocol = ProtocolStore.getById(this, getIntent().getStringExtra("protocolId"));
        String medicineName = getIntent().getStringExtra("medicine");
        if (protocol != null && medicineName != null) {
            for (ProtocolMedication med : protocol.medications) if (med.medicine.equalsIgnoreCase(medicineName)) medication = med;
        }
        if (protocol == null || medication == null) { finish(); return; }
        for (TreatmentPhase p : medication.phases) phases.add(p.copy());
        startDelayDays = medication.startDelayDays;
        startsAfterMedicine = medication.startsAfterMedicine == null ? "" : medication.startsAfterMedicine;
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, medication.medicine));
        page.addView(Ui.subtitle(this, "Defina duração, horários, desmame e quando este colírio começa dentro do protocolo " + protocol.name + "."));

        page.addView(Ui.sectionTitle(this, "Início dentro do protocolo"));
        LinearLayout startCard = Ui.card(this);
        startLabel = new TextView(this);
        startLabel.setTextSize(17);
        startLabel.setTextColor(Ui.TEXT);
        startCard.addView(startLabel);
        startCard.addView(Ui.space(this, 6));
        Button editStart = Ui.secondaryButton(this, "Alterar início");
        editStart.setOnClickListener(v -> chooseStartRule());
        startCard.addView(editStart);
        page.addView(startCard);
        renderStart();

        page.addView(Ui.sectionTitle(this, "Esquema / desmame"));
        phaseList = new LinearLayout(this);
        phaseList.setOrientation(LinearLayout.VERTICAL);
        page.addView(phaseList);
        renderPhases();

        Button addPhase = Ui.primaryButton(this, "+ Adicionar etapa do desmame");
        addPhase.setOnClickListener(v -> addPhase());
        page.addView(addPhase);
        page.addView(Ui.space(this, 12));

        Button save = Ui.primaryButton(this, "Salvar no protocolo");
        save.setOnClickListener(v -> saveAndFinish());
        page.addView(save);
        setContentView(scroll);
    }

    private void renderStart() {
        if (startsAfterMedicine != null && !startsAfterMedicine.isEmpty()) startLabel.setText("Iniciar após o término de " + startsAfterMedicine);
        else if (startDelayDays > 0) startLabel.setText("Iniciar após " + startDelayDays + (startDelayDays == 1 ? " dia" : " dias"));
        else startLabel.setText("Início imediato junto ao protocolo");
    }

    private void chooseStartRule() {
        String[] options = {"Início imediato", "Iniciar após X dias", "Iniciar após outro colírio do protocolo"};
        new AlertDialog.Builder(this).setTitle("Quando iniciar?")
                .setItems(options, (d, which) -> {
                    if (which == 0) { startDelayDays = 0; startsAfterMedicine = ""; renderStart(); }
                    else if (which == 1) askDelayDays();
                    else chooseDependency();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void askDelayDays() {
        EditText input = numberInput(String.valueOf(Math.max(1, startDelayDays)));
        new AlertDialog.Builder(this).setTitle("Aguardar quantos dias?").setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    startDelayDays = Math.max(0, parseInt(input.getText().toString(), 0));
                    startsAfterMedicine = "";
                    renderStart();
                }).show();
    }

    private void chooseDependency() {
        ArrayList<String> names = new ArrayList<>();
        for (ProtocolMedication med : protocol.medications) if (!med.medicine.equalsIgnoreCase(medication.medicine)) names.add(med.medicine);
        if (names.isEmpty()) {
            Toast.makeText(this, "Adicione primeiro o outro colírio ao protocolo.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] items = names.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Iniciar após qual colírio?")
                .setItems(items, (d, which) -> {
                    startsAfterMedicine = items[which]; startDelayDays = 0; renderStart();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void renderPhases() {
        phaseList.removeAllViews();
        for (int i = 0; i < phases.size(); i++) {
            TreatmentPhase phase = phases.get(i);
            Collections.sort(phase.times);
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(phases.size() == 1 ? "Tratamento" : "Etapa " + (i + 1));
            title.setTextSize(19);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            card.addView(title);
            TextView duration = new TextView(this);
            duration.setText(phase.days <= 0 ? "Duração: uso contínuo" : "Duração: " + phase.days + (phase.days == 1 ? " dia" : " dias"));
            duration.setTextColor(Ui.MUTED);
            duration.setTextSize(16);
            duration.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 6));
            card.addView(duration);

            if (phase.times.isEmpty()) card.addView(Ui.subtitle(this, "Nenhum horário cadastrado."));
            for (String current : new ArrayList<>(phase.times)) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView time = new TextView(this);
                time.setText(current);
                time.setTextSize(20);
                time.setTypeface(null, android.graphics.Typeface.BOLD);
                row.addView(time, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                Button edit = Ui.smallButton(this, "Editar");
                edit.setOnClickListener(v -> chooseTime(phase, current));
                row.addView(edit);
                Button remove = Ui.smallButton(this, "Excluir");
                remove.setTextColor(Ui.DANGER);
                remove.setOnClickListener(v -> { phase.times.remove(current); renderPhases(); });
                row.addView(remove);
                card.addView(row);
                card.addView(Ui.divider(this));
            }
            Button addTime = Ui.secondaryButton(this, "+ Adicionar horário");
            addTime.setOnClickListener(v -> chooseTime(phase, null));
            card.addView(addTime);
            card.addView(Ui.space(this, 6));
            Button days = Ui.secondaryButton(this, "Alterar duração");
            days.setOnClickListener(v -> editDuration(phase));
            card.addView(days);
            if (phases.size() > 1) {
                card.addView(Ui.space(this, 6));
                Button del = Ui.dangerButton(this, "Excluir esta etapa");
                del.setOnClickListener(v -> { phases.remove(phase); renderPhases(); });
                card.addView(del);
            }
            phaseList.addView(card);
        }
    }

    private void chooseTime(TreatmentPhase phase, String existing) {
        Calendar now = Calendar.getInstance();
        int h = now.get(Calendar.HOUR_OF_DAY), m = now.get(Calendar.MINUTE);
        if (existing != null) {
            try { String[] p = existing.split(":"); h = Integer.parseInt(p[0]); m = Integer.parseInt(p[1]); } catch (Exception ignored) {}
        }
        new TimePickerDialog(this, (v, hour, minute) -> {
            String value = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);
            if (existing != null) phase.times.remove(existing);
            if (!phase.times.contains(value)) phase.times.add(value);
            renderPhases();
        }, h, m, true).show();
    }

    private void editDuration(TreatmentPhase phase) {
        EditText input = numberInput(phase.days <= 0 ? "0" : String.valueOf(phase.days));
        new AlertDialog.Builder(this).setTitle("Duração em dias")
                .setMessage("Digite 0 somente para uso contínuo.")
                .setView(input).setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> { phase.days = Math.max(0, parseInt(input.getText().toString(), 7)); renderPhases(); }).show();
    }

    private void addPhase() {
        for (TreatmentPhase p : phases) {
            if (p.days <= 0) {
                Toast.makeText(this, "Defina em dias a duração da etapa atual antes de criar o desmame.", Toast.LENGTH_LONG).show();
                return;
            }
        }
        String[] freq = {"1x/dia", "2x/dia", "3x/dia", "4x/dia", "5x/dia", "6x/dia"};
        new AlertDialog.Builder(this).setTitle("Nova etapa — frequência")
                .setItems(freq, (d, which) -> askPhaseDays(which + 1))
                .setNegativeButton("Cancelar", null).show();
    }

    private void askPhaseDays(int frequency) {
        EditText input = numberInput("7");
        new AlertDialog.Builder(this).setTitle(frequency + "x/dia por quantos dias?")
                .setView(input).setNegativeButton("Cancelar", null)
                .setPositiveButton("Adicionar", (d, w) -> {
                    phases.add(new TreatmentPhase(Math.max(1, parseInt(input.getText().toString(), 7)), TreatmentText.defaultTimes(frequency)));
                    renderPhases();
                    Toast.makeText(this, "Etapa adicionada. Confira os horários sugeridos.", Toast.LENGTH_LONG).show();
                }).show();
    }

    private boolean validate() {
        if (phases.isEmpty()) return false;
        for (int i = 0; i < phases.size(); i++) {
            if (phases.get(i).times.isEmpty()) {
                Toast.makeText(this, "Cadastre horário(s) na etapa " + (i + 1) + ".", Toast.LENGTH_LONG).show();
                return false;
            }
            if (phases.get(i).days <= 0 && i < phases.size() - 1) {
                Toast.makeText(this, "Somente a última etapa pode ser contínua.", Toast.LENGTH_LONG).show();
                return false;
            }
        }
        return true;
    }

    private void saveAndFinish() {
        if (!validate()) return;
        medication.phases.clear();
        for (TreatmentPhase p : phases) medication.phases.add(p.copy());
        medication.startDelayDays = startDelayDays;
        medication.startsAfterMedicine = startsAfterMedicine == null ? "" : startsAfterMedicine;
        medication.syncLegacyTimes();
        ProtocolStore.save(this, protocol);
        Toast.makeText(this, "Esquema salvo no protocolo.", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override public void onBackPressed() { finish(); }

    private EditText numberInput(String value) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(value);
        input.setSelectAllOnFocus(true);
        input.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        return input;
    }
    private int parseInt(String value, int fallback) { try { return Integer.parseInt(value.trim()); } catch (Exception e) { return fallback; } }
}
