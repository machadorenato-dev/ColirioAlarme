package com.renato.colirioalarme;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Locale;

public class ProtocolMedicationActivity extends Activity {
    private SurgeryProtocol protocol;
    private ProtocolMedication medication;
    private LinearLayout list;
    private final ArrayList<String> times = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        protocol = ProtocolStore.getById(this, getIntent().getStringExtra("protocolId"));
        String medicineName = getIntent().getStringExtra("medicine");
        if (protocol != null && medicineName != null) {
            for (ProtocolMedication med : protocol.medications) {
                if (med.medicine.equalsIgnoreCase(medicineName)) medication = med;
            }
        }
        if (protocol == null || medication == null) {
            finish();
            return;
        }
        times.addAll(medication.times);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> saveAndFinish());
        page.addView(back);
        page.addView(Ui.title(this, medication.medicine));
        page.addView(Ui.subtitle(this, "Horários salvos no protocolo " + protocol.name + "."));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        renderTimes();

        Button add = Ui.primaryButton(this, "+ Adicionar horário");
        add.setOnClickListener(v -> chooseTime(-1));
        page.addView(add);
        page.addView(Ui.space(this, 10));

        Button save = Ui.primaryButton(this, "Salvar horários");
        save.setOnClickListener(v -> saveAndFinish());
        page.addView(save);
        setContentView(scroll);
    }

    private void renderTimes() {
        Collections.sort(times);
        list.removeAllViews();
        if (times.isEmpty()) {
            list.addView(Ui.subtitle(this, "Nenhum horário cadastrado."));
            return;
        }
        for (int i = 0; i < times.size(); i++) {
            final int index = i;
            LinearLayout card = Ui.card(this);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView time = new TextView(this);
            time.setText(times.get(i));
            time.setTextSize(24);
            time.setTypeface(null, android.graphics.Typeface.BOLD);
            row.addView(time, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            card.addView(row);

            Button edit = Ui.secondaryButton(this, "Editar");
            edit.setOnClickListener(v -> chooseTime(index));
            card.addView(edit);
            card.addView(Ui.space(this, 5));
            Button remove = Ui.dangerButton(this, "Excluir horário");
            remove.setOnClickListener(v -> {
                times.remove(index);
                renderTimes();
            });
            card.addView(remove);
            list.addView(card);
        }
    }

    private void chooseTime(int editIndex) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        if (editIndex >= 0 && editIndex < times.size()) {
            String[] parts = times.get(editIndex).split(":");
            try {
                hour = Integer.parseInt(parts[0]);
                minute = Integer.parseInt(parts[1]);
            } catch (Exception ignored) {}
        }
        new TimePickerDialog(this, (view, h, m) -> {
            String value = String.format(Locale.getDefault(), "%02d:%02d", h, m);
            if (editIndex >= 0 && editIndex < times.size()) times.set(editIndex, value);
            else if (!times.contains(value)) times.add(value);
            renderTimes();
        }, hour, minute, true).show();
    }

    @Override
    public void onBackPressed() {
        saveAndFinish();
    }

    private void saveAndFinish() {
        medication.times.clear();
        medication.times.addAll(times);
        ProtocolStore.save(this, protocol);
        Toast.makeText(this, "Horários salvos no protocolo.", Toast.LENGTH_SHORT).show();
        finish();
    }
}
