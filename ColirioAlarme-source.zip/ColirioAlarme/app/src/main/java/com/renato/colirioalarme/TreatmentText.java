package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class TreatmentText {
    private TreatmentText() {}

    public static ArrayList<String> defaultTimes(int frequency) {
        switch (frequency) {
            case 1: return new ArrayList<>(Arrays.asList("08:00"));
            case 2: return new ArrayList<>(Arrays.asList("08:00", "20:00"));
            case 3: return new ArrayList<>(Arrays.asList("08:00", "14:00", "20:00"));
            case 4: return new ArrayList<>(Arrays.asList("08:00", "12:00", "16:00", "20:00"));
            case 5: return new ArrayList<>(Arrays.asList("08:00", "11:00", "14:00", "17:00", "20:00"));
            case 6: return new ArrayList<>(Arrays.asList("07:00", "10:00", "13:00", "16:00", "19:00", "22:00"));
            default: return new ArrayList<>();
        }
    }

    public static String phaseSummary(TreatmentPhase phase) {
        if (phase == null) return "";
        String duration = phase.days <= 0 ? "uso contínuo" : "por " + phase.days + (phase.days == 1 ? " dia" : " dias");
        String frequency = phase.times.size() + "x/dia";
        String times = phase.times.isEmpty() ? "sem horários" : String.join(" | ", phase.times);
        return frequency + " " + duration + " • " + times;
    }

    public static String phasesSummary(List<TreatmentPhase> phases) {
        if (phases == null || phases.isEmpty()) return "Sem esquema cadastrado";
        ArrayList<String> lines = new ArrayList<>();
        for (int i = 0; i < phases.size(); i++) {
            String prefix = phases.size() > 1 ? "Etapa " + (i + 1) + ": " : "";
            lines.add(prefix + phaseSummary(phases.get(i)));
        }
        return String.join("\n", lines);
    }

    public static String startSummary(MedicationPlan plan) {
        if (plan == null) return "";
        if (plan.startsAfterMedicine != null && !plan.startsAfterMedicine.trim().isEmpty()) {
            return "Inicia após o término de " + plan.startsAfterMedicine;
        }
        if (plan.startDelayDays > 0) {
            return "Inicia após " + plan.startDelayDays + (plan.startDelayDays == 1 ? " dia" : " dias");
        }
        return "Início imediato";
    }
}
