package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class PatientFormDialog {
    public interface Callback { void onSaved(Patient patient, boolean surgeryDateChanged); }
    private static final String[] EYES = {"Olho direito", "Olho esquerdo", "Ambos os olhos"};

    private PatientFormDialog() {}

    public static void show(Activity activity, Patient existing, Callback callback) {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(activity, 20);
        box.setPadding(pad, Ui.dp(activity, 6), pad, 0);

        EditText name = new EditText(activity);
        name.setHint("Nome do paciente");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);

        EditText surgeryType = new EditText(activity);
        surgeryType.setHint("Tipo de cirurgia");
        surgeryType.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);

        Spinner eye = new Spinner(activity);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item, EYES);
        eye.setAdapter(adapter);

        EditText date = new EditText(activity);
        date.setHint("Data da cirurgia");
        date.setFocusable(false);
        date.setClickable(true);
        date.setCompoundDrawablesWithIntrinsicBounds(0, 0, android.R.drawable.ic_menu_my_calendar, 0);

        EditText patientPassword = new EditText(activity);
        patientPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        boolean alreadyHasPassword = PatientAccessUtil.hasPassword(existing);
        patientPassword.setHint(existing == null || !alreadyHasPassword
                ? "Senha de acesso do paciente (mínimo 6 caracteres)"
                : "Nova senha do paciente (deixe em branco para manter)");

        long initialDate = existing == null ? System.currentTimeMillis() : existing.surgeryDateMillis;
        final long[] selectedDate = {TreatmentUtils.midnight(initialDate)};
        updateDateText(date, selectedDate[0]);
        date.setOnClickListener(v -> chooseDate(activity, date, selectedDate));

        if (existing != null) {
            name.setText(existing.name);
            surgeryType.setText(existing.surgeryType);
            int selected = 2;
            for (int i = 0; i < EYES.length; i++) if (EYES[i].equalsIgnoreCase(existing.operatedEye)) selected = i;
            eye.setSelection(selected);
        }

        box.addView(name);
        box.addView(surgeryType);
        box.addView(Ui.subtitle(activity, "Olho operado"));
        box.addView(eye);
        box.addView(Ui.space(activity, 6));
        box.addView(Ui.subtitle(activity, "Data da cirurgia"));
        box.addView(date);
        box.addView(Ui.space(activity, 6));
        box.addView(Ui.subtitle(activity, "Acesso do paciente"));
        box.addView(patientPassword);

        long oldDate = existing == null ? selectedDate[0] : existing.surgeryDateMillis;
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(existing == null ? "Novo paciente" : "Editar paciente")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", null)
                .create();

        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String st = surgeryType.getText().toString().trim();
            String pass = patientPassword.getText().toString();
            if (n.isEmpty() || st.isEmpty()) {
                Toast.makeText(activity, "Preencha nome e tipo de cirurgia.", Toast.LENGTH_LONG).show();
                return;
            }
            if ((existing == null || !alreadyHasPassword) && pass.length() < 6) {
                Toast.makeText(activity, "Crie uma senha de acesso do paciente com pelo menos 6 caracteres.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!pass.isEmpty() && pass.length() < 6) {
                Toast.makeText(activity, "A nova senha precisa ter pelo menos 6 caracteres.", Toast.LENGTH_LONG).show();
                return;
            }

            String selectedEye = String.valueOf(eye.getSelectedItem());
            Patient patient = existing == null
                    ? new Patient(n, "", st, selectedEye, selectedDate[0])
                    : existing;
            patient.name = n;
            patient.phone = ""; // V12: telefone deixa de fazer parte do cadastro.
            patient.surgeryType = st;
            patient.operatedEye = selectedEye;
            patient.surgeryDateMillis = TreatmentUtils.midnight(selectedDate[0]);
            if (!pass.isEmpty()) PatientAccessUtil.setPassword(patient, pass);
            else PatientAccessUtil.refreshTokenForName(patient);

            boolean changed = existing != null && TreatmentUtils.midnight(oldDate) != patient.surgeryDateMillis;
            dialog.dismiss();
            if (callback != null) callback.onSaved(patient, changed);
        }));
        dialog.show();
    }

    private static void chooseDate(Activity activity, EditText field, long[] selectedDate) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(selectedDate[0]);
        new DatePickerDialog(activity, (view, year, month, dayOfMonth) -> {
            Calendar chosen = Calendar.getInstance();
            chosen.set(year, month, dayOfMonth, 0, 0, 0);
            chosen.set(Calendar.MILLISECOND, 0);
            selectedDate[0] = chosen.getTimeInMillis();
            updateDateText(field, selectedDate[0]);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private static void updateDateText(EditText field, long millis) {
        field.setText(new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(millis)));
    }
}
