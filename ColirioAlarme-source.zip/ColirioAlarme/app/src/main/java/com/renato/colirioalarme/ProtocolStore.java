package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ProtocolStore {
    private static final String PREFS = "colirio_programacao_v3";
    private static final String KEY_PROTOCOLS = "protocols";

    private ProtocolStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<SurgeryProtocol> getAll(Context context) {
        ArrayList<SurgeryProtocol> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_PROTOCOLS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String id = obj.optString("id", "");
                String name = obj.optString("name", "").trim();
                String guidanceId = obj.optString("guidanceId", "");
                ArrayList<ProtocolMedication> meds = new ArrayList<>();
                JSONArray medsJson = obj.optJSONArray("medications");
                if (medsJson != null) {
                    for (int j = 0; j < medsJson.length(); j++) {
                        JSONObject medObj = medsJson.optJSONObject(j);
                        if (medObj == null) continue;
                        String medicine = medObj.optString("medicine", "").trim();
                        if (medicine.isEmpty()) continue;
                        ArrayList<TreatmentPhase> phases = PlanStore.readPhases(medObj);
                        if (phases.isEmpty()) {
                            ArrayList<String> times = PlanStore.readTimes(medObj.optJSONArray("times"));
                            phases.add(new TreatmentPhase(0, times));
                        }
                        int delay = Math.max(0, medObj.optInt("startDelayDays", 0));
                        String after = medObj.optString("startsAfterMedicine", "");
                        meds.add(new ProtocolMedication(medicine, phases, delay, after));
                    }
                }
                if (!id.isEmpty() && !name.isEmpty()) result.add(new SurgeryProtocol(id, name, meds, guidanceId));
            }
        } catch (Exception ignored) {}
        final Collator collator = Collator.getInstance(new Locale("pt", "BR"));
        collator.setStrength(Collator.PRIMARY);
        result.sort((a, b) -> collator.compare(a.name, b.name));
        return result;
    }

    public static SurgeryProtocol getById(Context context, String id) {
        if (id == null) return null;
        for (SurgeryProtocol p : getAll(context)) if (id.equals(p.id)) return p;
        return null;
    }

    public static void save(Context context, SurgeryProtocol protocol) {
        List<SurgeryProtocol> all = getAll(context);
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(protocol.id)) {
                all.set(i, protocol);
                replaced = true;
                break;
            }
        }
        if (!replaced) all.add(protocol);
        saveAll(context, all);
        FirebaseRepository.syncDoctorCatalogs(context, null);
    }

    public static void delete(Context context, String id) {
        List<SurgeryProtocol> all = getAll(context);
        all.removeIf(p -> p.id.equals(id));
        saveAll(context, all);
        FirebaseRepository.syncDoctorCatalogs(context, null);
    }


    public static JSONArray exportDoctorData(Context context) {
        try { return new JSONArray(prefs(context).getString(KEY_PROTOCOLS, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public static void importDoctorData(Context context, JSONArray data) {
        if (data == null) return;
        prefs(context).edit().putString(KEY_PROTOCOLS, data.toString()).apply();
    }

    private static void saveAll(Context context, List<SurgeryProtocol> all) {
        JSONArray arr = new JSONArray();
        try {
            for (SurgeryProtocol p : all) {
                JSONObject obj = new JSONObject();
                obj.put("id", p.id);
                obj.put("name", p.name);
                obj.put("guidanceId", p.guidanceId == null ? "" : p.guidanceId);
                JSONArray meds = new JSONArray();
                for (ProtocolMedication med : p.medications) {
                    med.syncLegacyTimes();
                    JSONObject medObj = new JSONObject();
                    medObj.put("medicine", med.medicine);
                    medObj.put("startDelayDays", med.startDelayDays);
                    medObj.put("startsAfterMedicine", med.startsAfterMedicine == null ? "" : med.startsAfterMedicine);
                    medObj.put("phases", PlanStore.phasesToJson(med.phases));
                    JSONArray times = new JSONArray();
                    for (String time : med.times) times.put(time);
                    medObj.put("times", times);
                    meds.put(medObj);
                }
                obj.put("medications", meds);
                arr.put(obj);
            }
        } catch (Exception ignored) {}
        prefs(context).edit().putString(KEY_PROTOCOLS, arr.toString()).apply();
    }
}
