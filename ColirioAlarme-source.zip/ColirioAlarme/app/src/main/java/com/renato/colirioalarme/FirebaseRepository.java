package com.renato.colirioalarme;

import android.content.Context;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.SetOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Acesso centralizado ao Firestore. Mantém uma cópia local para o app continuar funcionando sem internet. */
public final class FirebaseRepository {
    public interface ResultCallback { void onResult(boolean ok, String message); }

    private FirebaseRepository() {}

    private static FirebaseUser doctor() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        return user != null && !user.isAnonymous() ? user : null;
    }

    public static void ensureDoctorProfile(Context context) {
        FirebaseUser user = doctor();
        if (user == null) return;
        Map<String, Object> data = new HashMap<>();
        data.put("email", user.getEmail() == null ? "" : user.getEmail());
        data.put("updatedAt", FieldValue.serverTimestamp());
        FirebaseFirestore.getInstance().collection("doctors").document(user.getUid()).set(data, SetOptions.merge());
    }


    /** Salva medicamentos, programações, protocolos e orientações no perfil online do médico. */
    public static void syncDoctorCatalogs(Context context, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null) {
            if (callback != null) callback.onResult(false, "Médico não autenticado.");
            return;
        }
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("medicineDataJson", PlanStore.exportDoctorData(context).toString());
            data.put("protocolsJson", ProtocolStore.exportDoctorData(context).toString());
            data.put("guidancesJson", GuidanceStore.exportDoctorData(context).toString());
            data.put("catalogUpdatedAt", FieldValue.serverTimestamp());
            FirebaseFirestore.getInstance().collection("doctors").document(user.getUid())
                    .set(data, SetOptions.merge())
                    .addOnSuccessListener(x -> { if (callback != null) callback.onResult(true, "Cadastros sincronizados."); })
                    .addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
        } catch (Exception e) {
            if (callback != null) callback.onResult(false, e.getMessage());
        }
    }

    /** Recupera do Firestore os cadastros do médico após login/reinstalação. */
    public static void pullDoctorCatalogs(Context context, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null) {
            if (callback != null) callback.onResult(false, "Médico não autenticado.");
            return;
        }
        FirebaseFirestore.getInstance().collection("doctors").document(user.getUid()).get()
                .addOnSuccessListener(doc -> {
                    try {
                        String medicines = doc.getString("medicineDataJson");
                        String protocols = doc.getString("protocolsJson");
                        String guidances = doc.getString("guidancesJson");
                        boolean hasBackup = (medicines != null && !medicines.isEmpty())
                                || (protocols != null && !protocols.isEmpty())
                                || (guidances != null && !guidances.isEmpty());
                        if (!hasBackup) {
                            syncDoctorCatalogs(context, callback);
                            return;
                        }
                        if (medicines != null && !medicines.isEmpty()) PlanStore.importDoctorData(context, new JSONObject(medicines));
                        if (protocols != null && !protocols.isEmpty()) ProtocolStore.importDoctorData(context, new JSONArray(protocols));
                        if (guidances != null && !guidances.isEmpty()) GuidanceStore.importDoctorData(context, new JSONArray(guidances));
                        if (callback != null) callback.onResult(true, "Cadastros recuperados da conta.");
                    } catch (Exception e) {
                        if (callback != null) callback.onResult(false, e.getMessage());
                    }
                })
                .addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
    }

    public static void syncPatient(Context context, Patient patient, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null || patient == null) {
            if (callback != null) callback.onResult(false, "Médico não autenticado.");
            return;
        }
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("id", patient.id);
            data.put("name", patient.name);
            data.put("phone", patient.phone);
            data.put("surgeryType", patient.surgeryType == null ? "" : patient.surgeryType);
            data.put("operatedEye", patient.operatedEye == null ? "" : patient.operatedEye);
            data.put("surgeryDateMillis", patient.surgeryDateMillis);
            data.put("linkToken", patient.linkToken);
            data.put("dataJson", PatientStore.toJson(patient).toString());
            data.put("updatedAt", FieldValue.serverTimestamp());
            FirebaseFirestore.getInstance().collection("doctors").document(user.getUid())
                    .collection("patients").document(patient.id).set(data)
                    .addOnSuccessListener(x -> { if (callback != null) callback.onResult(true, "Paciente sincronizado."); })
                    .addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
        } catch (Exception e) {
            if (callback != null) callback.onResult(false, e.getMessage());
        }
    }

    public static void syncAllLocalPatients(Context context, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null) { if (callback != null) callback.onResult(false, "Médico não autenticado."); return; }
        List<Patient> local = PatientStore.getAll(context);
        if (local.isEmpty()) { if (callback != null) callback.onResult(true, "Nenhum paciente local para enviar."); return; }
        final int total = local.size();
        final int[] done = {0};
        final boolean[] anyFail = {false};
        for (Patient patient : local) {
            syncPatient(context, patient, (ok, msg) -> {
                if (!ok) anyFail[0] = true;
                done[0]++;
                if (done[0] == total && callback != null) callback.onResult(!anyFail[0], anyFail[0] ? "Parte da sincronização falhou." : "Pacientes sincronizados.");
            });
        }
    }

    public static void pullPatients(Context context, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null) { if (callback != null) callback.onResult(false, "Médico não autenticado."); return; }
        FirebaseFirestore.getInstance().collection("doctors").document(user.getUid()).collection("patients")
                .get().addOnSuccessListener(snapshot -> {
                    ArrayList<Patient> patients = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : snapshot) {
                        try {
                            String json = doc.getString("dataJson");
                            Patient p = json == null ? null : PatientStore.fromJson(new JSONObject(json));
                            if (p != null) patients.add(p);
                        } catch (Exception ignored) {}
                    }
                    PatientStore.mergeFromCloud(context, patients);
                    if (callback != null) callback.onResult(true, patients.size() + " paciente(s) recebido(s).");
                }).addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
    }

    public static void deletePatient(Context context, String patientId, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null || patientId == null || patientId.isEmpty()) return;
        FirebaseFirestore.getInstance().collection("doctors").document(user.getUid()).collection("patients")
                .document(patientId).delete()
                .addOnSuccessListener(x -> { if (callback != null) callback.onResult(true, "Paciente excluído da nuvem."); })
                .addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
    }

    public static void publishPatientProgram(Context context, Patient patient, PatientAssignment assignment,
                                             JSONObject program, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null || patient == null || assignment == null || program == null) {
            if (callback != null) callback.onResult(false, "Entre novamente na Área do médico.");
            return;
        }
        syncPatient(context, patient, null);
        Map<String, Object> data = new HashMap<>();
        data.put("doctorUid", user.getUid());
        data.put("patientId", patient.id);
        data.put("patientName", patient.name);
        data.put("phone", patient.phone);
        data.put("assignmentId", assignment.id);
        data.put("protocolName", assignment.protocolName);
        data.put("programJson", program.toString());
        data.put("active", true);
        data.put("updatedAt", FieldValue.serverTimestamp());
        FirebaseFirestore.getInstance().collection("patientLinks").document(patient.linkToken).set(data)
                .addOnSuccessListener(x -> { if (callback != null) callback.onResult(true, "Protocolo publicado."); })
                .addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
    }

    public static void fetchPatientFollowUp(Context context, Patient patient, ResultCallback callback) {
        FirebaseUser user = doctor();
        if (user == null || patient == null || patient.linkToken == null || patient.linkToken.isEmpty()) {
            if (callback != null) callback.onResult(false, "Paciente sem vínculo Firebase.");
            return;
        }
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("patientLinks").document(patient.linkToken).collection("doseLog")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(300).get()
                .addOnSuccessListener(logSnapshot -> {
                    JSONArray logs = new JSONArray();
                    for (QueryDocumentSnapshot doc : logSnapshot) {
                        try {
                            JSONObject o = new JSONObject();
                            o.put("timestamp", number(doc.get("timestamp")));
                            o.put("patientId", safe(doc.getString("patientId")));
                            o.put("medicine", safe(doc.getString("medicine")));
                            o.put("eye", safe(doc.getString("eye")));
                            o.put("time", safe(doc.getString("time")));
                            o.put("status", safe(doc.getString("status")));
                            logs.put(o);
                        } catch (Exception ignored) {}
                    }
                    db.collection("patientLinks").document(patient.linkToken).collection("status").document("current").get()
                            .addOnSuccessListener(status -> {
                                JSONArray plans = new JSONArray();
                                try {
                                    String plansJson = status.getString("plansJson");
                                    if (plansJson != null && !plansJson.isEmpty()) plans = new JSONArray(plansJson);
                                } catch (Exception ignored) {}
                                AdherenceStore.saveReport(context, patient.id, logs, plans);
                                if (callback != null) callback.onResult(true, "Acompanhamento atualizado pela internet.");
                            })
                            .addOnFailureListener(e -> {
                                AdherenceStore.saveReport(context, patient.id, logs, new JSONArray());
                                if (callback != null) callback.onResult(true, "Registros atualizados; horários não disponíveis.");
                            });
                }).addOnFailureListener(e -> { if (callback != null) callback.onResult(false, e.getMessage()); });
    }

    private static long number(Object value) {
        if (value instanceof Number) return ((Number) value).longValue();
        return 0L;
    }

    private static String safe(String v) { return v == null ? "" : v; }
}
