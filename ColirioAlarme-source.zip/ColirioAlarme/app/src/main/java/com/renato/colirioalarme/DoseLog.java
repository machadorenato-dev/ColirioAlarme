package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class DoseLog {
    private static final String PREFS = "colirio_programacao_v3";
    private static final String KEY = "dose_log";
    private static final int MAX_ITEMS = 1000;

    private DoseLog() {}

    public static void add(Context context, String medicine, String eye, String time, String status) {
        add(context, PatientProfileStore.getId(context), medicine, eye, time, status);
    }

    public static void add(Context context, String patientId, String medicine, String eye, String time, String status) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray old;
        try {
            old = new JSONArray(prefs.getString(KEY, "[]"));
        } catch (Exception e) {
            old = new JSONArray();
        }
        JSONArray updated = new JSONArray();
        try {
            JSONObject entry = new JSONObject();
            entry.put("timestamp", System.currentTimeMillis());
            entry.put("patientId", patientId == null ? "" : patientId);
            entry.put("medicine", medicine == null ? "" : medicine);
            entry.put("eye", eye == null ? "" : eye);
            entry.put("time", time == null ? "" : time);
            entry.put("status", status == null ? "" : status);
            updated.put(entry);
            FirebasePatientSync.uploadDoseEntry(context, new JSONObject(entry.toString()));
            for (int i = 0; i < old.length() && updated.length() < MAX_ITEMS; i++) updated.put(old.get(i));
        } catch (Exception ignored) {}
        prefs.edit().putString(KEY, updated.toString()).apply();
    }

    public static void addUnansweredOnce(Context context, String medicine, String eye, String time) {
        String patientId = PatientProfileStore.getId(context);
        long cutoff = System.currentTimeMillis() - 6L * 60L * 60L * 1000L;
        for (JSONObject entry : getEntries(context, patientId)) {
            if (entry.optLong("timestamp", 0) < cutoff) break;
            if ("SEM_RESPOSTA".equals(entry.optString("status", ""))
                    && safeEquals(medicine, entry.optString("medicine", ""))
                    && safeEquals(eye, entry.optString("eye", ""))
                    && safeEquals(time, entry.optString("time", ""))) return;
        }
        add(context, patientId, medicine, eye, time, "SEM_RESPOSTA");
    }

    private static boolean safeEquals(String a, String b) {
        return (a == null ? "" : a).equals(b == null ? "" : b);
    }

    public static List<JSONObject> getEntries(Context context, String patientId) {
        ArrayList<JSONObject> result = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                String stored = obj.optString("patientId", "");
                if (patientId == null || patientId.isEmpty()) {
                    if (stored.isEmpty()) result.add(obj);
                } else if (patientId.equals(stored)) result.add(obj);
            }
        } catch (Exception ignored) {}
        return result;
    }
}
