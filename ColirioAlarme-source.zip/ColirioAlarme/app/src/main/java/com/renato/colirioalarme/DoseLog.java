package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public final class DoseLog {
    private static final String PREFS = "colirio_programacao_v3";
    private static final String KEY = "dose_log";
    private static final int MAX_ITEMS = 500;

    private DoseLog() {}

    public static void add(Context context, String medicine, String eye, String time, String status) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray old;
        try {
            old = new JSONArray(prefs.getString(KEY, "[]"));
        } catch (Exception e) {
            old = new JSONArray();
        }
        JSONArray updated = new JSONArray();
        try {
            JSONObject entry = new JSONObject();
            entry.put("timestamp", System.currentTimeMillis());
            entry.put("medicine", medicine == null ? "" : medicine);
            entry.put("eye", eye == null ? "" : eye);
            entry.put("time", time == null ? "" : time);
            entry.put("status", status == null ? "" : status);
            updated.put(entry);
            for (int i = 0; i < old.length() && updated.length() < MAX_ITEMS; i++) updated.put(old.get(i));
        } catch (Exception ignored) {}
        prefs.edit().putString(KEY, updated.toString()).apply();
    }
}
