package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SurgeryProtocol {
    public String id;
    public String name;
    public ArrayList<ProtocolMedication> medications;
    public String guidanceId;

    public SurgeryProtocol(String name) {
        this(UUID.randomUUID().toString(), name, new ArrayList<>(), "");
    }

    public SurgeryProtocol(String id, String name, List<ProtocolMedication> medications, String guidanceId) {
        this.id = id;
        this.name = name;
        this.medications = new ArrayList<>(medications);
        this.guidanceId = guidanceId == null ? "" : guidanceId;
    }
}
