package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Locale;

public class ScheduleActivity extends Activity {
    private String medicine;
    private MedicationPlan originalPlan;
    private RadioGroup eyeGroup;
    private LinearLayout timeList;
    private final ArrayList<String> times = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        medicine = getIntent().getStringExtra("medicine");
        String planId = getIntent().getStringExtra("planId");
        if (planId != null) originalPlan = PlanStore.getPlanById(this, planId);
        if (originalPlan == null && medicine != null) originalPlan = PlanStore.getPlanForMedicine(this, medicine);
        if (originalPlan != null) {
            medicine = originalPlan.medicine;
            times.addAll(originalPlan.times);
        }
        if (medicine == null || medicine.trim().isEmpty()) {
            finish();
            return;
        }
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);

        page.addView(Ui.title(this, medicine));
        page.addView(Ui.subtitle(this, originalPlan == null
                ? "Escolha o olho e cadastre os horários deste colírio."
                : "Edite o olho ou os horários e salve novamente."));

        TextView eyeTitle = new TextView(this);
        eyeTitle.setText("Em qual olho?");
        eyeTitle.setTextSize(19);
        eyeTitle.setPadding(0, 0, 0, Ui.dp(this, 5));
        page.addView(eyeTitle);

        eyeGroup = new RadioGroup(this);
        eyeGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton right = radio("Olho direito");
        RadioButton left = radio("Olho esquerdo");
        RadioButton both = radio("Ambos os olhos");
        eyeGroup.addView(right);
        eyeGroup.addView(left);
        eyeGroup.addView(both);
        page.addView(eyeGroup);

        String selectedEye = originalPlan != null ? originalPlan.eye : "Ambos os olhos";
        if ("Olho direito".equals(selectedEye)) right.setChecked(true);
        else if ("Olho esquerdo".equals(selectedEye)) left.setChecked(true);
        else both.setChecked(true);

        addSpace(page, 12);
        TextView timeTitle = new TextView(this);
        timeTitle.setText("Horários");
        timeTitle.setTextSize(19);
        page.addView(timeTitle);

        timeList = new LinearLayout(this);
        timeList.setOrientation(LinearLayout.VERTICAL);
        page.addView(timeList);
        renderTimes();

        Button addTime = Ui.primaryButton(this, "+ Adicionar horário");
        addTime.setOnClickListener(v -> chooseTime(-1));
        page.addView(addTime);

        addSpace(page, 14);
        Button save = Ui.primaryButton(this, originalPlan == null ? "Salvar programação" : "Salvar alterações");
        save.setOnClickListener(v -> savePlan());
        page.addView(save);

        if (originalPlan != null) {
            addSpace(page, 8);
            Button delete = Ui.dangerButton(this, "Excluir programação deste colírio");
            delete.setOnClickListener(v -> confirmDelete());
            page.addView(delete);
        }

        setContentView(scroll);
    }

    private RadioButton radio(String text) {
        RadioButton button = new RadioButton(this);
        button.setText(text);
        button.setTextSize(17);
        button.setMinHeight(Ui.dp(this, 46));
        return button;
    }

    private void renderTimes() {
        Collections.sort(times);
        timeList.removeAllViews();
        if (times.isEmpty()) {
            TextView empty = Ui.subtitle(this, "Nenhum horário cadastrado.");
            timeList.addView(empty);
            return;
        }
        for (int i = 0; i < times.size(); i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));

            TextView time = new TextView(this);
            time.setText(times.get(i));
            time.setTextSize(22);
            row.addView(time, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            Button edit = Ui.smallButton(this, "Editar");
            edit.setOnClickListener(v -> chooseTime(index));
            row.addView(edit);

            Button remove = Ui.smallButton(this, "Excluir");
            remove.setTextColor(Ui.DANGER);
            remove.setOnClickListener(v -> {
                times.remove(index);
                renderTimes();
            });
            row.addView(remove);

            timeList.addView(row);
            timeList.addView(Ui.divider(this));
        }
    }

    private void chooseTime(int editIndex) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        if (editIndex >= 0 && editIndex < times.size()) {
            String[] parts = times.get(editIndex).split(":");
            try {
                hour = Integer.parseInt(parts[0]);
                minute = Integer.parseInt(parts[1]);
            } catch (Exception ignored) {}
        }
        new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            String value = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
            if (editIndex >= 0 && editIndex < times.size()) {
                times.set(editIndex, value);
            } else if (!times.contains(value)) {
                times.add(value);
            }
            renderTimes();
        }, hour, minute, true).show();
    }

    private void savePlan() {
        if (times.isEmpty()) {
            Toast.makeText(this, "Cadastre pelo menos um horário.", Toast.LENGTH_SHORT).show();
            return;
        }
        RadioButton selected = findViewById(eyeGroup.getCheckedRadioButtonId());
        if (selected == null) {
            Toast.makeText(this, "Escolha o olho.", Toast.LENGTH_SHORT).show();
            return;
        }
        String eye = selected.getText().toString();

        if (originalPlan != null) AlarmScheduler.cancelPlan(this, originalPlan);
        MedicationPlan updated = originalPlan == null
                ? new MedicationPlan(medicine, eye, times)
                : new MedicationPlan(originalPlan.id, medicine, eye, times);
        PlanStore.savePlan(this, updated);
        AlarmScheduler.schedulePlan(this, updated);
        Toast.makeText(this, "Programação salva.", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir programação?")
                .setMessage("Os alarmes de " + medicine + " serão cancelados.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> {
                    AlarmScheduler.cancelPlan(this, originalPlan);
                    PlanStore.deletePlan(this, originalPlan.id);
                    Toast.makeText(this, "Programação excluída.", Toast.LENGTH_SHORT).show();
                    finish();
                }).show();
    }

    private void addSpace(LinearLayout page, int dp) {
        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.dp(this, dp)));
        page.addView(space);
    }
}
