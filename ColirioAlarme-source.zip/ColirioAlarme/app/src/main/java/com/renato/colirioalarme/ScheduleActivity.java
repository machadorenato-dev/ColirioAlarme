package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class ScheduleActivity extends Activity {
    private String medicine;
    private MedicationPlan originalPlan;
    private RadioGroup eyeGroup;
    private LinearLayout phaseList;
    private TextView startLabel;
    private final ArrayList<TreatmentPhase> phases = new ArrayList<>();
    private int startDelayDays = 0;
    private String startsAfterMedicine = "";
    private int initialDelay = 0;
    private String initialAfter = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        medicine = getIntent().getStringExtra("medicine");
        String planId = getIntent().getStringExtra("planId");
        if (planId != null) originalPlan = PlanStore.getPlanById(this, planId);
        if (originalPlan == null && medicine != null) originalPlan = PlanStore.getPlanForMedicine(this, medicine);
        if (originalPlan != null) {
            medicine = originalPlan.medicine;
            for (TreatmentPhase p : originalPlan.phases) phases.add(p.copy());
            startDelayDays = originalPlan.startDelayDays;
            startsAfterMedicine = originalPlan.startsAfterMedicine == null ? "" : originalPlan.startsAfterMedicine;
        } else {
            phases.add(new TreatmentPhase(7, new ArrayList<>()));
        }
        initialDelay = startDelayDays;
        initialAfter = startsAfterMedicine;
        if (medicine == null || medicine.trim().isEmpty()) { finish(); return; }
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, medicine));
        page.addView(Ui.subtitle(this, "Defina o olho, quando o tratamento começa, a duração e os horários. Para desmame, adicione etapas sequenciais."));

        page.addView(Ui.sectionTitle(this, "Olho"));
        eyeGroup = new RadioGroup(this);
        eyeGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton right = radio("Olho direito");
        RadioButton left = radio("Olho esquerdo");
        RadioButton both = radio("Ambos os olhos");
        eyeGroup.addView(right); eyeGroup.addView(left); eyeGroup.addView(both);
        page.addView(eyeGroup);
        String selectedEye = originalPlan != null ? originalPlan.eye : "Ambos os olhos";
        if ("Olho direito".equals(selectedEye)) right.setChecked(true);
        else if ("Olho esquerdo".equals(selectedEye)) left.setChecked(true);
        else both.setChecked(true);

        page.addView(Ui.sectionTitle(this, "Início do tratamento"));
        LinearLayout startCard = Ui.card(this);
        startLabel = new TextView(this);
        startLabel.setTextSize(17);
        startLabel.setTextColor(Ui.TEXT);
        startCard.addView(startLabel);
        Button startRule = Ui.secondaryButton(this, "Alterar início");
        startRule.setOnClickListener(v -> chooseStartRule());
        startCard.addView(Ui.space(this, 6));
        startCard.addView(startRule);
        page.addView(startCard);
        renderStartRule();

        page.addView(Ui.sectionTitle(this, "Esquema / desmame"));
        phaseList = new LinearLayout(this);
        phaseList.setOrientation(LinearLayout.VERTICAL);
        page.addView(phaseList);
        renderPhases();

        Button addPhase = Ui.primaryButton(this, "+ Adicionar etapa do desmame");
        addPhase.setOnClickListener(v -> addPhase());
        page.addView(addPhase);

        page.addView(Ui.space(this, 16));
        Button save = Ui.primaryButton(this, originalPlan == null ? "Salvar programação" : "Salvar alterações");
        save.setOnClickListener(v -> savePlan());
        page.addView(save);

        if (originalPlan != null) {
            page.addView(Ui.space(this, 8));
            Button delete = Ui.dangerButton(this, "Excluir programação deste colírio");
            delete.setOnClickListener(v -> confirmDelete());
            page.addView(delete);
        }
        setContentView(scroll);
    }

    private RadioButton radio(String text) {
        RadioButton button = new RadioButton(this);
        button.setText(text);
        button.setTextSize(17);
        button.setMinHeight(Ui.dp(this, 46));
        return button;
    }

    private void renderStartRule() {
        if (startLabel == null) return;
        if (startsAfterMedicine != null && !startsAfterMedicine.isEmpty()) {
            startLabel.setText("Iniciar após o término de " + startsAfterMedicine);
        } else if (startDelayDays > 0) {
            startLabel.setText("Iniciar após " + startDelayDays + (startDelayDays == 1 ? " dia" : " dias"));
        } else startLabel.setText("Iniciar imediatamente");
    }

    private void chooseStartRule() {
        String[] options = {"Iniciar imediatamente", "Iniciar após X dias", "Iniciar após outro colírio terminar"};
        new AlertDialog.Builder(this)
                .setTitle("Quando iniciar?")
                .setItems(options, (d, which) -> {
                    if (which == 0) {
                        startDelayDays = 0; startsAfterMedicine = ""; renderStartRule();
                    } else if (which == 1) askDelayDays();
                    else chooseDependency();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void askDelayDays() {
        EditText input = numberInput(String.valueOf(Math.max(1, startDelayDays)));
        new AlertDialog.Builder(this)
                .setTitle("Aguardar quantos dias?")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    int value = parseInt(input.getText().toString(), 0);
                    if (value < 0) value = 0;
                    startDelayDays = value;
                    startsAfterMedicine = "";
                    renderStartRule();
                }).show();
    }

    private void chooseDependency() {
        List<MedicationPlan> plans = PlanStore.getPlans(this);
        ArrayList<String> names = new ArrayList<>();
        for (MedicationPlan p : plans) if (!p.medicine.equalsIgnoreCase(medicine)) names.add(p.medicine);
        if (names.isEmpty()) {
            Toast.makeText(this, "Cadastre primeiro o colírio que deve ser usado antes deste.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] items = names.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Iniciar depois de qual colírio?")
                .setItems(items, (d, which) -> {
                    startsAfterMedicine = items[which];
                    startDelayDays = 0;
                    renderStartRule();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void renderPhases() {
        phaseList.removeAllViews();
        for (int i = 0; i < phases.size(); i++) {
            final TreatmentPhase phase = phases.get(i);
            final int phaseNumber = i + 1;
            Collections.sort(phase.times);
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(phases.size() == 1 ? "Tratamento" : "Etapa " + phaseNumber);
            title.setTextSize(19);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setTextColor(Ui.TEXT);
            card.addView(title);

            TextView duration = new TextView(this);
            duration.setText(phase.days <= 0 ? "Duração: uso contínuo" : "Duração: " + phase.days + (phase.days == 1 ? " dia" : " dias"));
            duration.setTextSize(16);
            duration.setTextColor(Ui.MUTED);
            duration.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 7));
            card.addView(duration);

            if (phase.times.isEmpty()) card.addView(Ui.subtitle(this, "Nenhum horário cadastrado."));
            for (String current : new ArrayList<>(phase.times)) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView time = new TextView(this);
                time.setText(current);
                time.setTextSize(20);
                time.setTypeface(null, android.graphics.Typeface.BOLD);
                row.addView(time, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                Button edit = Ui.smallButton(this, "Editar");
                edit.setOnClickListener(v -> chooseTime(phase, current));
                row.addView(edit);
                Button remove = Ui.smallButton(this, "Excluir");
                remove.setTextColor(Ui.DANGER);
                remove.setOnClickListener(v -> { phase.times.remove(current); renderPhases(); });
                row.addView(remove);
                card.addView(row);
                card.addView(Ui.divider(this));
            }

            Button addTime = Ui.secondaryButton(this, "+ Adicionar horário");
            addTime.setOnClickListener(v -> chooseTime(phase, null));
            card.addView(addTime);
            card.addView(Ui.space(this, 6));

            Button editDays = Ui.secondaryButton(this, "Alterar duração");
            editDays.setOnClickListener(v -> editDuration(phase));
            card.addView(editDays);

            if (phases.size() > 1) {
                card.addView(Ui.space(this, 6));
                Button delete = Ui.dangerButton(this, "Excluir esta etapa");
                delete.setOnClickListener(v -> { phases.remove(phase); renderPhases(); });
                card.addView(delete);
            }
            phaseList.addView(card);
        }
    }

    private void chooseTime(TreatmentPhase phase, String existing) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY), minute = now.get(Calendar.MINUTE);
        if (existing != null) {
            String[] p = existing.split(":");
            try { hour = Integer.parseInt(p[0]); minute = Integer.parseInt(p[1]); } catch (Exception ignored) {}
        }
        new TimePickerDialog(this, (view, h, m) -> {
            String value = String.format(Locale.getDefault(), "%02d:%02d", h, m);
            if (existing != null) phase.times.remove(existing);
            if (!phase.times.contains(value)) phase.times.add(value);
            renderPhases();
        }, hour, minute, true).show();
    }

    private void editDuration(TreatmentPhase phase) {
        EditText input = numberInput(phase.days <= 0 ? "0" : String.valueOf(phase.days));
        new AlertDialog.Builder(this)
                .setTitle("Duração em dias")
                .setMessage("Digite 0 somente se o uso for contínuo.")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    phase.days = Math.max(0, parseInt(input.getText().toString(), 7));
                    renderPhases();
                }).show();
    }

    private void addPhase() {
        for (TreatmentPhase p : phases) {
            if (p.days <= 0) {
                Toast.makeText(this, "Antes de acrescentar um desmame, defina em dias a duração da etapa contínua atual.", Toast.LENGTH_LONG).show();
                return;
            }
        }
        String[] frequencies = {"1x/dia", "2x/dia", "3x/dia", "4x/dia", "5x/dia", "6x/dia"};
        new AlertDialog.Builder(this)
                .setTitle("Nova etapa — frequência")
                .setItems(frequencies, (d, which) -> askNewPhaseDays(which + 1))
                .setNegativeButton("Cancelar", null).show();
    }

    private void askNewPhaseDays(int frequency) {
        EditText input = numberInput("7");
        new AlertDialog.Builder(this)
                .setTitle(frequency + "x/dia por quantos dias?")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Adicionar", (d, w) -> {
                    int days = Math.max(1, parseInt(input.getText().toString(), 7));
                    phases.add(new TreatmentPhase(days, TreatmentText.defaultTimes(frequency)));
                    renderPhases();
                    Toast.makeText(this, "Etapa adicionada. Confira e ajuste os horários sugeridos.", Toast.LENGTH_LONG).show();
                }).show();
    }

    private void savePlan() {
        if (phases.isEmpty()) { Toast.makeText(this, "Cadastre pelo menos uma etapa.", Toast.LENGTH_SHORT).show(); return; }
        for (int i = 0; i < phases.size(); i++) {
            TreatmentPhase p = phases.get(i);
            if (p.times.isEmpty()) { Toast.makeText(this, "Cadastre horário(s) na etapa " + (i + 1) + ".", Toast.LENGTH_LONG).show(); return; }
            if (p.days <= 0 && i < phases.size() - 1) { Toast.makeText(this, "Somente a última etapa pode ser de uso contínuo.", Toast.LENGTH_LONG).show(); return; }
        }
        RadioButton selected = findViewById(eyeGroup.getCheckedRadioButtonId());
        if (selected == null) { Toast.makeText(this, "Escolha o olho.", Toast.LENGTH_SHORT).show(); return; }
        String eye = selected.getText().toString();

        if (originalPlan != null) AlarmScheduler.cancelPlan(this, originalPlan);
        boolean startChanged = originalPlan == null || initialDelay != startDelayDays || !safe(initialAfter).equals(safe(startsAfterMedicine));
        long anchor = originalPlan != null && !startChanged ? originalPlan.anchorDateMillis : System.currentTimeMillis();
        MedicationPlan updated = originalPlan == null
                ? new MedicationPlan(medicine, eye, phases, startDelayDays, startsAfterMedicine, anchor)
                : new MedicationPlan(originalPlan.id, medicine, eye, phases, startDelayDays, startsAfterMedicine, anchor);
        PlanStore.savePlan(this, updated);
        AlarmScheduler.schedulePlan(this, updated);
        AlarmScheduler.rescheduleDependents(this, medicine);
        Toast.makeText(this, "Programação salva.", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir programação?")
                .setMessage("Os alarmes de " + medicine + " serão cancelados.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> {
                    AlarmScheduler.cancelPlan(this, originalPlan);
                    PlanStore.deletePlan(this, originalPlan.id);
                    AlarmScheduler.rescheduleDependents(this, medicine);
                    Toast.makeText(this, "Programação excluída.", Toast.LENGTH_SHORT).show();
                    finish();
                }).show();
    }

    private EditText numberInput(String value) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(value);
        input.setSelectAllOnFocus(true);
        input.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        return input;
    }

    private int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value.trim()); } catch (Exception e) { return fallback; }
    }
    private String safe(String value) { return value == null ? "" : value; }
}
