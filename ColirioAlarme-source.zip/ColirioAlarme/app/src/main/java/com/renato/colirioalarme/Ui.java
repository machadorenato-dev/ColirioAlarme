package com.renato.colirioalarme;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int BLUE = Color.rgb(36, 87, 197);
    public static final int BLUE_DARK = Color.rgb(24, 62, 145);
    public static final int TEXT = Color.rgb(25, 30, 40);
    public static final int MUTED = Color.rgb(92, 101, 116);
    public static final int SURFACE = Color.rgb(247, 249, 253);
    public static final int BORDER = Color.rgb(218, 224, 235);
    public static final int DANGER = Color.rgb(177, 32, 46);

    private Ui() {}

    public static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static TextView title(Context context, String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(28);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextColor(TEXT);
        view.setPadding(0, dp(context, 8), 0, dp(context, 8));
        return view;
    }

    public static TextView sectionTitle(Context context, String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(20);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextColor(TEXT);
        view.setPadding(0, dp(context, 12), 0, dp(context, 8));
        return view;
    }

    public static TextView subtitle(Context context, String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(16);
        view.setTextColor(MUTED);
        view.setPadding(0, 0, 0, dp(context, 12));
        return view;
    }

    public static Button primaryButton(Context context, String text) {
        Button button = baseButton(context, text);
        button.setTextColor(Color.WHITE);
        button.setBackground(roundRect(context, BLUE, 16, 0, 0));
        return button;
    }

    public static Button secondaryButton(Context context, String text) {
        Button button = baseButton(context, text);
        button.setTextColor(BLUE_DARK);
        button.setBackground(roundRect(context, Color.WHITE, 16, BORDER, 1));
        return button;
    }

    public static Button secondaryButtonLeft(Context context, String text) {
        Button button = secondaryButton(context, text);
        button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        button.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        return button;
    }

    public static Button dangerButton(Context context, String text) {
        Button button = baseButton(context, text);
        button.setTextColor(DANGER);
        button.setBackground(roundRect(context, Color.rgb(255, 247, 248), 16, Color.rgb(236, 190, 196), 1));
        return button;
    }

    public static Button smallButton(Context context, String text) {
        Button button = secondaryButton(context, text);
        button.setTextSize(14);
        button.setMinHeight(dp(context, 44));
        button.setPadding(dp(context, 12), dp(context, 6), dp(context, 12), dp(context, 6));
        return button;
    }

    private static Button baseButton(Context context, String text) {
        Button button = new Button(context);
        button.setText(text);
        button.setTextSize(17);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(context, 56));
        button.setPadding(dp(context, 16), dp(context, 10), dp(context, 16), dp(context, 10));
        return button;
    }

    public static LinearLayout verticalPage(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(context, 18), dp(context, 14), dp(context, 18), dp(context, 30));
        layout.setBackgroundColor(Color.rgb(252, 253, 255));
        return layout;
    }

    public static LinearLayout card(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(context, 14), dp(context, 12), dp(context, 14), dp(context, 12));
        layout.setBackground(roundRect(context, Color.WHITE, 18, BORDER, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(context, 10));
        layout.setLayoutParams(lp);
        return layout;
    }

    public static View divider(Context context) {
        View divider = new View(context);
        divider.setBackgroundColor(BORDER);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(context, 1)));
        return divider;
    }

    public static View space(Context context, int dp) {
        View space = new View(context);
        space.setLayoutParams(new LinearLayout.LayoutParams(1, dp(context, dp)));
        return space;
    }

    private static GradientDrawable roundRect(Context context, int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(context, radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(context, strokeDp), stroke);
        return drawable;
    }
}
