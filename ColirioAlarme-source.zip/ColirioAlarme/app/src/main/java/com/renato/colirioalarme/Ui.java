package com.renato.colirioalarme;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}

    public static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static TextView title(Context context, String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(26);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextColor(Color.rgb(20, 20, 20));
        view.setPadding(0, dp(context, 6), 0, dp(context, 10));
        return view;
    }

    public static TextView subtitle(Context context, String text) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextSize(16);
        view.setTextColor(Color.rgb(70, 70, 70));
        view.setPadding(0, 0, 0, dp(context, 12));
        return view;
    }

    public static Button primaryButton(Context context, String text) {
        Button button = new Button(context);
        button.setText(text);
        button.setTextSize(17);
        button.setAllCaps(false);
        button.setMinHeight(dp(context, 54));
        return button;
    }

    public static LinearLayout verticalPage(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(context, 18), dp(context, 18), dp(context, 18), dp(context, 28));
        return layout;
    }

    public static View divider(Context context) {
        View divider = new View(context);
        divider.setBackgroundColor(Color.rgb(225, 225, 225));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(context, 1)));
        return divider;
    }
}
