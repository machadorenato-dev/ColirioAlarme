package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class ProtocolViewActivity extends Activity {
    private String protocolId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        protocolId = getIntent().getStringExtra("protocolId");
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        SurgeryProtocol protocol = ProtocolStore.getById(this, protocolId);
        if (protocol == null) { finish(); return; }

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Protocolos");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, protocol.name));

        page.addView(Ui.sectionTitle(this, "Medicamentos"));
        if (protocol.medications.isEmpty()) {
            page.addView(Ui.subtitle(this, "Nenhum medicamento cadastrado."));
        } else {
            for (ProtocolMedication med : protocol.medications) {
                LinearLayout card = Ui.card(this);
                TextView title = new TextView(this);
                title.setText(med.medicine);
                title.setTextSize(19);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextColor(Ui.TEXT);
                card.addView(title);

                String start;
                if (med.startsAfterMedicine != null && !med.startsAfterMedicine.trim().isEmpty()) {
                    start = "Inicia após o término de " + med.startsAfterMedicine;
                } else if (med.startDelayDays > 0) {
                    start = "Inicia após " + med.startDelayDays + (med.startDelayDays == 1 ? " dia" : " dias");
                } else {
                    start = "Inicia na data da cirurgia";
                }
                card.addView(Ui.subtitle(this, start));

                TextView schedule = new TextView(this);
                schedule.setText(TreatmentText.phasesSummary(med.phases));
                schedule.setTextSize(16);
                schedule.setTextColor(Ui.BLUE_DARK);
                schedule.setPadding(0, Ui.dp(this, 6), 0, 0);
                card.addView(schedule);
                page.addView(card);
            }
        }

        Guidance guidance = GuidanceStore.getById(this, protocol.guidanceId);
        page.addView(Ui.sectionTitle(this, "Orientação pós-operatória"));
        if (guidance == null) {
            page.addView(Ui.subtitle(this, "Nenhuma orientação vinculada."));
        } else {
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(guidance.title);
            title.setTextSize(18);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setTextColor(Ui.TEXT);
            card.addView(title);
            if (guidance.text != null && !guidance.text.trim().isEmpty()) {
                TextView text = new TextView(this);
                text.setText(guidance.text);
                text.setTextSize(16);
                text.setTextColor(Ui.TEXT);
                text.setPadding(0, Ui.dp(this, 8), 0, 0);
                card.addView(text);
            }
            page.addView(card);
        }

        page.addView(Ui.space(this, 16));
        Button edit = Ui.primaryButton(this, "Editar");
        edit.setOnClickListener(v -> {
            Intent intent = new Intent(this, ProtocolEditActivity.class);
            intent.putExtra("protocolId", protocol.id);
            startActivity(intent);
        });
        page.addView(edit);
        setContentView(scroll);
    }
}
