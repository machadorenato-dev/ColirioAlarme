package com.renato.colirioalarme;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

/** Assistente sequencial de permissões exibido logo após o login do paciente. */
public class PatientPermissionActivity extends Activity {
    private boolean openingHome = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showNextPermission();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!openingHome) showNextPermission();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1201) {
            if (notificationAllowed()) showNextPermission();
            else Toast.makeText(this, "Autorize as notificações para receber os alarmes dos medicamentos.", Toast.LENGTH_LONG).show();
        }
    }

    private void showNextPermission() {
        if (!notificationAllowed()) {
            renderStep("Configuração do paciente", "Etapa 1 de 3",
                    "Para que o aplicativo avise os horários dos medicamentos, permita as notificações.",
                    "Permitir notificações", this::requestNotifications);
            return;
        }
        if (!fullScreenAllowed()) {
            renderStep("Configuração do paciente", "Etapa 2 de 3",
                    "Permita o alarme em tela cheia para que o aviso apareça mesmo com a tela bloqueada.",
                    "Permitir alarme em tela cheia", this::requestFullScreen);
            return;
        }
        if (!overlayAllowed()) {
            renderStep("Configuração do paciente", "Etapa 3 de 3",
                    "Permita que o alarme apareça sobre outros aplicativos quando necessário.",
                    "Permitir janela sobre outros apps", this::requestOverlay);
            return;
        }
        openPatientHome();
    }

    private void renderStep(String title, String progress, String explanation,
                            String buttonText, Runnable action) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        page.addView(Ui.title(this, title));
        page.addView(Ui.subtitle(this, progress));
        page.addView(Ui.space(this, 14));
        page.addView(Ui.subtitle(this, explanation));
        page.addView(Ui.space(this, 18));
        Button allow = Ui.primaryButton(this, buttonText);
        allow.setOnClickListener(v -> action.run());
        page.addView(allow);
        setContentView(scroll);
    }

    private boolean notificationAllowed() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean fullScreenAllowed() {
        if (Build.VERSION.SDK_INT < 34) return true;
        NotificationManager nm = getSystemService(NotificationManager.class);
        return nm == null || nm.canUseFullScreenIntent();
    }

    private boolean overlayAllowed() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1201);
        } else showNextPermission();
    }

    private void requestFullScreen() {
        if (Build.VERSION.SDK_INT < 34) {
            showNextPermission();
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Abra as permissões especiais do aplicativo e autorize alarmes em tela cheia.", Toast.LENGTH_LONG).show();
        }
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            showNextPermission();
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Abra as permissões especiais e permita aparecer sobre outros aplicativos.", Toast.LENGTH_LONG).show();
        }
    }

    private void openPatientHome() {
        if (openingHome) return;
        openingHome = true;
        Intent intent = new Intent(this, PatientHomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}
