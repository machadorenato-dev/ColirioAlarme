package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DoctorAreaActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!DoctorAuthStore.isSignedIn()) { finish(); return; }
        FirebaseRepository.ensureDoctorProfile(this);
        FirebaseRepository.pullDoctorCatalogs(this, null);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Sair da Área do médico");
        back.setOnClickListener(v -> signOutAndFinish());
        page.addView(back);
        page.addView(Ui.title(this, "Área do médico"));
        page.addView(Ui.subtitle(this, DoctorAuthStore.getEmail(this)));

        Button patients = Ui.primaryButton(this, "Pacientes");
        patients.setOnClickListener(v -> startActivity(new Intent(this, PatientListActivity.class)));
        page.addView(patients);
        page.addView(Ui.space(this, 9));

        Button programming = Ui.primaryButton(this, "Medicamentos");
        programming.setOnClickListener(v -> startActivity(new Intent(this, MedicineListActivity.class)));
        page.addView(programming);
        page.addView(Ui.space(this, 9));

        Button protocols = Ui.primaryButton(this, "Protocolos");
        protocols.setOnClickListener(v -> startActivity(new Intent(this, ProtocolListActivity.class)));
        page.addView(protocols);
        page.addView(Ui.space(this, 9));

        Button guidance = Ui.primaryButton(this, "Orientações");
        guidance.setOnClickListener(v -> startActivity(new Intent(this, GuidanceListActivity.class)));
        page.addView(guidance);
        page.addView(Ui.space(this, 9));

        page.addView(Ui.sectionTitle(this, "Conta do médico"));
        Button change = Ui.secondaryButton(this, "Alterar senha");
        change.setOnClickListener(v -> changePassword());
        page.addView(change);
        page.addView(Ui.space(this, 8));
        Button logout = Ui.secondaryButton(this, "Sair da conta");
        logout.setOnClickListener(v -> signOutAndFinish());
        page.addView(logout);
        setContentView(scroll);
    }

    private void changePassword() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null || user.getEmail() == null || user.isAnonymous()) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 8), pad, 0);
        EditText current = passwordField("Senha atual");
        EditText next = passwordField("Nova senha");
        EditText confirm = passwordField("Confirme a nova senha");
        box.addView(current); box.addView(next); box.addView(confirm);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Alterar senha")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Alterar", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newPass = next.getText().toString();
            if (newPass.length() < 6 || !newPass.equals(confirm.getText().toString())) {
                Toast.makeText(this, "Confira a nova senha e a confirmação.", Toast.LENGTH_LONG).show();
                return;
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            user.reauthenticate(EmailAuthProvider.getCredential(user.getEmail(), current.getText().toString()))
                    .addOnCompleteListener(authTask -> {
                        if (!authTask.isSuccessful()) {
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                            Toast.makeText(this, "Senha atual incorreta.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        user.updatePassword(newPass).addOnCompleteListener(updateTask -> {
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                            if (updateTask.isSuccessful()) {
                                dialog.dismiss();
                                Toast.makeText(this, "Senha alterada.", Toast.LENGTH_LONG).show();
                            } else Toast.makeText(this, "Não foi possível alterar a senha.", Toast.LENGTH_LONG).show();
                        });
                    });
        }));
        dialog.show();
    }

    private EditText passwordField(String hint) {
        EditText f = new EditText(this);
        f.setHint(hint);
        f.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return f;
    }

    private void signOutAndFinish() {
        DoctorAuthStore.signOut();
        finish();
    }

    @Override
    public void onBackPressed() {
        signOutAndFinish();
    }
}
