package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class DoctorAreaActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!DoctorAuthStore.isConfigured(this)) { finish(); return; }
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Sair da Área do médico");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Área do médico"));
        page.addView(Ui.subtitle(this, DoctorAuthStore.getEmail(this)));

        Button patients = Ui.primaryButton(this, "Pacientes");
        patients.setOnClickListener(v -> startActivity(new Intent(this, PatientListActivity.class)));
        page.addView(patients);
        page.addView(Ui.space(this, 9));

        Button programming = Ui.primaryButton(this, "Programação dos colírios");
        programming.setOnClickListener(v -> startActivity(new Intent(this, MedicineListActivity.class)));
        page.addView(programming);
        page.addView(Ui.space(this, 9));

        Button protocols = Ui.primaryButton(this, "Protocolos cirúrgicos");
        protocols.setOnClickListener(v -> startActivity(new Intent(this, ProtocolListActivity.class)));
        page.addView(protocols);
        page.addView(Ui.space(this, 9));

        Button guidance = Ui.secondaryButton(this, "Modelos de orientações pós-operatórias");
        guidance.setOnClickListener(v -> startActivity(new Intent(this, GuidanceListActivity.class)));
        page.addView(guidance);
        page.addView(Ui.space(this, 9));

        Button share = Ui.primaryButton(this, "Enviar programação para o paciente");
        share.setOnClickListener(v -> ProgramTransfer.share(this));
        page.addView(share);

        page.addView(Ui.sectionTitle(this, "Segurança"));
        Button change = Ui.secondaryButton(this, "Alterar senha");
        change.setOnClickListener(v -> changePassword());
        page.addView(change);
        setContentView(scroll);
    }

    private void changePassword() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 8), pad, 0);
        EditText current = passwordField("Senha atual");
        EditText next = passwordField("Nova senha");
        EditText confirm = passwordField("Confirme a nova senha");
        box.addView(current); box.addView(next); box.addView(confirm);
        new AlertDialog.Builder(this).setTitle("Alterar senha").setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    if (next.getText().toString().length() < 6 || !next.getText().toString().equals(confirm.getText().toString())) {
                        Toast.makeText(this, "Confira a nova senha e a confirmação.", Toast.LENGTH_LONG).show(); return;
                    }
                    boolean ok = DoctorAuthStore.changePassword(this, current.getText().toString(), next.getText().toString());
                    Toast.makeText(this, ok ? "Senha alterada." : "Senha atual incorreta.", Toast.LENGTH_LONG).show();
                }).show();
    }

    private EditText passwordField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }
}
