package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PatientListActivity extends Activity {
    private LinearLayout page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
        syncFromCloud(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (page != null) render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Área do médico");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Pacientes"));
        page.addView(Ui.subtitle(this, "Os pacientes ficam salvos neste aparelho e também na sua conta Firebase."));

        Button add = Ui.primaryButton(this, "+ Novo paciente");
        add.setOnClickListener(v -> PatientFormDialog.show(this, null, (patient, changed) -> {
            PatientStore.save(this, patient);
            Toast.makeText(this, "Paciente salvo e sincronizado com sua conta.", Toast.LENGTH_SHORT).show();
            render();
        }));
        page.addView(add);
        page.addView(Ui.space(this, 8));

        page.addView(Ui.space(this, 14));

        List<Patient> patients = PatientStore.getAll(this);
        if (patients.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this, "Nenhum paciente cadastrado."));
            page.addView(card);
        } else {
            for (Patient patient : patients) addCard(patient);
        }
        setContentView(scroll);
    }

    private void syncFromCloud(boolean showToast) {
        FirebaseRepository.pullPatients(this, (ok, msg) -> runOnUiThread(() -> {
            if (showToast) Toast.makeText(this, ok ? "Pacientes sincronizados." : "Não foi possível sincronizar agora.", Toast.LENGTH_LONG).show();
            if (!isFinishing()) render();
        }));
    }

    private void addCard(Patient patient) {
        LinearLayout card = Ui.card(this);
        TextView name = new TextView(this);
        name.setText(patient.name);
        name.setTextSize(20);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setTextColor(Ui.TEXT);
        card.addView(name);
        if (!patient.phone.isEmpty()) card.addView(Ui.subtitle(this, patient.phone));
        String surgery = patient.surgeryType.isEmpty() ? "Cirurgia não informada" : patient.surgeryType;
        String date = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(patient.surgeryDateMillis));
        card.addView(Ui.subtitle(this, surgery + " • " + patient.operatedEye + " • " + date));
        String protocols = patient.assignments.isEmpty() ? "Nenhum protocolo" :
                patient.assignments.size() + (patient.assignments.size() == 1 ? " protocolo" : " protocolos");
        TextView count = Ui.subtitle(this, protocols);
        count.setPadding(0, 0, 0, Ui.dp(this, 6));
        card.addView(count);
        Button open = Ui.primaryButton(this, "Abrir paciente");
        open.setOnClickListener(v -> {
            Intent intent = new Intent(this, PatientDetailActivity.class);
            intent.putExtra("patientId", patient.id);
            startActivity(intent);
        });
        card.addView(open);
        page.addView(card);
    }
}
