package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class PatientListActivity extends Activity {
    private LinearLayout page;
    private boolean firstSyncDone = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
        syncFromCloud(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (page != null) render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Área do médico");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Pacientes"));
        page.addView(Ui.subtitle(this, "Os pacientes ficam salvos neste aparelho e também na sua conta Firebase."));

        Button add = Ui.primaryButton(this, "+ Novo paciente");
        add.setOnClickListener(v -> editPatient(null));
        page.addView(add);
        page.addView(Ui.space(this, 8));

        Button sync = Ui.secondaryButton(this, "Sincronizar pacientes pela internet");
        sync.setOnClickListener(v -> syncFromCloud(true));
        page.addView(sync);
        page.addView(Ui.space(this, 14));

        List<Patient> patients = PatientStore.getAll(this);
        if (patients.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this, "Nenhum paciente cadastrado."));
            page.addView(card);
        } else {
            for (Patient patient : patients) addCard(patient);
        }
        setContentView(scroll);
    }

    private void syncFromCloud(boolean showToast) {
        FirebaseRepository.pullPatients(this, (ok, msg) -> runOnUiThread(() -> {
            firstSyncDone = true;
            if (showToast) Toast.makeText(this, ok ? "Pacientes sincronizados." : "Não foi possível sincronizar agora.", Toast.LENGTH_LONG).show();
            if (!isFinishing()) render();
        }));
    }

    private void addCard(Patient patient) {
        LinearLayout card = Ui.card(this);
        TextView name = new TextView(this);
        name.setText(patient.name);
        name.setTextSize(20);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setTextColor(Ui.TEXT);
        card.addView(name);
        if (!patient.phone.isEmpty()) card.addView(Ui.subtitle(this, patient.phone));
        String protocols = patient.assignments.isEmpty() ? "Nenhum protocolo" :
                patient.assignments.size() + (patient.assignments.size() == 1 ? " protocolo" : " protocolos");
        TextView count = Ui.subtitle(this, protocols);
        count.setPadding(0, 0, 0, Ui.dp(this, 6));
        card.addView(count);
        Button open = Ui.primaryButton(this, "Abrir paciente");
        open.setOnClickListener(v -> {
            Intent intent = new Intent(this, PatientDetailActivity.class);
            intent.putExtra("patientId", patient.id);
            startActivity(intent);
        });
        card.addView(open);
        page.addView(card);
    }

    private void editPatient(Patient existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 6), pad, 0);
        EditText name = new EditText(this);
        name.setHint("Nome do paciente");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText phone = new EditText(this);
        phone.setHint("Telefone");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        if (existing != null) {
            name.setText(existing.name);
            phone.setText(existing.phone);
        }
        box.addView(name);
        box.addView(phone);
        new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Novo paciente" : "Editar paciente")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) {
                        Toast.makeText(this, "Informe o nome do paciente.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Patient patient = existing == null ? new Patient(n, phone.getText().toString()) : existing;
                    patient.name = n;
                    patient.phone = phone.getText().toString().trim();
                    PatientStore.save(this, patient);
                    Toast.makeText(this, "Paciente salvo. O Firebase sincronizará quando houver internet.", Toast.LENGTH_SHORT).show();
                    render();
                }).show();
    }
}
