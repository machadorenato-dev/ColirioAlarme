package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class PatientLoginActivity extends Activity {
    private EditText name;
    private EditText password;
    private Button enter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Paciente"));

        name = new EditText(this);
        name.setHint("Nome do paciente");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        String savedName = PatientProfileStore.getName(this);
        if (!savedName.isEmpty()) name.setText(savedName);
        page.addView(name);
        page.addView(Ui.space(this, 8));

        password = new EditText(this);
        password.setHint("Senha");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        page.addView(password);
        page.addView(Ui.space(this, 14));

        enter = Ui.primaryButton(this, "Entrar");
        enter.setOnClickListener(v -> login());
        page.addView(enter);
        setContentView(scroll);
    }

    private void login() {
        String patientName = name.getText().toString().trim();
        String pass = password.getText().toString();
        if (patientName.isEmpty() || pass.length() < 6) {
            Toast.makeText(this, "Informe o nome do paciente e a senha.", Toast.LENGTH_LONG).show();
            return;
        }
        enter.setEnabled(false);
        FirebasePatientSync.loginWithNameAndPassword(this, patientName, pass, (ok, msg) -> runOnUiThread(() -> {
            enter.setEnabled(true);
            if (!ok) {
                Toast.makeText(this, msg == null || msg.isEmpty() ? "Não foi possível entrar." : msg, Toast.LENGTH_LONG).show();
                return;
            }
            Toast.makeText(this, "Protocolo carregado.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, PatientHomeActivity.class);
            startActivity(intent);
            finish();
        }));
    }
}
