package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;

public class TreatmentPhase {
    public int days;
    public ArrayList<String> times;

    public TreatmentPhase(int days, List<String> times) {
        this.days = days;
        this.times = new ArrayList<>();
        if (times != null) this.times.addAll(times);
    }

    public TreatmentPhase copy() {
        return new TreatmentPhase(days, times);
    }
}
