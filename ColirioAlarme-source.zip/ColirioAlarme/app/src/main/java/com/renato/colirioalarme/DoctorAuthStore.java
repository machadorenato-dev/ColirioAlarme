package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.auth.FirebaseAuth;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/** Pequeno armazenamento local apenas para lembrar o e-mail do médico e validar o código de ativação.
 * A senha agora é gerenciada exclusivamente pelo Firebase Authentication. */
public final class DoctorAuthStore {
    private static final String PREFS = "doctor_auth_v7";
    private static final String KEY_EMAIL = "email";
    private static final String ACTIVATION_SHA256 = "671fabbc52624be9916582c37c74904371ecf3c9430f5e8f6e499e3382bf064c";

    private DoctorAuthStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isSignedIn() {
        return FirebaseAuth.getInstance().getCurrentUser() != null
                && !FirebaseAuth.getInstance().getCurrentUser().isAnonymous();
    }

    public static String getEmail(Context context) {
        if (FirebaseAuth.getInstance().getCurrentUser() != null
                && !FirebaseAuth.getInstance().getCurrentUser().isAnonymous()
                && FirebaseAuth.getInstance().getCurrentUser().getEmail() != null) {
            return FirebaseAuth.getInstance().getCurrentUser().getEmail();
        }
        String current = prefs(context).getString(KEY_EMAIL, "");
        if (!current.isEmpty()) return current;
        // Migração do e-mail lembrado nas versões anteriores.
        return context.getSharedPreferences("doctor_auth_v4", Context.MODE_PRIVATE).getString("email", "");
    }

    public static void rememberEmail(Context context, String email) {
        prefs(context).edit().putString(KEY_EMAIL, normalizeEmail(email)).apply();
    }

    public static void signOut() {
        FirebaseAuth.getInstance().signOut();
    }

    public static boolean verifyActivationCode(String code) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest((code == null ? "" : code.trim().toUpperCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) hex.append(String.format(Locale.US, "%02x", b));
            return constantEquals(ACTIVATION_SHA256, hex.toString());
        } catch (Exception e) {
            return false;
        }
    }

    private static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    private static boolean constantEquals(String a, String b) {
        if (a == null || b == null || a.length() != b.length()) return false;
        int diff = 0;
        for (int i = 0; i < a.length(); i++) diff |= a.charAt(i) ^ b.charAt(i);
        return diff == 0;
    }
}
