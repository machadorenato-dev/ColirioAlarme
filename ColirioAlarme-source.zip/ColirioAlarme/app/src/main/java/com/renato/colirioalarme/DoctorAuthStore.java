package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

public final class DoctorAuthStore {
    private static final String PREFS = "doctor_auth_v4";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_SALT = "salt";
    private static final String KEY_HASH = "password_hash";
    private static final String KEY_RECOVERY_HASH = "recovery_hash";

    private static final String ACTIVATION_SHA256 = "671fabbc52624be9916582c37c74904371ecf3c9430f5e8f6e499e3382bf064c";

    private DoctorAuthStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isConfigured(Context context) {
        return !prefs(context).getString(KEY_HASH, "").isEmpty();
    }

    public static String getEmail(Context context) {
        return prefs(context).getString(KEY_EMAIL, "");
    }

    public static boolean verifyActivationCode(String code) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest((code == null ? "" : code.trim().toUpperCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) hex.append(String.format(Locale.US, "%02x", b));
            return constantEquals(ACTIVATION_SHA256, hex.toString());
        } catch (Exception e) {
            return false;
        }
    }

    public static String configure(Context context, String email, String password) {
        String salt = randomBase64(16);
        String recovery = String.format(Locale.US, "%08d", new SecureRandom().nextInt(100000000));
        prefs(context).edit()
                .putString(KEY_EMAIL, normalizeEmail(email))
                .putString(KEY_SALT, salt)
                .putString(KEY_HASH, hash(salt, password))
                .putString(KEY_RECOVERY_HASH, hash(salt, recovery))
                .apply();
        return recovery;
    }

    public static boolean verifyPassword(Context context, String email, String password) {
        SharedPreferences p = prefs(context);
        String storedEmail = p.getString(KEY_EMAIL, "");
        String salt = p.getString(KEY_SALT, "");
        String storedHash = p.getString(KEY_HASH, "");
        if (storedHash.isEmpty() || salt.isEmpty()) return false;
        if (!storedEmail.equals(normalizeEmail(email))) return false;
        return constantEquals(storedHash, hash(salt, password));
    }

    public static boolean resetWithRecovery(Context context, String email, String recoveryCode, String newPassword) {
        SharedPreferences p = prefs(context);
        if (!p.getString(KEY_EMAIL, "").equals(normalizeEmail(email))) return false;
        String salt = p.getString(KEY_SALT, "");
        String recoveryHash = p.getString(KEY_RECOVERY_HASH, "");
        if (salt.isEmpty() || recoveryHash.isEmpty()) return false;
        if (!constantEquals(recoveryHash, hash(salt, recoveryCode))) return false;
        p.edit().putString(KEY_HASH, hash(salt, newPassword)).apply();
        return true;
    }

    public static boolean changePassword(Context context, String currentPassword, String newPassword) {
        String email = getEmail(context);
        if (!verifyPassword(context, email, currentPassword)) return false;
        String salt = prefs(context).getString(KEY_SALT, "");
        prefs(context).edit().putString(KEY_HASH, hash(salt, newPassword)).apply();
        return true;
    }

    private static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    private static String randomBase64(int bytes) {
        byte[] data = new byte[bytes];
        new SecureRandom().nextBytes(data);
        return Base64.encodeToString(data, Base64.NO_WRAP);
    }

    private static String hash(String salt, String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt.getBytes(StandardCharsets.UTF_8));
            digest.update((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(digest.digest(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean constantEquals(String a, String b) {
        if (a == null || b == null || a.length() != b.length()) return false;
        int diff = 0;
        for (int i = 0; i < a.length(); i++) diff |= a.charAt(i) ^ b.charAt(i);
        return diff == 0;
    }
}
