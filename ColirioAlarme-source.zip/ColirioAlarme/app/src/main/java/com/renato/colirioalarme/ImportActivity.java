package com.renato.colirioalarme;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class ImportActivity extends Activity {
    private JSONObject imported;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Uri uri = getIntent().getData();
        String extraUri = getIntent().getStringExtra("uri");
        if (uri == null && extraUri != null) uri = Uri.parse(extraUri);
        if (uri == null) {
            Toast.makeText(this, "Arquivo de programação não encontrado.", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        try {
            imported = new JSONObject(readAll(uri));
            if (!ProgramTransfer.MARKER.equals(imported.optString("app"))) throw new Exception("Arquivo não reconhecido");
            if ("adherence".equals(imported.optString("fileType"))) {
                Toast.makeText(this, "Este é um arquivo de acompanhamento. Importe-o na Área do médico > Pacientes > Acompanhamento.", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            buildScreen();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir esta programação.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private String readAll(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("sem conteúdo");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        page.addView(Ui.title(this, "Importar programação"));

        JSONObject patient = imported.optJSONObject("patient");
        String patientName = patient == null ? "" : patient.optString("name", "").trim();
        String protocolName = imported.optString("protocolName", "").trim();
        String subtitle = "Confira os colírios, o olho, a duração e as etapas antes de confirmar.";
        if (!patientName.isEmpty()) subtitle = "Paciente: " + patientName + (protocolName.isEmpty() ? "" : "\nProtocolo: " + protocolName) + "\n\n" + subtitle;
        page.addView(Ui.subtitle(this, subtitle));

        JSONArray plans = imported.optJSONArray("plans");
        if (plans != null) {
            for (int i = 0; i < plans.length(); i++) {
                JSONObject obj = plans.optJSONObject(i);
                if (obj == null) continue;
                LinearLayout card = Ui.card(this);
                TextView name = new TextView(this);
                name.setText(obj.optString("medicine", "Colírio"));
                name.setTextSize(19);
                name.setTypeface(null, android.graphics.Typeface.BOLD);
                card.addView(name);
                TextView details = new TextView(this);
                details.setText(previewPlan(obj));
                details.setTextSize(15);
                details.setTextColor(Ui.MUTED);
                card.addView(details);
                page.addView(card);
            }
        }

        JSONObject guidance = imported.optJSONObject("guidance");
        if (guidance != null && !guidance.optString("text", "").trim().isEmpty()) {
            page.addView(Ui.sectionTitle(this, "Orientações pós-operatórias"));
            LinearLayout card = Ui.card(this);
            TextView text = new TextView(this);
            text.setText(guidance.optString("text", ""));
            text.setTextSize(16);
            card.addView(text);
            page.addView(card);
        }

        Button confirm = Ui.primaryButton(this, "Importar e ativar alarmes");
        confirm.setOnClickListener(v -> importNow());
        page.addView(confirm);
        page.addView(Ui.space(this, 8));
        Button cancel = Ui.secondaryButton(this, "Cancelar");
        cancel.setOnClickListener(v -> finish());
        page.addView(cancel);
        setContentView(scroll);
    }

    private String previewPlan(JSONObject obj) {
        ArrayList<TreatmentPhase> phases = PlanStore.readPhases(obj);
        if (phases.isEmpty()) phases.add(new TreatmentPhase(0, PlanStore.readTimes(obj.optJSONArray("times"))));
        String start;
        String after = obj.optString("startsAfterMedicine", "");
        int delay = obj.optInt("startDelayDays", 0);
        if (!after.isEmpty()) start = "Inicia após " + after;
        else if (delay > 0) start = "Inicia após " + delay + " dia(s)";
        else start = "Início imediato";
        return obj.optString("eye", "") + "\n" + start + "\n" + TreatmentText.phasesSummary(phases);
    }

    private void importNow() {
        JSONObject patient = imported.optJSONObject("patient");
        if (patient != null) {
            PatientProfileStore.save(this,
                    patient.optString("id", ""),
                    patient.optString("name", ""),
                    patient.optString("phone", ""));
            // Um protocolo nominal substitui a programação anterior do aparelho para evitar sobras de outro tratamento/paciente.
            for (MedicationPlan oldPlan : new ArrayList<>(PlanStore.getPlans(this))) {
                AlarmScheduler.cancelPlan(this, oldPlan);
                PlanStore.deletePlan(this, oldPlan.id);
            }
        }

        JSONArray plans = imported.optJSONArray("plans");
        ArrayList<MedicationPlan> importedPlans = new ArrayList<>();
        int importedCount = 0;
        long anchor = System.currentTimeMillis();
        if (plans != null) {
            for (int i = 0; i < plans.length(); i++) {
                JSONObject obj = plans.optJSONObject(i);
                if (obj == null) continue;
                String medicine = obj.optString("medicine", "").trim();
                String eye = obj.optString("eye", "Ambos os olhos");
                ArrayList<TreatmentPhase> phases = PlanStore.readPhases(obj);
                if (phases.isEmpty()) phases.add(new TreatmentPhase(0, PlanStore.readTimes(obj.optJSONArray("times"))));
                boolean hasTime = false;
                for (TreatmentPhase p : phases) if (!p.times.isEmpty()) hasTime = true;
                if (medicine.isEmpty() || !hasTime) continue;

                int delay = Math.max(0, obj.optInt("startDelayDays", 0));
                String after = obj.optString("startsAfterMedicine", "");
                MedicationPlan old = PlanStore.getPlanForMedicine(this, medicine);
                if (old != null) AlarmScheduler.cancelPlan(this, old);
                MedicationPlan plan = old == null
                        ? new MedicationPlan(medicine, eye, phases, delay, after, anchor)
                        : new MedicationPlan(old.id, medicine, eye, phases, delay, after, anchor);
                PlanStore.savePlan(this, plan);
                importedPlans.add(plan);
                importedCount++;
            }
            for (MedicationPlan plan : importedPlans) AlarmScheduler.schedulePlan(this, plan);
        }

        JSONObject guidance = imported.optJSONObject("guidance");
        if (guidance != null && !guidance.optString("text", "").trim().isEmpty()) {
            String internalTitle = guidance.optString("title", "Orientações");
            if (internalTitle.trim().isEmpty()) internalTitle = "Orientações";
            GuidanceStore.importAndActivate(this, internalTitle, guidance.optString("text", ""));
        } else GuidanceStore.clearActive(this);

        String patientName = PatientProfileStore.getFirstName(this);
        String message = importedCount + " colírio(s) importado(s).";
        if (!patientName.isEmpty()) message += " Programação ativada para " + patientName + ".";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        finish();
    }
}
