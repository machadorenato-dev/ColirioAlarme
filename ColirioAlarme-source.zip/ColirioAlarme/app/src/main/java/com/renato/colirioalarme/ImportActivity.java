package com.renato.colirioalarme;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class ImportActivity extends Activity {
    private JSONObject imported;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Uri uri = getIntent().getData();
        String extraUri = getIntent().getStringExtra("uri");
        if (uri == null && extraUri != null) uri = Uri.parse(extraUri);
        if (uri == null) {
            Toast.makeText(this, "Arquivo de programação não encontrado.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        try {
            imported = new JSONObject(readAll(uri));
            if (!ProgramTransfer.MARKER.equals(imported.optString("app"))) throw new Exception("Arquivo não reconhecido");
            buildScreen();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir esta programação.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private String readAll(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("sem conteúdo");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        page.addView(Ui.title(this, "Importar programação"));
        page.addView(Ui.subtitle(this, "Confira os colírios e o olho antes de confirmar."));

        JSONArray plans = imported.optJSONArray("plans");
        if (plans != null) {
            for (int i = 0; i < plans.length(); i++) {
                JSONObject obj = plans.optJSONObject(i);
                if (obj == null) continue;
                LinearLayout card = Ui.card(this);
                TextView name = new TextView(this);
                name.setText(obj.optString("medicine", "Colírio"));
                name.setTextSize(19);
                name.setTypeface(null, android.graphics.Typeface.BOLD);
                card.addView(name);
                TextView details = new TextView(this);
                details.setText(obj.optString("eye", "") + " • " + timesText(obj.optJSONArray("times")));
                details.setTextSize(16);
                details.setTextColor(Ui.MUTED);
                card.addView(details);
                page.addView(card);
            }
        }

        JSONObject guidance = imported.optJSONObject("guidance");
        if (guidance != null) {
            page.addView(Ui.sectionTitle(this, "Orientações pós-operatórias"));
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(guidance.optString("title", "Orientações"));
            title.setTextSize(18);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            card.addView(title);
            TextView text = new TextView(this);
            text.setText(guidance.optString("text", ""));
            text.setTextSize(16);
            text.setPadding(0, Ui.dp(this, 6), 0, 0);
            card.addView(text);
            page.addView(card);
        }

        Button confirm = Ui.primaryButton(this, "Importar e ativar alarmes");
        confirm.setOnClickListener(v -> importNow());
        page.addView(confirm);
        page.addView(Ui.space(this, 8));
        Button cancel = Ui.secondaryButton(this, "Cancelar");
        cancel.setOnClickListener(v -> finish());
        page.addView(cancel);
        setContentView(scroll);
    }

    private String timesText(JSONArray arr) {
        if (arr == null) return "Sem horários";
        ArrayList<String> values = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            String t = arr.optString(i, "");
            if (!t.isEmpty()) values.add(t);
        }
        return String.join(" | ", values);
    }

    private void importNow() {
        JSONArray plans = imported.optJSONArray("plans");
        int importedCount = 0;
        if (plans != null) {
            for (int i = 0; i < plans.length(); i++) {
                JSONObject obj = plans.optJSONObject(i);
                if (obj == null) continue;
                String medicine = obj.optString("medicine", "").trim();
                String eye = obj.optString("eye", "Ambos os olhos");
                JSONArray timesJson = obj.optJSONArray("times");
                ArrayList<String> times = new ArrayList<>();
                if (timesJson != null) {
                    for (int j = 0; j < timesJson.length(); j++) {
                        String time = timesJson.optString(j, "");
                        if (!time.isEmpty()) times.add(time);
                    }
                }
                if (medicine.isEmpty() || times.isEmpty()) continue;
                MedicationPlan old = PlanStore.getPlanForMedicine(this, medicine);
                if (old != null) AlarmScheduler.cancelPlan(this, old);
                MedicationPlan plan = old == null
                        ? new MedicationPlan(medicine, eye, times)
                        : new MedicationPlan(old.id, medicine, eye, times);
                PlanStore.savePlan(this, plan);
                AlarmScheduler.schedulePlan(this, plan);
                importedCount++;
            }
        }
        JSONObject guidance = imported.optJSONObject("guidance");
        if (guidance != null) {
            GuidanceStore.importAndActivate(this, guidance.optString("title", ""), guidance.optString("text", ""));
        }
        Toast.makeText(this, importedCount + " colírio(s) importado(s).", Toast.LENGTH_LONG).show();
        finish();
    }
}
