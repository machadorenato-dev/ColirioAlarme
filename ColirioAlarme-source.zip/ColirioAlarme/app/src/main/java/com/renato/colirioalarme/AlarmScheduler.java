package com.renato.colirioalarme;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public final class AlarmScheduler {
    private AlarmScheduler() {}

    public static void schedulePlan(Context context, MedicationPlan plan) {
        for (String time : plan.times) schedule(context, plan, time);
    }

    public static void cancelPlan(Context context, MedicationPlan plan) {
        for (String time : plan.times) cancel(context, plan, time);
    }

    public static void scheduleAll(Context context) {
        for (MedicationPlan plan : PlanStore.getPlans(context)) schedulePlan(context, plan);
    }


    public static void snooze(Context context, String planId, String medicine, String eye, String originalTime, int minutes) {
        Calendar when = Calendar.getInstance();
        when.add(Calendar.MINUTE, minutes);

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("planId", planId);
        intent.putExtra("medicine", medicine);
        intent.putExtra("eye", eye);
        intent.putExtra("time", originalTime);
        intent.putExtra("snooze", true);
        int requestCode = ("snooze|" + planId + "|" + medicine + "|" + System.currentTimeMillis()).hashCode() & 0x7fffffff;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pendingIntent);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pendingIntent);
        } else {
            manager.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pendingIntent);
        }
    }

    private static void schedule(Context context, MedicationPlan plan, String time) {
        String[] parts = time.split(":");
        if (parts.length != 2) return;
        int hour;
        int minute;
        try {
            hour = Integer.parseInt(parts[0]);
            minute = Integer.parseInt(parts[1]);
        } catch (Exception e) {
            return;
        }

        Calendar when = Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY, hour);
        when.set(Calendar.MINUTE, minute);
        when.set(Calendar.SECOND, 0);
        when.set(Calendar.MILLISECOND, 0);
        if (when.getTimeInMillis() <= System.currentTimeMillis()) {
            when.add(Calendar.DAY_OF_YEAR, 1);
        }

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pendingIntent = alarmPendingIntent(context, plan, time, PendingIntent.FLAG_UPDATE_CURRENT);
        if (manager == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pendingIntent);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pendingIntent);
        } else {
            manager.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pendingIntent);
        }
    }

    private static void cancel(Context context, MedicationPlan plan, String time) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pendingIntent = alarmPendingIntent(context, plan, time, PendingIntent.FLAG_NO_CREATE);
        if (manager != null && pendingIntent != null) {
            manager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }

    private static PendingIntent alarmPendingIntent(Context context, MedicationPlan plan, String time, int extraFlag) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("planId", plan.id);
        intent.putExtra("medicine", plan.medicine);
        intent.putExtra("eye", plan.eye);
        intent.putExtra("time", time);
        int requestCode = (plan.id + "|" + time).hashCode() & 0x7fffffff;
        int flags = extraFlag | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }
}
