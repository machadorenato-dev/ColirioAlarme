package com.renato.colirioalarme;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public class AlarmScheduler {
    public static void schedule(Context context, Reminder r) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Calendar when = Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY, r.hour);
        when.set(Calendar.MINUTE, r.minute);
        when.set(Calendar.SECOND, 0);
        when.set(Calendar.MILLISECOND, 0);
        if (when.getTimeInMillis() <= System.currentTimeMillis()) when.add(Calendar.DAY_OF_YEAR, 1);

        Intent i = new Intent(context, AlarmReceiver.class);
        i.putExtra("id", r.id);
        i.putExtra("name", r.name);
        i.putExtra("hour", r.hour);
        i.putExtra("minute", r.minute);
        i.putExtra("message", r.message);
        PendingIntent pi = PendingIntent.getBroadcast(context, r.id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        }
    }

    public static void cancel(Context context, int id) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, id, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (am != null && pi != null) {
            am.cancel(pi);
            pi.cancel();
        }
    }

    public static void scheduleAll(Context context) {
        for (Reminder r : ReminderStore.getAll(context)) schedule(context, r);
    }
}
