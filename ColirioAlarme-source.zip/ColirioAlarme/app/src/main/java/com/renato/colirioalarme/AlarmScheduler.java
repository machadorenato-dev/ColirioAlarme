package com.renato.colirioalarme;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class AlarmScheduler {
    private AlarmScheduler() {}

    public static void schedulePlan(Context context, MedicationPlan plan) {
        if (plan == null) return;
        cancelCurrentPlanAlarm(context, plan.id);
        cancelOldV4PlanAlarm(context, plan.id);
        TreatmentUtils.NextDose next = TreatmentUtils.nextDose(context, plan, System.currentTimeMillis());
        if (next == null) return;

        Intent intent = alarmBroadcastIntent(context, plan.id, plan.medicine, plan.eye, next.time);
        intent.putExtra("phaseIndex", next.phaseIndex);
        PendingIntent pending = PendingIntent.getBroadcast(
                context, planRequestCode(plan.id), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, next.whenMillis, pending);
    }

    public static void cancelPlan(Context context, MedicationPlan plan) {
        if (plan == null) return;
        cancelCurrentPlanAlarm(context, plan.id);
        cancelOldV4PlanAlarm(context, plan.id);
        cancelUnanswered(context, plan.id, null);
        for (String time : plan.allTimes()) cancelLegacy(context, plan.id, time);
    }

    public static void scheduleAll(Context context) {
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            for (String time : plan.allTimes()) cancelLegacy(context, plan.id, time);
            cancelOldV4PlanAlarm(context, plan.id);
            schedulePlan(context, plan);
        }
    }

    public static void rescheduleDependents(Context context, String medicine) {
        if (medicine == null) return;
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            if (plan.startsAfterMedicine != null && plan.startsAfterMedicine.equalsIgnoreCase(medicine)) {
                schedulePlan(context, plan);
            }
        }
    }

    public static void snooze(Context context, String planId, String medicine, String eye,
                              String originalTime, int minutes) {
        Calendar when = Calendar.getInstance();
        when.add(Calendar.MINUTE, minutes);
        Intent intent = alarmBroadcastIntent(context, planId, medicine, eye, originalTime);
        intent.putExtra("snooze", true);
        int requestCode = ("snooze-v6|" + planId + "|" + originalTime + "|" + System.currentTimeMillis()).hashCode() & 0x7fffffff;
        PendingIntent pending = PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, when.getTimeInMillis(), pending);
    }

    public static void scheduleUnanswered(Context context, String planId, String medicine,
                                          String eye, String originalTime, boolean test) {
        cancelUnanswered(context, planId, originalTime);
        Calendar when = Calendar.getInstance();
        when.add(Calendar.MINUTE, 1);
        Intent intent = alarmBroadcastIntent(context, planId, medicine, eye, originalTime);
        intent.putExtra("unanswered", true);
        intent.putExtra("test", test);
        PendingIntent pending = PendingIntent.getBroadcast(context,
                unansweredCode(planId), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, when.getTimeInMillis(), pending);
    }

    public static void cancelUnanswered(Context context, String planId, String originalTime) {
        if (planId == null) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = PendingIntent.getBroadcast(context, unansweredCode(planId),
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && p != null) { manager.cancel(p); p.cancel(); }

        // Limpa também os repetidores da V4/V5 após atualização.
        PendingIntent oldActivity = PendingIntent.getActivity(context, oldUnansweredCode(planId),
                new Intent(context, AlarmActivity.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && oldActivity != null) { manager.cancel(oldActivity); oldActivity.cancel(); }
        PendingIntent oldFallback = PendingIntent.getBroadcast(context, oldUnansweredFallbackCode(planId),
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && oldFallback != null) { manager.cancel(oldFallback); oldFallback.cancel(); }
    }

    public static void scheduleTest(Context context, int minutes) {
        Calendar when = Calendar.getInstance();
        when.add(Calendar.MINUTE, minutes);
        String time = new SimpleDateFormat("HH:mm", new Locale("pt", "BR")).format(new Date(when.getTimeInMillis()));
        Intent intent = alarmBroadcastIntent(context, "test-v6", "Colírio de teste", "Olho direito", time);
        intent.putExtra("test", true);
        PendingIntent pending = PendingIntent.getBroadcast(context, testCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, when.getTimeInMillis(), pending);
    }

    private static Intent alarmBroadcastIntent(Context context, String planId, String medicine, String eye, String time) {
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("planId", planId);
        intent.putExtra("medicine", medicine);
        intent.putExtra("eye", eye);
        intent.putExtra("time", time);
        return intent;
    }

    private static void setExact(Context context, long millis, PendingIntent pending) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending);
            } else {
                manager.setExact(AlarmManager.RTC_WAKEUP, millis, pending);
            }
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending);
            } else {
                manager.set(AlarmManager.RTC_WAKEUP, millis, pending);
            }
        }
    }

    private static void cancelCurrentPlanAlarm(Context context, String planId) {
        if (planId == null) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = PendingIntent.getBroadcast(context, planRequestCode(planId),
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && p != null) { manager.cancel(p); p.cancel(); }
    }

    private static void cancelOldV4PlanAlarm(Context context, String planId) {
        if (planId == null) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        int activityCode = ("plan-v4|" + planId).hashCode() & 0x7fffffff;
        int fallbackCode = ("plan-fallback-v4|" + planId).hashCode() & 0x7fffffff;
        PendingIntent oldActivity = PendingIntent.getActivity(context, activityCode,
                new Intent(context, AlarmActivity.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && oldActivity != null) { manager.cancel(oldActivity); oldActivity.cancel(); }
        PendingIntent oldFallback = PendingIntent.getBroadcast(context, fallbackCode,
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && oldFallback != null) { manager.cancel(oldFallback); oldFallback.cancel(); }
    }

    private static void cancelLegacy(Context context, String planId, String time) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        int code = (planId + "|" + time).hashCode() & 0x7fffffff;
        PendingIntent p = PendingIntent.getBroadcast(context, code,
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && p != null) { manager.cancel(p); p.cancel(); }
    }

    private static int planRequestCode(String planId) {
        return ("plan-v6|" + planId).hashCode() & 0x7fffffff;
    }

    private static int unansweredCode(String planId) {
        return ("unanswered-v6|" + String.valueOf(planId)).hashCode() & 0x7fffffff;
    }

    private static int oldUnansweredCode(String planId) {
        return ("unanswered-v4|" + String.valueOf(planId)).hashCode() & 0x7fffffff;
    }

    private static int oldUnansweredFallbackCode(String planId) {
        return ("unanswered-fallback-v4|" + String.valueOf(planId)).hashCode() & 0x7fffffff;
    }

    private static int testCode() {
        return 0x600600;
    }
}
