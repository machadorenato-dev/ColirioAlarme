package com.renato.colirioalarme;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public final class AlarmScheduler {
    private AlarmScheduler() {}

    public static void schedulePlan(Context context, MedicationPlan plan) {
        if (plan == null) return;
        cancelCurrentPlanAlarm(context, plan.id);
        TreatmentUtils.NextDose next = TreatmentUtils.nextDose(context, plan, System.currentTimeMillis());
        if (next == null) return;

        Intent intent = alarmActivityIntent(context, plan.id, plan.medicine, plan.eye, next.time);
        intent.putExtra("phaseIndex", next.phaseIndex);
        PendingIntent pending = PendingIntent.getActivity(
                context, planRequestCode(plan.id), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent fallbackIntent = new Intent(context, AlarmReceiver.class);
        fallbackIntent.putExtra("planId", plan.id);
        fallbackIntent.putExtra("medicine", plan.medicine);
        fallbackIntent.putExtra("eye", plan.eye);
        fallbackIntent.putExtra("time", next.time);
        fallbackIntent.putExtra("pairedFallback", true);
        PendingIntent fallback = PendingIntent.getBroadcast(context, planFallbackCode(plan.id), fallbackIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, next.whenMillis, pending);
        setExact(context, next.whenMillis, fallback);
    }

    public static void cancelPlan(Context context, MedicationPlan plan) {
        if (plan == null) return;
        cancelCurrentPlanAlarm(context, plan.id);
        cancelUnanswered(context, plan.id, null);
        for (String time : plan.allTimes()) cancelLegacy(context, plan.id, time);
    }

    public static void scheduleAll(Context context) {
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            for (String time : plan.allTimes()) cancelLegacy(context, plan.id, time);
            schedulePlan(context, plan);
        }
    }

    public static void rescheduleDependents(Context context, String medicine) {
        if (medicine == null) return;
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            if (plan.startsAfterMedicine != null && plan.startsAfterMedicine.equalsIgnoreCase(medicine)) {
                schedulePlan(context, plan);
            }
        }
    }

    public static void snooze(Context context, String planId, String medicine, String eye,
                              String originalTime, int minutes) {
        Calendar when = Calendar.getInstance();
        when.add(Calendar.MINUTE, minutes);
        Intent intent = alarmActivityIntent(context, planId, medicine, eye, originalTime);
        intent.putExtra("snooze", true);
        int requestCode = ("snooze|" + planId + "|" + originalTime + "|" + System.currentTimeMillis()).hashCode() & 0x7fffffff;
        PendingIntent pending = PendingIntent.getActivity(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent fallbackIntent = new Intent(context, AlarmReceiver.class);
        fallbackIntent.putExtra("planId", planId);
        fallbackIntent.putExtra("medicine", medicine);
        fallbackIntent.putExtra("eye", eye);
        fallbackIntent.putExtra("time", originalTime);
        fallbackIntent.putExtra("snooze", true);
        fallbackIntent.putExtra("pairedFallback", true);
        PendingIntent fallback = PendingIntent.getBroadcast(context, requestCode ^ 0x13579, fallbackIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, when.getTimeInMillis(), pending);
        setExact(context, when.getTimeInMillis(), fallback);
    }

    public static void scheduleUnanswered(Context context, String planId, String medicine,
                                          String eye, String originalTime) {
        cancelUnanswered(context, planId, originalTime);
        Calendar when = Calendar.getInstance();
        when.add(Calendar.MINUTE, 1);
        Intent intent = alarmActivityIntent(context, planId, medicine, eye, originalTime);
        intent.putExtra("unanswered", true);
        PendingIntent pending = PendingIntent.getActivity(context,
                unansweredCode(planId), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent fallbackIntent = new Intent(context, AlarmReceiver.class);
        fallbackIntent.putExtra("planId", planId);
        fallbackIntent.putExtra("medicine", medicine);
        fallbackIntent.putExtra("eye", eye);
        fallbackIntent.putExtra("time", originalTime);
        fallbackIntent.putExtra("unanswered", true);
        fallbackIntent.putExtra("pairedFallback", true);
        PendingIntent fallback = PendingIntent.getBroadcast(context, unansweredFallbackCode(planId), fallbackIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setExact(context, when.getTimeInMillis(), pending);
        setExact(context, when.getTimeInMillis(), fallback);
    }

    public static void cancelUnanswered(Context context, String planId, String originalTime) {
        if (planId == null) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = PendingIntent.getActivity(context, unansweredCode(planId),
                new Intent(context, AlarmActivity.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && p != null) { manager.cancel(p); p.cancel(); }
        PendingIntent fallback = PendingIntent.getBroadcast(context, unansweredFallbackCode(planId),
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && fallback != null) { manager.cancel(fallback); fallback.cancel(); }
    }

    private static Intent alarmActivityIntent(Context context, String planId, String medicine, String eye, String time) {
        Intent intent = new Intent(context, AlarmActivity.class);
        intent.putExtra("planId", planId);
        intent.putExtra("medicine", medicine);
        intent.putExtra("eye", eye);
        intent.putExtra("time", time);
        intent.putExtra("fromAlarm", true);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        return intent;
    }

    private static void setExact(Context context, long millis, PendingIntent pending) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pending);
        } else {
            manager.setExact(AlarmManager.RTC_WAKEUP, millis, pending);
        }
    }

    private static void cancelCurrentPlanAlarm(Context context, String planId) {
        if (planId == null) return;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = PendingIntent.getActivity(context, planRequestCode(planId),
                new Intent(context, AlarmActivity.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && p != null) { manager.cancel(p); p.cancel(); }
        PendingIntent fallback = PendingIntent.getBroadcast(context, planFallbackCode(planId),
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && fallback != null) { manager.cancel(fallback); fallback.cancel(); }
    }

    private static void cancelLegacy(Context context, String planId, String time) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        int code = (planId + "|" + time).hashCode() & 0x7fffffff;
        PendingIntent p = PendingIntent.getBroadcast(context, code,
                new Intent(context, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (manager != null && p != null) { manager.cancel(p); p.cancel(); }
    }

    private static int planRequestCode(String planId) {
        return ("plan-v4|" + planId).hashCode() & 0x7fffffff;
    }

    private static int planFallbackCode(String planId) {
        return ("plan-fallback-v4|" + planId).hashCode() & 0x7fffffff;
    }

    private static int unansweredCode(String planId) {
        return ("unanswered-v4|" + String.valueOf(planId)).hashCode() & 0x7fffffff;
    }

    private static int unansweredFallbackCode(String planId) {
        return ("unanswered-fallback-v4|" + String.valueOf(planId)).hashCode() & 0x7fffffff;
    }
}
