package com.renato.colirioalarme;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

public class AlarmService extends Service {
    public static final String CHANNEL_ID = "colirio_alarm_channel_v4";
    public static final int NOTIFICATION_ID = 4107;
    private TextToSpeech tts;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String medicine = intent != null ? intent.getStringExtra("medicine") : null;
        String eye = intent != null ? intent.getStringExtra("eye") : null;
        String time = intent != null ? intent.getStringExtra("time") : null;
        String planId = intent != null ? intent.getStringExtra("planId") : null;
        if (medicine == null || medicine.trim().isEmpty()) medicine = "colírio";
        if (eye == null || eye.trim().isEmpty()) eye = "Ambos os olhos";
        if (time == null || time.trim().isEmpty()) time = "Agora";

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification(medicine, eye, time, planId));
        String phrase = "Está na hora do seu colírio " + medicine + ", "
                + eye.toLowerCase(new Locale("pt", "BR")) + ".";
        speak(phrase);
        // O serviço permanece até o paciente tocar em FEITO ou ADIAR.
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String medicine, String eye, String time, String planId) {
        Intent alarmScreen = new Intent(this, AlarmActivity.class);
        alarmScreen.putExtra("medicine", medicine);
        alarmScreen.putExtra("eye", eye);
        alarmScreen.putExtra("time", time);
        alarmScreen.putExtra("planId", planId);
        alarmScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int code = (medicine + "|" + eye + "|" + time).hashCode() & 0x7fffffff;
        PendingIntent fullScreen = PendingIntent.getActivity(this, code, alarmScreen,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Hora do colírio: " + medicine)
                .setContentText(eye + " • " + time + " • toque para responder")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(fullScreen)
                .setFullScreenIntent(fullScreen, true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Alarmes dos colírios", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Alarmes em tela cheia dos horários programados para os colírios");
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void speak(String phrase) {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setLanguage(new Locale("pt", "BR"));
                tts.setSpeechRate(0.95f);
                tts.setPitch(1.0f);
                tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "colirio_alarm");
            }
        });
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
