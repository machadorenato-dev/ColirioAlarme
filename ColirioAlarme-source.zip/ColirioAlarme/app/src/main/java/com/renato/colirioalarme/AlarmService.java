package com.renato.colirioalarme;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

public class AlarmService extends Service implements TextToSpeech.OnInitListener {
    private static final String CHANNEL_ID = "colirio_alarm_channel";
    private TextToSpeech tts;
    private String phrase = "Está na hora do seu colírio";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(this, this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String name = intent == null ? null : intent.getStringExtra("name");
        String custom = intent == null ? null : intent.getStringExtra("message");
        if (custom != null && !custom.trim().isEmpty()) phrase = custom.trim();
        else if (name != null && !name.trim().isEmpty()) phrase = "Está na hora do seu colírio " + name;

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 9001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.renato.colirioalarme.R.drawable.ic_launcher)
                .setContentTitle("Hora do colírio")
                .setContentText(phrase)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .build();
        startForeground(1001, notification);
        return START_NOT_STICKY;
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("pt", "BR"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault());
            }
            tts.setSpeechRate(0.95f);
            tts.setPitch(1.0f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) { stopSelf(); }
                @Override public void onError(String utteranceId) { stopSelf(); }
            });
            tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "colirio_alarm");
        } else {
            stopSelf();
        }
    }

    @Override public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Alarmes de colírio", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Avisos de horário dos colírios");
        channel.enableVibration(true);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }
}
