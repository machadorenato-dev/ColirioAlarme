package com.renato.colirioalarme;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class AlarmService extends Service {
    // Canal novo para que configurações antigas do canal da V4/V5 não impeçam o alerta máximo.
    public static final String CHANNEL_ID = "colirio_alarm_channel_v6";
    public static final int NOTIFICATION_ID = 6107;

    private TextToSpeech tts;
    private WindowManager windowManager;
    private LinearLayout overlayView;
    private String medicine;
    private String eye;
    private String time;
    private String planId;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        medicine = intent != null ? intent.getStringExtra("medicine") : null;
        eye = intent != null ? intent.getStringExtra("eye") : null;
        time = intent != null ? intent.getStringExtra("time") : null;
        planId = intent != null ? intent.getStringExtra("planId") : null;
        if (medicine == null || medicine.trim().isEmpty()) medicine = "colírio";
        if (eye == null || eye.trim().isEmpty()) eye = "Ambos os olhos";
        if (time == null || time.trim().isEmpty()) time = "Agora";

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification(medicine, eye, time, planId));
        showOverlayIfPossible();

        String phrase = "Está na hora do seu colírio " + medicine + ", "
                + eye.toLowerCase(new Locale("pt", "BR")) + ".";
        speak(phrase);
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String medicine, String eye, String time, String planId) {
        Intent alarmScreen = new Intent(this, AlarmActivity.class);
        alarmScreen.putExtra("medicine", medicine);
        alarmScreen.putExtra("eye", eye);
        alarmScreen.putExtra("time", time);
        alarmScreen.putExtra("planId", planId);
        alarmScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        int code = ("v6|" + medicine + "|" + eye + "|" + time).hashCode() & 0x7fffffff;
        PendingIntent fullScreen = PendingIntent.getActivity(this, code, alarmScreen,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Hora do colírio: " + medicine)
                .setContentText(eye + " • " + time + " • toque para responder")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(fullScreen)
                .setFullScreenIntent(fullScreen, true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Alarmes dos colírios", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Alarmes prioritários dos horários programados para os colírios");
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showOverlayIfPossible() {
        removeOverlay();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || !Settings.canDrawOverlays(this)) return;

        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km != null && km.isKeyguardLocked()) return;

        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) return;

            overlayView = buildOverlayView();
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            windowManager.addView(overlayView, params);
        } catch (Exception ignored) {
            overlayView = null;
        }
    }

    private LinearLayout buildOverlayView() {
        LinearLayout page = Ui.verticalPage(this);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.addView(Ui.space(this, 45));

        TextView heading = Ui.title(this, "Hora do colírio");
        heading.setGravity(Gravity.CENTER);
        page.addView(heading);

        TextView name = new TextView(this);
        name.setText(medicine);
        name.setTextSize(34);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setTextColor(Ui.BLUE_DARK);
        name.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 12));
        page.addView(name);

        TextView eyeText = new TextView(this);
        eyeText.setText(eye);
        eyeText.setTextSize(26);
        eyeText.setGravity(Gravity.CENTER);
        eyeText.setTextColor(Ui.TEXT);
        page.addView(eyeText);

        TextView timeText = new TextView(this);
        timeText.setText(time);
        timeText.setTextSize(23);
        timeText.setGravity(Gravity.CENTER);
        timeText.setTextColor(Ui.MUTED);
        timeText.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 34));
        page.addView(timeText);

        Button done = Ui.primaryButton(this, "FEITO");
        done.setTextSize(24);
        done.setMinHeight(Ui.dp(this, 78));
        done.setOnClickListener(v -> doneFromOverlay());
        page.addView(done);
        page.addView(Ui.space(this, 16));

        Button snooze = Ui.secondaryButton(this, "ADIAR 10 MIN");
        snooze.setTextSize(22);
        snooze.setMinHeight(Ui.dp(this, 78));
        snooze.setOnClickListener(v -> snoozeFromOverlay());
        page.addView(snooze);

        TextView reminder = Ui.subtitle(this,
                "Se nenhuma opção for escolhida, o alarme tocará novamente em 1 minuto.");
        reminder.setGravity(Gravity.CENTER);
        reminder.setPadding(0, Ui.dp(this, 22), 0, 0);
        page.addView(reminder);
        return page;
    }

    private void doneFromOverlay() {
        DoseLog.add(this, medicine, eye, time, "FEITO");
        dismissFromOverlay();
    }

    private void snoozeFromOverlay() {
        AlarmScheduler.cancelUnanswered(this, planId, time);
        AlarmScheduler.snooze(this, planId, medicine, eye, time, 10);
        DoseLog.add(this, medicine, eye, time, "ADIADO");
        Toast.makeText(this, "Alarme adiado por 10 minutos.", Toast.LENGTH_SHORT).show();
        dismissFromOverlay();
    }

    private void dismissFromOverlay() {
        AlarmScheduler.cancelUnanswered(this, planId, time);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
        removeOverlay();
        stopSelf();
    }

    private void removeOverlay() {
        try {
            if (windowManager != null && overlayView != null) windowManager.removeView(overlayView);
        } catch (Exception ignored) {}
        overlayView = null;
        windowManager = null;
    }

    private void speak(String phrase) {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setLanguage(new Locale("pt", "BR"));
                tts.setSpeechRate(0.95f);
                tts.setPitch(1.0f);
                tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "colirio_alarm_v6");
            }
        });
    }

    @Override
    public void onDestroy() {
        removeOverlay();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        try { stopForeground(true); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
