package com.renato.colirioalarme;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

public class AlarmService extends Service {
    private static final String CHANNEL_ID = "colirio_alarm_channel";
    private static final int NOTIFICATION_ID = 4107;
    private TextToSpeech tts;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String medicine = intent != null ? intent.getStringExtra("medicine") : null;
        String eye = intent != null ? intent.getStringExtra("eye") : null;
        if (medicine == null || medicine.trim().isEmpty()) medicine = "colírio";
        if (eye == null || eye.trim().isEmpty()) eye = "ambos os olhos";

        createChannel();
        String phrase = "Está na hora do seu colírio " + medicine + ", " + eye.toLowerCase(new Locale("pt", "BR")) + ".";
        startForeground(NOTIFICATION_ID, buildNotification(medicine, eye));
        speak(phrase);
        new Handler(Looper.getMainLooper()).postDelayed(this::stopSelf, 45000);
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String medicine, String eye) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setSmallIcon(com.renato.colirioalarme.R.drawable.ic_launcher)
                .setContentTitle("Hora do colírio")
                .setContentText(medicine + " • " + eye)
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Avisos de horário dos colírios", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Alarmes dos horários programados para os colírios");
            channel.enableVibration(true);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void speak(String phrase) {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setLanguage(new Locale("pt", "BR"));
                tts.setSpeechRate(0.95f);
                tts.setPitch(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) { stopSelf(); }
                    @Override public void onError(String utteranceId) { stopSelf(); }
                });
                tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "colirio_alarm");
            } else {
                stopSelf();
            }
        });
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
