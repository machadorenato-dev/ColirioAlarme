package com.renato.colirioalarme;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Gera uma receita simples em PDF usando o protocolo/programação atual do paciente. */
public final class RecipePdfUtil {
    private static final int PAGE_W = 595;
    private static final int PAGE_H = 842;
    private static final float LEFT = 48f;
    private static final float RIGHT = 547f;
    private static final float TOP = 42f;
    private static final float BOTTOM = 790f;

    private RecipePdfUtil() {}

    public static byte[] buildForDoctor(Context context, Patient patient) throws Exception {
        if (patient == null) throw new Exception("Paciente inválido");
        DoctorRecipeProfileStore.Profile profile = DoctorRecipeProfileStore.get(context);
        if (profile.name.isEmpty() || profile.crm.isEmpty()) throw new Exception("Cadastre primeiro os dados da receita na Área do médico.");
        ArrayList<RecipeMedication> meds = new ArrayList<>();
        for (PatientAssignment assignment : patient.assignments) {
            for (ProtocolMedication med : assignment.medications) {
                meds.add(new RecipeMedication(med.medicine, assignment.eye,
                        startForProtocolMedication(med), TreatmentText.phasesSummary(med.phases)));
            }
        }
        return build(profile, patient.name, patient.surgeryType, patient.operatedEye,
                patient.surgeryDateMillis, meds);
    }

    public static byte[] buildForPatient(Context context) throws Exception {
        DoctorRecipeProfileStore.Profile profile = PatientRecipeProfileStore.get(context);
        if (profile.name.isEmpty() || profile.crm.isEmpty()) throw new Exception("Os dados profissionais do médico ainda não foram enviados para este aparelho.");
        ArrayList<RecipeMedication> meds = new ArrayList<>();
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            meds.add(new RecipeMedication(plan.medicine, plan.eye, TreatmentText.startSummary(plan),
                    TreatmentText.phasesSummary(plan.phases)));
        }
        return build(profile, PatientProfileStore.getName(context), PatientProfileStore.getSurgeryType(context),
                PatientProfileStore.getOperatedEye(context), PatientProfileStore.getSurgeryDateMillis(context), meds);
    }

    public static void write(Context context, Uri uri, byte[] pdf) throws Exception {
        if (uri == null || pdf == null) throw new Exception("Destino inválido");
        try (OutputStream out = context.getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) throw new Exception("Não foi possível criar o PDF");
            out.write(pdf);
            out.flush();
        }
    }

    public static String suggestedFileName(String patientName) {
        String clean = patientName == null ? "Paciente" : patientName.trim().replaceAll("[^A-Za-z0-9À-ÿ_-]+", "_");
        if (clean.isEmpty()) clean = "Paciente";
        return "Receita_" + clean + "_" + new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date()) + ".pdf";
    }

    private static byte[] build(DoctorRecipeProfileStore.Profile profile, String patientName, String surgeryType,
                                String operatedEye, long surgeryDateMillis, List<RecipeMedication> meds) throws Exception {
        PdfDocument pdf = new PdfDocument();
        Writer writer = new Writer(pdf, profile);
        writer.newPage();
        writer.header();

        writer.heading("RECEITA MÉDICA");
        writer.line("Paciente: " + safe(patientName), 13, true, Color.BLACK);
        if (!safe(surgeryType).isEmpty()) writer.line("Procedimento: " + safe(surgeryType), 11, false, Color.DKGRAY);
        if (!safe(operatedEye).isEmpty()) writer.line("Olho: " + safe(operatedEye), 11, false, Color.DKGRAY);
        if (surgeryDateMillis > 0) {
            String date = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(surgeryDateMillis));
            writer.line("Data da cirurgia: " + date, 11, false, Color.DKGRAY);
        }
        writer.gap(12);
        writer.rule();
        writer.gap(10);

        if (meds == null || meds.isEmpty()) {
            writer.paragraph("Nenhum medicamento programado para este paciente.", 12, false, Color.DKGRAY, 16);
        } else {
            int number = 1;
            for (RecipeMedication med : meds) {
                writer.ensure(92);
                writer.line(number + ". " + safe(med.name), 14, true, Color.BLACK);
                String eye = safe(med.eye);
                String start = safe(med.start);
                if (!eye.isEmpty() || !start.isEmpty()) {
                    String meta = eye;
                    if (!start.isEmpty()) meta += (meta.isEmpty() ? "" : " • ") + start;
                    writer.paragraph(meta, 10.5f, false, Color.DKGRAY, 14);
                }
                String schedule = safe(med.schedule);
                if (!schedule.isEmpty()) writer.paragraph(schedule, 11.5f, false, Color.rgb(24, 62, 145), 15);
                writer.gap(8);
                number++;
            }
        }

        writer.gap(10);
        writer.rule();
        writer.gap(10);
        writer.paragraph("Data de emissão: " + new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date()),
                10.5f, false, Color.DKGRAY, 14);
        writer.signatureBlock();
        writer.finish();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        pdf.writeTo(out);
        pdf.close();
        return out.toByteArray();
    }

    private static String startForProtocolMedication(ProtocolMedication med) {
        if (med == null) return "";
        if (med.startsAfterMedicine != null && !med.startsAfterMedicine.trim().isEmpty()) return "Inicia após o término de " + med.startsAfterMedicine;
        if (med.startDelayDays > 0) return "Inicia após " + med.startDelayDays + (med.startDelayDays == 1 ? " dia" : " dias");
        return "Inicia na data da cirurgia";
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }

    private static final class RecipeMedication {
        final String name, eye, start, schedule;
        RecipeMedication(String name, String eye, String start, String schedule) {
            this.name = name; this.eye = eye; this.start = start; this.schedule = schedule;
        }
    }

    private static final class Writer {
        final PdfDocument pdf;
        final DoctorRecipeProfileStore.Profile profile;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        PdfDocument.Page page;
        Canvas canvas;
        int pageNumber = 0;
        float y = TOP;

        Writer(PdfDocument pdf, DoctorRecipeProfileStore.Profile profile) { this.pdf = pdf; this.profile = profile; }

        void newPage() {
            if (page != null) pdf.finishPage(page);
            pageNumber++;
            page = pdf.startPage(new PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNumber).create());
            canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            y = TOP;
        }

        void header() {
            Bitmap logo = decode(profile.logoBase64);
            float textRight = RIGHT;
            if (logo != null) {
                float maxW = 130f, maxH = 68f;
                float scale = Math.min(maxW / logo.getWidth(), maxH / logo.getHeight());
                float w = logo.getWidth() * scale, h = logo.getHeight() * scale;
                canvas.drawBitmap(logo, null, new RectF(RIGHT - w, TOP, RIGHT, TOP + h), paint);
                textRight = RIGHT - w - 15;
                logo.recycle();
            }
            paint.setColor(Color.BLACK); paint.setTextSize(14); paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText(safe(profile.clinic).isEmpty() ? safe(profile.name) : safe(profile.clinic), LEFT, y + 14, paint);
            y += 22;
            paragraph(profile.name + (profile.crm.isEmpty() ? "" : " • " + profile.crm), 10.5f, false, Color.DKGRAY, 14, textRight);
            if (!profile.specialty.isEmpty()) paragraph(profile.specialty, 10.5f, false, Color.DKGRAY, 14, textRight);
            if (!profile.details.isEmpty()) paragraph(profile.details, 9.5f, false, Color.GRAY, 13, textRight);
            y = Math.max(y + 8, TOP + 82);
            rule(); gap(12);
        }

        void heading(String text) { line(text, 17, true, Color.BLACK); gap(10); }

        void line(String text, float size, boolean bold, int color) {
            ensure(size + 12);
            paint.setColor(color); paint.setTextSize(size);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
            canvas.drawText(text == null ? "" : text, LEFT, y + size, paint);
            y += size + 7;
        }

        void paragraph(String text, float size, boolean bold, int color, float lineHeight) { paragraph(text, size, bold, color, lineHeight, RIGHT); }

        void paragraph(String text, float size, boolean bold, int color, float lineHeight, float maxRight) {
            if (text == null || text.isEmpty()) return;
            paint.setColor(color); paint.setTextSize(size); paint.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
            String[] explicit = text.replace("\r", "").split("\n", -1);
            for (String rawLine : explicit) {
                List<String> wrapped = wrap(rawLine, paint, Math.max(80, maxRight - LEFT));
                if (wrapped.isEmpty()) wrapped.add("");
                for (String row : wrapped) {
                    ensure(lineHeight + 3);
                    canvas.drawText(row, LEFT, y + size, paint);
                    y += lineHeight;
                }
            }
        }

        void signatureBlock() {
            ensure(145);
            Bitmap sig = decode(profile.signatureBase64);
            if (sig != null) {
                float maxW = 180f, maxH = 68f;
                float scale = Math.min(maxW / sig.getWidth(), maxH / sig.getHeight());
                float w = sig.getWidth() * scale, h = sig.getHeight() * scale;
                canvas.drawBitmap(sig, null, new RectF(LEFT, y, LEFT + w, y + h), paint);
                y += h + 4;
                sig.recycle();
            } else {
                y += 34;
            }
            paint.setColor(Color.GRAY); paint.setStrokeWidth(1f);
            canvas.drawLine(LEFT, y, LEFT + 220, y, paint);
            y += 8;
            line(profile.name, 11, true, Color.BLACK);
            if (!profile.crm.isEmpty()) line(profile.crm, 10, false, Color.DKGRAY);
            if (!profile.specialty.isEmpty()) line(profile.specialty, 10, false, Color.DKGRAY);
        }

        void rule() { ensure(5); paint.setColor(Color.LTGRAY); paint.setStrokeWidth(1f); canvas.drawLine(LEFT, y, RIGHT, y, paint); y += 2; }
        void gap(float amount) { y += amount; }

        void ensure(float needed) {
            if (y + needed <= BOTTOM) return;
            newPage();
            header();
        }

        void finish() { if (page != null) { pdf.finishPage(page); page = null; } }

        static List<String> wrap(String text, Paint paint, float width) {
            ArrayList<String> rows = new ArrayList<>();
            String clean = text == null ? "" : text.trim();
            if (clean.isEmpty()) return rows;
            String[] words = clean.split("\\s+");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String candidate = line.length() == 0 ? word : line + " " + word;
                if (paint.measureText(candidate) <= width || line.length() == 0) {
                    line.setLength(0); line.append(candidate);
                } else {
                    rows.add(line.toString());
                    line.setLength(0); line.append(word);
                }
            }
            if (line.length() > 0) rows.add(line.toString());
            return rows;
        }

        static Bitmap decode(String base64) {
            if (base64 == null || base64.trim().isEmpty()) return null;
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            } catch (Exception ignored) { return null; }
        }
    }
}
