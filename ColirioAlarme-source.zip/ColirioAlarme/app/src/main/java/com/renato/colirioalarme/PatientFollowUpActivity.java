package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PatientFollowUpActivity extends Activity {
    private static final int OPEN_REPORT = 5101;
    private String patientId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        patientId = getIntent().getStringExtra("patientId");
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        Patient patient = PatientStore.getById(this, patientId);
        if (patient == null) { finish(); return; }

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Paciente");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Acompanhamento"));
        page.addView(Ui.subtitle(this, patient.name));

        Button importReport = Ui.primaryButton(this, "Importar acompanhamento do paciente");
        importReport.setOnClickListener(v -> chooseReport());
        page.addView(importReport);
        page.addView(Ui.space(this, 10));

        List<JSONObject> entries = new ArrayList<>(AdherenceStore.getEntries(this, patient.id));
        if (entries.isEmpty()) entries.addAll(DoseLog.getEntries(this, patient.id));
        int done = 0, delayed = 0, unanswered = 0;
        for (JSONObject entry : entries) {
            String status = entry.optString("status", "");
            if ("FEITO".equals(status)) done++;
            else if ("ADIADO".equals(status)) delayed++;
            else if ("SEM_RESPOSTA".equals(status)) unanswered++;
        }

        LinearLayout summary = Ui.card(this);
        TextView counts = new TextView(this);
        counts.setText("Feito: " + done + "   •   Adiado: " + delayed + "   •   Sem resposta: " + unanswered);
        counts.setTextSize(17);
        counts.setTextColor(Ui.TEXT);
        counts.setTypeface(null, android.graphics.Typeface.BOLD);
        summary.addView(counts);
        int totalActions = done + delayed + unanswered;
        if (totalActions > 0) {
            int adherence = Math.round(done * 100f / Math.max(1, done + unanswered));
            summary.addView(Ui.subtitle(this, "Doses confirmadas: aproximadamente " + adherence + "% dos registros feito/sem resposta."));
        }
        page.addView(summary);

        JSONArray reportedPlans = AdherenceStore.getPlans(this, patient.id);
        if (reportedPlans.length() > 0) {
            page.addView(Ui.sectionTitle(this, "Horários atuais no telefone do paciente"));
            for (int i = 0; i < reportedPlans.length(); i++) {
                JSONObject obj = reportedPlans.optJSONObject(i);
                if (obj == null) continue;
                LinearLayout scheduleCard = Ui.card(this);
                TextView med = new TextView(this);
                med.setText(obj.optString("medicine", "Colírio"));
                med.setTextSize(17);
                med.setTypeface(null, android.graphics.Typeface.BOLD);
                med.setTextColor(Ui.TEXT);
                scheduleCard.addView(med);
                ArrayList<TreatmentPhase> phases = PlanStore.readPhases(obj);
                if (phases.isEmpty()) phases.add(new TreatmentPhase(0, PlanStore.readTimes(obj.optJSONArray("times"))));
                scheduleCard.addView(Ui.subtitle(this, obj.optString("eye", "") + "\n" + TreatmentText.phasesSummary(phases)));
                page.addView(scheduleCard);
            }
        }

        if (entries.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this,
                    "Ainda não há dados recebidos. Na tela principal do paciente existe o botão “Enviar acompanhamento ao médico”. Após receber o arquivo, importe-o aqui."));
            page.addView(card);
        } else {
            page.addView(Ui.sectionTitle(this, "Registros mais recentes"));
            SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault());
            int limit = Math.min(entries.size(), 100);
            for (int i = 0; i < limit; i++) {
                JSONObject entry = entries.get(i);
                LinearLayout card = Ui.card(this);
                TextView title = new TextView(this);
                title.setText(entry.optString("medicine", "Colírio") + " — " + statusLabel(entry.optString("status", "")));
                title.setTextSize(17);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextColor(Ui.TEXT);
                card.addView(title);
                long timestamp = entry.optLong("timestamp", 0);
                String date = timestamp > 0 ? fmt.format(new Date(timestamp)) : "";
                card.addView(Ui.subtitle(this,
                        entry.optString("eye", "") + " • previsto " + entry.optString("time", "") +
                                (date.isEmpty() ? "" : " • registrado " + date)));
                page.addView(card);
            }
        }

        LinearLayout online = Ui.card(this);
        online.addView(Ui.subtitle(this,
                "Nesta V5 o acompanhamento entre aparelhos funciona por arquivo enviado pelo paciente. A sincronização automática em tempo real exigirá a configuração do serviço online/Firebase."));
        page.addView(online);
        setContentView(scroll);
    }

    private String statusLabel(String status) {
        if ("FEITO".equals(status)) return "FEITO";
        if ("ADIADO".equals(status)) return "ADIADO";
        if ("SEM_RESPOSTA".equals(status)) return "SEM RESPOSTA";
        return status;
    }

    private void chooseReport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, OPEN_REPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != OPEN_REPORT || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            JSONObject root = new JSONObject(readAll(data.getData()));
            if (!ProgramTransfer.MARKER.equals(root.optString("app")) || !"adherence".equals(root.optString("fileType"))) {
                throw new Exception("arquivo inválido");
            }
            JSONObject p = root.optJSONObject("patient");
            if (p == null || !patientId.equals(p.optString("id", ""))) {
                Toast.makeText(this, "Este acompanhamento pertence a outro paciente.", Toast.LENGTH_LONG).show();
                return;
            }
            JSONArray logs = root.optJSONArray("doseLog");
            JSONArray plans = root.optJSONArray("plans");
            AdherenceStore.saveReport(this, patientId,
                    logs == null ? new JSONArray() : logs,
                    plans == null ? new JSONArray() : plans);
            Toast.makeText(this, "Acompanhamento atualizado.", Toast.LENGTH_LONG).show();
            render();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível importar este acompanhamento.", Toast.LENGTH_LONG).show();
        }
    }

    private String readAll(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("sem conteúdo");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
