package com.renato.colirioalarme;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.Locale;

/** Utilitários para o acesso do paciente. A senha nunca é armazenada em texto aberto. */
public final class PatientAccessUtil {
    private static final String TOKEN_PREFIX = "pw_";

    private PatientAccessUtil() {}

    public static String hashPassword(String password) {
        return sha256(password == null ? "" : password);
    }

    public static String tokenFor(String patientName, String password) {
        return tokenFromHash(patientName, hashPassword(password));
    }

    public static String tokenFromHash(String patientName, String passwordHash) {
        if (passwordHash == null || passwordHash.trim().isEmpty()) return "";
        return TOKEN_PREFIX + sha256(normalizeName(patientName) + ":" + passwordHash.trim());
    }

    public static void setPassword(Patient patient, String password) {
        if (patient == null) return;
        patient.passwordHash = hashPassword(password);
        patient.linkToken = tokenFromHash(patient.name, patient.passwordHash);
    }

    public static void refreshTokenForName(Patient patient) {
        if (patient == null || patient.passwordHash == null || patient.passwordHash.isEmpty()) return;
        patient.linkToken = tokenFromHash(patient.name, patient.passwordHash);
    }

    public static boolean hasPassword(Patient patient) {
        return patient != null && patient.passwordHash != null && !patient.passwordHash.isEmpty()
                && patient.linkToken != null && patient.linkToken.startsWith(TOKEN_PREFIX);
    }

    public static boolean sameName(String a, String b) {
        return normalizeName(a).equals(normalizeName(b));
    }

    public static String normalizeName(String value) {
        String v = value == null ? "" : value.trim().toLowerCase(new Locale("pt", "BR"));
        v = Normalizer.normalize(v, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return v.replaceAll("\\s+", " ");
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format(Locale.US, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception e) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
