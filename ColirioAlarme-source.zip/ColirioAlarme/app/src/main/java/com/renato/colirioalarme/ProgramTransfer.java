package com.renato.colirioalarme;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ProgramTransfer {
    public static final String MARKER = "ColirioAlarme";

    private ProgramTransfer() {}

    public static JSONObject createJson(Context context) throws Exception {
        JSONObject root = new JSONObject();
        root.put("app", MARKER);
        root.put("formatVersion", 1);
        root.put("createdAt", System.currentTimeMillis());

        JSONArray plans = new JSONArray();
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            JSONObject obj = new JSONObject();
            obj.put("medicine", plan.medicine);
            obj.put("eye", plan.eye);
            JSONArray times = new JSONArray();
            for (String time : plan.times) times.put(time);
            obj.put("times", times);
            plans.put(obj);
        }
        root.put("plans", plans);

        Guidance guidance = GuidanceStore.getActive(context);
        if (guidance != null) {
            JSONObject g = new JSONObject();
            g.put("title", guidance.title);
            g.put("text", guidance.text);
            root.put("guidance", g);
        }
        return root;
    }

    public static void share(Context context) {
        if (PlanStore.getPlans(context).isEmpty()) {
            Toast.makeText(context, "Cadastre pelo menos um colírio antes de enviar.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Toast.makeText(context, "O envio direto requer Android 10 ou superior.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(new Date());
            String fileName = "Programacao_Colirios_" + stamp + ".colirio";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            ContentResolver resolver = context.getContentResolver();
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Não foi possível criar o arquivo");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new Exception("Não foi possível abrir o arquivo");
                out.write(createJson(context).toString(2).getBytes(StandardCharsets.UTF_8));
            }
            values.clear();
            values.put(MediaStore.Downloads.IS_PENDING, 0);
            resolver.update(uri, values, null, null);

            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/json");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(send, "Enviar programação"));
        } catch (Exception e) {
            Toast.makeText(context, "Não foi possível gerar a programação: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
