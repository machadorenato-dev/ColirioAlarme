package com.renato.colirioalarme;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ProgramTransfer {
    public static final String MARKER = "ColirioAlarme";

    private ProgramTransfer() {}

    public static JSONObject createJson(Context context) throws Exception {
        JSONObject root = baseRoot();
        root.put("plans", plansFromCurrentDevice(context));

        String patientName = PatientProfileStore.getName(context);
        if (!patientName.isEmpty()) {
            JSONObject patient = new JSONObject();
            patient.put("id", PatientProfileStore.getId(context));
            patient.put("name", patientName);
            patient.put("surgeryType", PatientProfileStore.getSurgeryType(context));
            patient.put("operatedEye", PatientProfileStore.getOperatedEye(context));
            patient.put("surgeryDateMillis", PatientProfileStore.getSurgeryDateMillis(context));
            root.put("patient", patient);
            if (PatientProfileStore.getSurgeryDateMillis(context) > 0) {
                root.put("surgeryDateMillis", PatientProfileStore.getSurgeryDateMillis(context));
            }
            String token = PatientProfileStore.getLinkToken(context);
            if (!token.isEmpty()) root.put("firebaseToken", token);
        }

        Guidance guidance = GuidanceStore.getActive(context);
        if (guidance != null) root.put("guidance", guidanceJson(guidance.title, guidance.text));
        return root;
    }

    /**
     * Gera a programação completa atualmente atribuída ao paciente. O argumento preferredAssignment
     * serve apenas para escolher o nome do protocolo/orientação quando o envio começou por um protocolo
     * específico. Todos os protocolos ativos do paciente são incluídos no mesmo documento Firebase.
     */
    public static JSONObject createJsonForPatient(Patient patient, PatientAssignment preferredAssignment) throws Exception {
        JSONObject root = baseRoot();
        JSONObject p = new JSONObject();
        p.put("id", patient.id);
        p.put("name", patient.name);
        p.put("surgeryType", patient.surgeryType == null ? "" : patient.surgeryType);
        p.put("operatedEye", patient.operatedEye == null ? "Ambos os olhos" : patient.operatedEye);
        p.put("surgeryDateMillis", patient.surgeryDateMillis);
        root.put("patient", p);
        root.put("surgeryDateMillis", patient.surgeryDateMillis);
        root.put("protocolName", preferredAssignment == null ? "Programação do paciente" : preferredAssignment.protocolName);
        root.put("assignmentId", preferredAssignment == null ? "" : preferredAssignment.id);
        root.put("firebaseToken", patient.linkToken == null ? "" : patient.linkToken);

        JSONArray plans = new JSONArray();
        for (PatientAssignment assignment : patient.assignments) {
            for (ProtocolMedication med : assignment.medications) {
                JSONObject obj = new JSONObject();
                obj.put("medicine", med.medicine);
                obj.put("eye", assignment.eye);
                obj.put("startDelayDays", med.startDelayDays);
                obj.put("startsAfterMedicine", med.startsAfterMedicine == null ? "" : med.startsAfterMedicine);
                obj.put("anchorDateMillis", patient.surgeryDateMillis);
                obj.put("phases", PlanStore.phasesToJson(med.phases));
                med.syncLegacyTimes();
                JSONArray legacy = new JSONArray();
                for (String time : med.times) legacy.put(time);
                obj.put("times", legacy);
                plans.put(obj);
            }
        }
        root.put("plans", plans);

        String guidanceTitle = patient.guidanceTitle == null ? "" : patient.guidanceTitle;
        String guidanceText = patient.guidanceText == null ? "" : patient.guidanceText;
        if (guidanceText.trim().isEmpty() && preferredAssignment != null
                && preferredAssignment.guidanceText != null && !preferredAssignment.guidanceText.trim().isEmpty()) {
            guidanceTitle = preferredAssignment.guidanceTitle;
            guidanceText = preferredAssignment.guidanceText;
        }
        if (guidanceText.trim().isEmpty()) {
            for (int i = patient.assignments.size() - 1; i >= 0; i--) {
                PatientAssignment assignment = patient.assignments.get(i);
                if (assignment.guidanceText != null && !assignment.guidanceText.trim().isEmpty()) {
                    guidanceTitle = assignment.guidanceTitle;
                    guidanceText = assignment.guidanceText;
                    break;
                }
            }
        }
        if (!guidanceText.trim().isEmpty()) root.put("guidance", guidanceJson(guidanceTitle, guidanceText));
        return root;
    }

    private static JSONObject baseRoot() throws Exception {
        JSONObject root = new JSONObject();
        root.put("app", MARKER);
        root.put("formatVersion", 7);
        root.put("createdAt", System.currentTimeMillis());
        return root;
    }

    private static JSONArray plansFromCurrentDevice(Context context) throws Exception {
        JSONArray plans = new JSONArray();
        for (MedicationPlan plan : PlanStore.getPlans(context)) {
            JSONObject obj = new JSONObject();
            obj.put("medicine", plan.medicine);
            obj.put("eye", plan.eye);
            obj.put("startDelayDays", plan.startDelayDays);
            obj.put("startsAfterMedicine", plan.startsAfterMedicine == null ? "" : plan.startsAfterMedicine);
            obj.put("anchorDateMillis", plan.anchorDateMillis);
            obj.put("phases", PlanStore.phasesToJson(plan.phases));
            JSONArray legacy = new JSONArray();
            for (String time : plan.times) legacy.put(time);
            obj.put("times", legacy);
            plans.put(obj);
        }
        return plans;
    }

    static JSONArray plansFromCurrentDeviceForSync(Context context) throws Exception {
        return plansFromCurrentDevice(context);
    }

    private static JSONObject guidanceJson(String title, String text) throws Exception {
        JSONObject g = new JSONObject();
        g.put("title", title == null ? "" : title);
        g.put("text", text == null ? "" : text);
        return g;
    }

    public static void share(Context context) {
        if (PlanStore.getPlans(context).isEmpty()) {
            Toast.makeText(context, "Cadastre pelo menos um medicamento antes de enviar.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            shareJson(context, createJson(context), "Programacao_Colirios", "Enviar programação ao paciente");
        } catch (Exception e) {
            Toast.makeText(context, "Não foi possível gerar a programação: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Mantido por compatibilidade com versões anteriores; a V12 usa sincronização automática. */
    public static void shareAdherence(Context context) {
        String patientId = PatientProfileStore.getId(context);
        String patientName = PatientProfileStore.getName(context);
        if (patientId.isEmpty() || patientName.isEmpty()) {
            Toast.makeText(context, "Esta instalação ainda não está vinculada a um paciente.", Toast.LENGTH_LONG).show();
            return;
        }
        java.util.List<JSONObject> entries = DoseLog.getEntries(context, patientId);
        if (entries.isEmpty()) {
            Toast.makeText(context, "Ainda não há registros de uso para enviar.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            JSONObject root = baseRoot();
            root.put("fileType", "adherence");
            JSONObject patient = new JSONObject();
            patient.put("id", patientId);
            patient.put("name", patientName);
            root.put("patient", patient);
            String token = PatientProfileStore.getLinkToken(context);
            if (!token.isEmpty()) root.put("firebaseToken", token);
            JSONArray logs = new JSONArray();
            for (JSONObject entry : entries) logs.put(new JSONObject(entry.toString()));
            root.put("doseLog", logs);
            root.put("plans", plansFromCurrentDevice(context));
            shareJson(context, root, "Acompanhamento_" + safe(patientName), "Enviar acompanhamento ao médico");
        } catch (Exception e) {
            Toast.makeText(context, "Não foi possível gerar o acompanhamento.", Toast.LENGTH_LONG).show();
        }
    }

    public static void sharePatient(Context context, Patient patient, PatientAssignment assignment) {
        if (patient == null || assignment == null || assignment.medications.isEmpty()) {
            Toast.makeText(context, "Este paciente ainda não possui um protocolo com medicamentos.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!PatientAccessUtil.hasPassword(patient)) {
            Toast.makeText(context, "Defina primeiro a senha de acesso do paciente em Editar dados do paciente.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            JSONObject json = createJsonForPatient(patient, assignment);
            // Se o paciente já usa o app, mantém os horários que ele ajustou ao receber um protocolo adicional.
            json.put("preservePatientTimes", true);
            FirebaseRepository.publishPatientProgram(context, patient, assignment, json, (ok, message) -> {
                Toast.makeText(context,
                        ok ? "Protocolo enviado. O paciente já pode entrar com nome e senha."
                                : "Não foi possível enviar o protocolo agora. Verifique a conexão.\n" + (message == null ? "" : message),
                        Toast.LENGTH_LONG).show();
            });
        } catch (Exception e) {
            Toast.makeText(context, "Não foi possível gerar o protocolo: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public static void publishPatientState(Context context, Patient patient, boolean preservePatientTimes,
                                           FirebaseRepository.ResultCallback callback) {
        if (patient == null) {
            if (callback != null) callback.onResult(false, "Paciente inválido.");
            return;
        }
        if (!PatientAccessUtil.hasPassword(patient)) {
            if (callback != null) callback.onResult(false, "Defina a senha de acesso do paciente.");
            return;
        }
        try {
            PatientAssignment preferred = patient.assignments.isEmpty()
                    ? null : patient.assignments.get(patient.assignments.size() - 1);
            JSONObject json = createJsonForPatient(patient, preferred);
            json.put("preservePatientTimes", preservePatientTimes);
            FirebaseRepository.publishPatientProgram(context, patient, preferred, json, callback);
        } catch (Exception e) {
            if (callback != null) callback.onResult(false, e.getMessage());
        }
    }

    public static void publishPatientUpdate(Context context, Patient patient, PatientAssignment assignment,
                                            FirebaseRepository.ResultCallback callback) {
        if (patient == null) {
            if (callback != null) callback.onResult(false, "Paciente inválido.");
            return;
        }
        if (!PatientAccessUtil.hasPassword(patient)) {
            if (callback != null) callback.onResult(false, "Defina a senha de acesso do paciente.");
            return;
        }
        try {
            JSONObject json = createJsonForPatient(patient, assignment);
            json.put("preservePatientTimes", true);
            FirebaseRepository.publishPatientProgram(context, patient, assignment, json, callback);
        } catch (Exception e) {
            if (callback != null) callback.onResult(false, e.getMessage());
        }
    }

    public static void publishPatientMedicineReplacement(Context context, Patient patient, PatientAssignment assignment,
                                                         String oldMedicine, String newMedicine,
                                                         FirebaseRepository.ResultCallback callback) {
        if (patient == null || assignment == null) {
            if (callback != null) callback.onResult(false, "Paciente sem protocolo ativo.");
            return;
        }
        if (!PatientAccessUtil.hasPassword(patient)) {
            if (callback != null) callback.onResult(false, "Defina a senha de acesso do paciente.");
            return;
        }
        try {
            JSONObject json = createJsonForPatient(patient, assignment);
            json.put("preservePatientTimes", true);
            json.put("replaceMedicineFrom", oldMedicine == null ? "" : oldMedicine);
            json.put("replaceMedicineTo", newMedicine == null ? "" : newMedicine);
            FirebaseRepository.publishPatientProgram(context, patient, assignment, json, callback);
        } catch (Exception e) {
            if (callback != null) callback.onResult(false, e.getMessage());
        }
    }

    private static void shareJson(Context context, JSONObject json, String prefix, String chooserTitle) throws Exception {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Toast.makeText(context, "O envio direto requer Android 10 ou superior.", Toast.LENGTH_LONG).show();
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(new Date());
        String fileName = prefix + "_" + stamp + ".colirio";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        ContentResolver resolver = context.getContentResolver();
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Não foi possível criar o arquivo");
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new Exception("Não foi possível abrir o arquivo");
            out.write(json.toString(2).getBytes(StandardCharsets.UTF_8));
        }
        values.clear();
        values.put(MediaStore.Downloads.IS_PENDING, 0);
        resolver.update(uri, values, null, null);

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/json");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(send, chooserTitle));
    }

    private static String safe(String value) {
        if (value == null) return "";
        String clean = value.trim().replaceAll("[^A-Za-z0-9À-ÿ_-]+", "_");
        return clean.isEmpty() ? "Paciente" : clean;
    }
}
