package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.List;

public class GuidanceListActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (list != null) render();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Orientações"));

        Button create = Ui.primaryButton(this, "+ Nova orientação");
        create.setOnClickListener(v -> createGuidance());
        page.addView(create);
        page.addView(Ui.space(this, 12));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        render();
        setContentView(scroll);
    }

    private void createGuidance() {
        EditText input = new EditText(this);
        input.setHint("Ex.: FACO - pós-operatório");
        new AlertDialog.Builder(this)
                .setTitle("Nome da orientação")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Criar", (d, w) -> {
                    String title = input.getText().toString().trim();
                    if (title.isEmpty()) return;
                    Guidance g = new Guidance(title, "");
                    GuidanceStore.save(this, g);
                    openEdit(g.id);
                }).show();
    }

    private void render() {
        list.removeAllViews();
        List<Guidance> all = GuidanceStore.getAll(this);
        if (all.isEmpty()) {
            list.addView(Ui.subtitle(this, "Nenhuma orientação cadastrada."));
            return;
        }
        for (Guidance g : all) {
            Button guidance = Ui.primaryButton(this, g.title);
            guidance.setOnClickListener(v -> openGuidance(g.id));
            list.addView(guidance);
            list.addView(Ui.space(this, 8));
        }
    }

    private void openGuidance(String id) {
        Intent intent = new Intent(this, GuidanceViewActivity.class);
        intent.putExtra("guidanceId", id);
        startActivity(intent);
    }

    private void openEdit(String id) {
        Intent intent = new Intent(this, GuidanceEditActivity.class);
        intent.putExtra("guidanceId", id);
        startActivity(intent);
    }
}
