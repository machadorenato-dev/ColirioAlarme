package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class GuidanceListActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (list != null) render();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Orientações"));
        page.addView(Ui.subtitle(this, "Crie orientações para diferentes cirurgias e selecione a que será enviada ao paciente."));

        Button create = Ui.primaryButton(this, "+ Nova orientação");
        create.setOnClickListener(v -> createGuidance());
        page.addView(create);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        render();
        setContentView(scroll);
    }

    private void createGuidance() {
        EditText input = new EditText(this);
        input.setHint("Ex.: FACO - pós-operatório");
        new AlertDialog.Builder(this)
                .setTitle("Nome da orientação")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Criar", (d, w) -> {
                    String title = input.getText().toString().trim();
                    if (title.isEmpty()) return;
                    Guidance g = new Guidance(title, "");
                    GuidanceStore.save(this, g);
                    Intent intent = new Intent(this, GuidanceEditActivity.class);
                    intent.putExtra("guidanceId", g.id);
                    startActivity(intent);
                }).show();
    }

    private void render() {
        list.removeAllViews();
        List<Guidance> all = GuidanceStore.getAll(this);
        if (all.isEmpty()) {
            list.addView(Ui.space(this, 12));
            list.addView(Ui.subtitle(this, "Nenhuma orientação cadastrada."));
            return;
        }
        Guidance active = GuidanceStore.getActive(this);
        for (Guidance g : all) {
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(g.title + (active != null && active.id.equals(g.id) ? "   ✓" : ""));
            title.setTextSize(19);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            card.addView(title);

            Button select = Ui.primaryButton(this, "Selecionar para o paciente");
            select.setOnClickListener(v -> {
                GuidanceStore.setActive(this, g.id);
                Toast.makeText(this, "Orientação selecionada.", Toast.LENGTH_SHORT).show();
                render();
            });
            card.addView(select);
            card.addView(Ui.space(this, 6));

            Button edit = Ui.secondaryButton(this, "Editar orientação");
            edit.setOnClickListener(v -> {
                Intent intent = new Intent(this, GuidanceEditActivity.class);
                intent.putExtra("guidanceId", g.id);
                startActivity(intent);
            });
            card.addView(edit);
            list.addView(card);
        }
    }
}
