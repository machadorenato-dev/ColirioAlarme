package com.renato.colirioalarme;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AlarmActivity extends Activity {
    private String medicine;
    private String eye;
    private String time;
    private String planId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        readIntent(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readIntent(intent);
        build();
    }

    private void readIntent(Intent intent) {
        medicine = intent.getStringExtra("medicine");
        eye = intent.getStringExtra("eye");
        time = intent.getStringExtra("time");
        planId = intent.getStringExtra("planId");
        if (medicine == null || medicine.isEmpty()) medicine = "Colírio";
        if (eye == null || eye.isEmpty()) eye = "Ambos os olhos";
        if (time == null || time.isEmpty()) time = "Agora";
    }

    private void build() {
        LinearLayout page = Ui.verticalPage(this);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.addView(Ui.space(this, 30));

        TextView heading = Ui.title(this, "Hora do colírio");
        heading.setGravity(Gravity.CENTER);
        page.addView(heading);

        TextView name = new TextView(this);
        name.setText(medicine);
        name.setTextSize(32);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setTextColor(Ui.BLUE_DARK);
        name.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 10));
        page.addView(name);

        TextView eyeText = new TextView(this);
        eyeText.setText(eye);
        eyeText.setTextSize(24);
        eyeText.setGravity(Gravity.CENTER);
        eyeText.setTextColor(Ui.TEXT);
        page.addView(eyeText);

        TextView timeText = new TextView(this);
        timeText.setText(time);
        timeText.setTextSize(22);
        timeText.setGravity(Gravity.CENTER);
        timeText.setTextColor(Ui.MUTED);
        timeText.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 30));
        page.addView(timeText);

        Button done = Ui.primaryButton(this, "FEITO");
        done.setTextSize(22);
        done.setMinHeight(Ui.dp(this, 72));
        done.setOnClickListener(v -> done());
        page.addView(done);
        page.addView(Ui.space(this, 14));

        Button snooze = Ui.secondaryButton(this, "ADIAR 10 MIN");
        snooze.setTextSize(21);
        snooze.setMinHeight(Ui.dp(this, 72));
        snooze.setOnClickListener(v -> snooze());
        page.addView(snooze);

        setContentView(page);
    }

    private void done() {
        DoseLog.add(this, medicine, eye, time, "FEITO");
        dismissAlarm();
    }

    private void snooze() {
        AlarmScheduler.snooze(this, planId, medicine, eye, time, 10);
        DoseLog.add(this, medicine, eye, time, "ADIADO");
        Toast.makeText(this, "Alarme adiado por 10 minutos.", Toast.LENGTH_SHORT).show();
        dismissAlarm();
    }

    private void dismissAlarm() {
        stopService(new Intent(this, AlarmService.class));
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(AlarmService.NOTIFICATION_ID);
        finishAndRemoveTask();
    }
}
