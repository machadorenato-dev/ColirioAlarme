package com.renato.colirioalarme;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AlarmActivity extends Activity {
    private String medicine;
    private String eye;
    private String time;
    private String planId;
    private PowerManager.WakeLock wakeLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        wakeScreen();
        readIntent(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        configureWindow();
        wakeScreen();
        readIntent(intent);
        build();
    }

    @SuppressWarnings("deprecation")
    private void configureWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    @SuppressWarnings("deprecation")
    private void wakeScreen() {
        releaseWakeLock();
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                            | PowerManager.ACQUIRE_CAUSES_WAKEUP
                            | PowerManager.ON_AFTER_RELEASE,
                    "ColirioAlarme:AlarmActivityWake");
            wakeLock.acquire(20_000L);
        } catch (Exception ignored) {}
    }

    private void readIntent(Intent intent) {
        medicine = intent != null ? intent.getStringExtra("medicine") : null;
        eye = intent != null ? intent.getStringExtra("eye") : null;
        time = intent != null ? intent.getStringExtra("time") : null;
        planId = intent != null ? intent.getStringExtra("planId") : null;
        if (medicine == null || medicine.isEmpty()) medicine = "Colírio";
        if (eye == null || eye.isEmpty()) eye = "Ambos os olhos";
        if (time == null || time.isEmpty()) time = "Agora";
    }

    private void build() {
        LinearLayout page = Ui.verticalPage(this);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.addView(Ui.space(this, 35));

        TextView heading = Ui.title(this, "Hora do colírio");
        heading.setGravity(Gravity.CENTER);
        page.addView(heading);

        TextView name = new TextView(this);
        name.setText(medicine);
        name.setTextSize(34);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setTextColor(Ui.BLUE_DARK);
        name.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 12));
        page.addView(name);

        TextView eyeText = new TextView(this);
        eyeText.setText(eye);
        eyeText.setTextSize(26);
        eyeText.setGravity(Gravity.CENTER);
        eyeText.setTextColor(Ui.TEXT);
        page.addView(eyeText);

        TextView timeText = new TextView(this);
        timeText.setText(time);
        timeText.setTextSize(23);
        timeText.setGravity(Gravity.CENTER);
        timeText.setTextColor(Ui.MUTED);
        timeText.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 34));
        page.addView(timeText);

        Button done = Ui.primaryButton(this, "FEITO");
        done.setTextSize(24);
        done.setMinHeight(Ui.dp(this, 78));
        done.setOnClickListener(v -> done());
        page.addView(done);
        page.addView(Ui.space(this, 16));

        Button snooze = Ui.secondaryButton(this, "ADIAR 10 MIN");
        snooze.setTextSize(22);
        snooze.setMinHeight(Ui.dp(this, 78));
        snooze.setOnClickListener(v -> snooze());
        page.addView(snooze);

        TextView reminder = Ui.subtitle(this, "Se nenhuma opção for escolhida, o alarme tocará novamente em 1 minuto.");
        reminder.setGravity(Gravity.CENTER);
        reminder.setPadding(0, Ui.dp(this, 22), 0, 0);
        page.addView(reminder);
        setContentView(page);
    }

    private void done() {
        DoseLog.add(this, medicine, eye, time, "FEITO");
        dismissAlarm();
    }

    private void snooze() {
        AlarmScheduler.cancelUnanswered(this, planId, time);
        AlarmScheduler.snooze(this, planId, medicine, eye, time, 10);
        DoseLog.add(this, medicine, eye, time, "ADIADO");
        Toast.makeText(this, "Alarme adiado por 10 minutos.", Toast.LENGTH_SHORT).show();
        dismissAlarm();
    }

    private void dismissAlarm() {
        AlarmScheduler.cancelUnanswered(this, planId, time);
        stopService(new Intent(this, AlarmService.class));
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(AlarmService.NOTIFICATION_ID);
        releaseWakeLock();
        finishAndRemoveTask();
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    @Override
    protected void onDestroy() {
        releaseWakeLock();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // Evita fechar o alarme sem registrar FEITO ou ADIAR.
    }
}
