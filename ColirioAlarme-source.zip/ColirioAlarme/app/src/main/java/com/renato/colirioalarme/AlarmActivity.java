package com.renato.colirioalarme;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AlarmActivity extends Activity {
    private String medicine;
    private String eye;
    private String time;
    private String planId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        readIntent(getIntent());
        activateAlarm(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readIntent(intent);
        activateAlarm(intent);
        build();
    }

    private void activateAlarm(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("fromAlarm", false)) return;
        boolean unanswered = intent.getBooleanExtra("unanswered", false);
        boolean snoozeTrigger = intent.getBooleanExtra("snooze", false);

        Intent service = new Intent(this, AlarmService.class);
        service.putExtra("medicine", medicine);
        service.putExtra("eye", eye);
        service.putExtra("planId", planId);
        service.putExtra("time", time);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception ignored) {}

        AlarmScheduler.scheduleUnanswered(this, planId, medicine, eye, time);
        if (!unanswered && !snoozeTrigger && planId != null) {
            MedicationPlan plan = PlanStore.getPlanById(this, planId);
            if (plan != null) AlarmScheduler.schedulePlan(this, plan);
        }
    }

    private void readIntent(Intent intent) {
        medicine = intent.getStringExtra("medicine");
        eye = intent.getStringExtra("eye");
        time = intent.getStringExtra("time");
        planId = intent.getStringExtra("planId");
        if (medicine == null || medicine.isEmpty()) medicine = "Colírio";
        if (eye == null || eye.isEmpty()) eye = "Ambos os olhos";
        if (time == null || time.isEmpty()) time = "Agora";
    }

    private void build() {
        LinearLayout page = Ui.verticalPage(this);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.addView(Ui.space(this, 35));

        TextView heading = Ui.title(this, "Hora do colírio");
        heading.setGravity(Gravity.CENTER);
        page.addView(heading);

        TextView name = new TextView(this);
        name.setText(medicine);
        name.setTextSize(34);
        name.setGravity(Gravity.CENTER);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setTextColor(Ui.BLUE_DARK);
        name.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 12));
        page.addView(name);

        TextView eyeText = new TextView(this);
        eyeText.setText(eye);
        eyeText.setTextSize(26);
        eyeText.setGravity(Gravity.CENTER);
        eyeText.setTextColor(Ui.TEXT);
        page.addView(eyeText);

        TextView timeText = new TextView(this);
        timeText.setText(time);
        timeText.setTextSize(23);
        timeText.setGravity(Gravity.CENTER);
        timeText.setTextColor(Ui.MUTED);
        timeText.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 34));
        page.addView(timeText);

        Button done = Ui.primaryButton(this, "FEITO");
        done.setTextSize(24);
        done.setMinHeight(Ui.dp(this, 78));
        done.setOnClickListener(v -> done());
        page.addView(done);
        page.addView(Ui.space(this, 16));

        Button snooze = Ui.secondaryButton(this, "ADIAR 10 MIN");
        snooze.setTextSize(22);
        snooze.setMinHeight(Ui.dp(this, 78));
        snooze.setOnClickListener(v -> snooze());
        page.addView(snooze);

        TextView reminder = Ui.subtitle(this, "Se nenhuma opção for escolhida, o alarme tocará novamente em 1 minuto.");
        reminder.setGravity(Gravity.CENTER);
        reminder.setPadding(0, Ui.dp(this, 22), 0, 0);
        page.addView(reminder);
        setContentView(page);
    }

    private void done() {
        DoseLog.add(this, medicine, eye, time, "FEITO");
        dismissAlarm();
    }

    private void snooze() {
        AlarmScheduler.cancelUnanswered(this, planId, time);
        AlarmScheduler.snooze(this, planId, medicine, eye, time, 10);
        DoseLog.add(this, medicine, eye, time, "ADIADO");
        Toast.makeText(this, "Alarme adiado por 10 minutos.", Toast.LENGTH_SHORT).show();
        dismissAlarm();
    }

    private void dismissAlarm() {
        AlarmScheduler.cancelUnanswered(this, planId, time);
        stopService(new Intent(this, AlarmService.class));
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(AlarmService.NOTIFICATION_ID);
        finishAndRemoveTask();
    }

    @Override
    public void onBackPressed() {
        // Evita fechar o alarme sem registrar FEITO ou ADIAR.
    }
}
