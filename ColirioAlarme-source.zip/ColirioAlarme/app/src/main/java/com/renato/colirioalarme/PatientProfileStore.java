package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

public final class PatientProfileStore {
    private static final String PREFS = "colirio_patient_profile_v5";
    private static final String KEY_ID = "patient_id";
    private static final String KEY_NAME = "patient_name";
    private static final String KEY_PHONE = "patient_phone";
    private static final String KEY_LINK_TOKEN = "firebase_link_token";

    private PatientProfileStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void save(Context context, String id, String name, String phone) {
        prefs(context).edit()
                .putString(KEY_ID, id == null ? "" : id)
                .putString(KEY_NAME, name == null ? "" : name.trim())
                .putString(KEY_PHONE, phone == null ? "" : phone.trim())
                .apply();
    }

    public static void saveLinkToken(Context context, String token) {
        prefs(context).edit().putString(KEY_LINK_TOKEN, token == null ? "" : token.trim()).apply();
    }

    public static String getId(Context context) { return prefs(context).getString(KEY_ID, ""); }
    public static String getName(Context context) { return prefs(context).getString(KEY_NAME, ""); }
    public static String getPhone(Context context) { return prefs(context).getString(KEY_PHONE, ""); }
    public static String getLinkToken(Context context) { return prefs(context).getString(KEY_LINK_TOKEN, ""); }

    public static String getFirstName(Context context) {
        String name = getName(context).trim();
        if (name.isEmpty()) return "";
        int space = name.indexOf(' ');
        return space > 0 ? name.substring(0, space) : name;
    }
}
