package com.renato.colirioalarme;

public class Reminder {
    public final int id;
    public final String name;
    public final int hour;
    public final int minute;
    public final String message;

    public Reminder(int id, String name, int hour, int minute, String message) {
        this.id = id;
        this.name = name;
        this.hour = hour;
        this.minute = minute;
        this.message = message;
    }

    public String serialize() {
        return id + "|" + esc(name) + "|" + hour + "|" + minute + "|" + esc(message);
    }

    public static Reminder parse(String value) {
        String[] p = value.split("\\|", -1);
        if (p.length != 5) return null;
        try {
            return new Reminder(Integer.parseInt(p[0]), unesc(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), unesc(p[4]));
        } catch (Exception e) {
            return null;
        }
    }

    private static String esc(String s) { return s.replace("%", "%25").replace("|", "%7C"); }
    private static String unesc(String s) { return s.replace("%7C", "|").replace("%25", "%"); }
}
