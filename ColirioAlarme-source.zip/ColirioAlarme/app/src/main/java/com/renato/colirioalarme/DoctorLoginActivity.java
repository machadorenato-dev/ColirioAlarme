package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class DoctorLoginActivity extends Activity {
    private EditText email;
    private EditText password;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        // A Área do médico sempre exige autenticação explícita ao entrar.
        if (auth.getCurrentUser() != null && auth.getCurrentUser().isAnonymous()) auth.signOut();
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Área do médico"));
        email = new EditText(this);
        email.setHint("E-mail do médico");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setText(DoctorAuthStore.getEmail(this));
        page.addView(email);
        page.addView(Ui.space(this, 8));

        password = new EditText(this);
        password.setHint("Senha");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        page.addView(password);
        page.addView(Ui.space(this, 14));

        Button login = Ui.primaryButton(this, "Entrar");
        login.setOnClickListener(v -> login());
        page.addView(login);
        page.addView(Ui.space(this, 9));

        Button forgot = Ui.secondaryButton(this, "Esqueci minha senha");
        forgot.setOnClickListener(v -> sendReset());
        page.addView(forgot);
        page.addView(Ui.space(this, 16));

        Button create = Ui.secondaryButton(this, "Primeiro acesso");
        create.setOnClickListener(v -> registrationDialog());
        page.addView(create);
        setContentView(scroll);
    }

    private void login() {
        String e = email.getText().toString().trim();
        String p = password.getText().toString();
        if (!validEmail(e) || p.length() < 6) {
            Toast.makeText(this, "Informe e-mail e senha válidos.", Toast.LENGTH_LONG).show();
            return;
        }
        setBusy(true);
        auth.signInWithEmailAndPassword(e, p).addOnCompleteListener(task -> {
            setBusy(false);
            if (task.isSuccessful()) {
                DoctorAuthStore.rememberEmail(this, e);
                FirebaseRepository.ensureDoctorProfile(this);
                restoreDoctorAccountAndOpen();
            } else {
                Toast.makeText(this, "Não foi possível entrar. Confira o e-mail e a senha.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void registrationDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 6), pad, 0);
        EditText e = new EditText(this);
        e.setHint("E-mail do médico");
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        e.setText(email.getText().toString().trim());
        EditText p = passwordField("Crie uma senha (mínimo 6 caracteres)");
        EditText c = passwordField("Confirme a senha");
        EditText activation = passwordField("Código de ativação do médico");
        box.addView(e); box.addView(p); box.addView(c); box.addView(activation);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Criar conta do médico")
                .setMessage("Este cadastro cria sua conta online no Firebase.")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Criar conta", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String em = e.getText().toString().trim();
            String pass = p.getText().toString();
            if (!validEmail(em)) { Toast.makeText(this, "Digite um e-mail válido.", Toast.LENGTH_LONG).show(); return; }
            if (!DoctorAuthStore.verifyActivationCode(activation.getText().toString())) { Toast.makeText(this, "Código de ativação inválido.", Toast.LENGTH_LONG).show(); return; }
            if (pass.length() < 6) { Toast.makeText(this, "A senha precisa ter pelo menos 6 caracteres.", Toast.LENGTH_LONG).show(); return; }
            if (!pass.equals(c.getText().toString())) { Toast.makeText(this, "As senhas não coincidem.", Toast.LENGTH_LONG).show(); return; }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            auth.createUserWithEmailAndPassword(em, pass).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    DoctorAuthStore.rememberEmail(this, em);
                    FirebaseRepository.ensureDoctorProfile(this);
                    dialog.dismiss();
                    Toast.makeText(this, "Conta do médico criada.", Toast.LENGTH_LONG).show();
                    restoreDoctorAccountAndOpen();
                } else {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                    String msg = task.getException() == null ? "Não foi possível criar a conta." : task.getException().getMessage();
                    Toast.makeText(this, msg == null ? "Não foi possível criar a conta." : msg, Toast.LENGTH_LONG).show();
                }
            });
        }));
        dialog.show();
    }

    private void sendReset() {
        String e = email.getText().toString().trim();
        if (!validEmail(e)) {
            Toast.makeText(this, "Digite primeiro o e-mail cadastrado.", Toast.LENGTH_LONG).show();
            return;
        }
        auth.sendPasswordResetEmail(e).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DoctorAuthStore.rememberEmail(this, e);
                new AlertDialog.Builder(this)
                        .setTitle("E-mail enviado")
                        .setMessage("O Firebase enviou um link para redefinir sua senha para:\n\n" + e + "\n\nVerifique também a caixa de spam.")
                        .setPositiveButton("OK", null).show();
            } else {
                Toast.makeText(this, "Não foi possível enviar a recuperação. Confira o e-mail e a conexão.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private EditText passwordField(String hint) {
        EditText f = new EditText(this);
        f.setHint(hint);
        f.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return f;
    }

    private boolean validEmail(String value) {
        return value != null && value.contains("@") && value.indexOf('@') > 0 && value.lastIndexOf('.') > value.indexOf('@') + 1;
    }

    private void setBusy(boolean busy) {
        if (email != null) email.setEnabled(!busy);
        if (password != null) password.setEnabled(!busy);
    }

    private void restoreDoctorAccountAndOpen() {
        FirebaseRepository.pullDoctorCatalogs(this, (catalogOk, catalogMsg) ->
                FirebaseRepository.pullPatients(this, (patientOk, patientMsg) -> {
                    FirebaseRepository.syncAllLocalPatients(this, null);
                    runOnUiThread(this::openDoctorArea);
                }));
    }

    private void openDoctorArea() {
        startActivity(new Intent(this, DoctorAreaActivity.class));
        finish();
    }
}
