package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class DoctorLoginActivity extends Activity {
    private EditText email;
    private EditText password;
    private EditText confirm;
    private EditText activation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
    }

    private void build() {
        boolean configured = DoctorAuthStore.isConfigured(this);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, configured ? "Área do médico" : "Configurar Área do médico"));
        page.addView(Ui.subtitle(this, configured
                ? "Entre com o e-mail e a senha do médico."
                : "Faça este cadastro no aparelho do médico antes de distribuir o aplicativo aos pacientes."));

        email = new EditText(this);
        email.setHint("E-mail do médico");
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        if (configured) email.setText(DoctorAuthStore.getEmail(this));
        page.addView(email);
        page.addView(Ui.space(this, 8));

        password = new EditText(this);
        password.setHint(configured ? "Senha" : "Crie uma senha (mínimo 6 caracteres)");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        page.addView(password);

        if (!configured) {
            page.addView(Ui.space(this, 8));
            confirm = new EditText(this);
            confirm.setHint("Confirme a senha");
            confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            page.addView(confirm);
            page.addView(Ui.space(this, 8));
            activation = new EditText(this);
            activation.setHint("Código de ativação do médico");
            activation.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            page.addView(activation);
        }

        page.addView(Ui.space(this, 14));
        Button action = Ui.primaryButton(this, configured ? "Entrar" : "Cadastrar médico");
        action.setOnClickListener(v -> { if (configured) login(); else setup(); });
        page.addView(action);

        if (configured) {
            page.addView(Ui.space(this, 10));
            Button forgot = Ui.secondaryButton(this, "Esqueci minha senha");
            forgot.setOnClickListener(v -> recoveryDialog());
            page.addView(forgot);
        } else {
            page.addView(Ui.space(this, 12));
            TextView note = Ui.subtitle(this, "O e-mail fica associado à Área do médico. Nesta versão, a recuperação segura usa também um código de recuperação gerado no cadastro; guarde esse código. O envio automático de link por e-mail será ativado quando houver um serviço online de autenticação configurado.");
            page.addView(note);
        }
        setContentView(scroll);
    }

    private void setup() {
        String e = email.getText().toString().trim();
        String p = password.getText().toString();
        String c = confirm.getText().toString();
        if (!validEmail(e)) { Toast.makeText(this, "Digite um e-mail válido.", Toast.LENGTH_SHORT).show(); return; }
        if (!DoctorAuthStore.verifyActivationCode(activation.getText().toString())) { Toast.makeText(this, "Código de ativação do médico inválido.", Toast.LENGTH_LONG).show(); return; }
        if (p.length() < 6) { Toast.makeText(this, "A senha deve ter pelo menos 6 caracteres.", Toast.LENGTH_SHORT).show(); return; }
        if (!p.equals(c)) { Toast.makeText(this, "As senhas não coincidem.", Toast.LENGTH_SHORT).show(); return; }
        String recovery = DoctorAuthStore.configure(this, e, p);
        new AlertDialog.Builder(this)
                .setTitle("Cadastro concluído")
                .setMessage("Guarde este código de recuperação em local seguro:\n\n" + recovery + "\n\nEle permite redefinir a senha caso você a esqueça.")
                .setCancelable(false)
                .setPositiveButton("Entendi", (d, w) -> openDoctorArea())
                .show();
    }

    private void login() {
        if (DoctorAuthStore.verifyPassword(this, email.getText().toString(), password.getText().toString())) openDoctorArea();
        else Toast.makeText(this, "E-mail ou senha incorretos.", Toast.LENGTH_LONG).show();
    }

    private void recoveryDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 8), pad, 0);
        EditText e = new EditText(this);
        e.setHint("E-mail cadastrado");
        e.setText(DoctorAuthStore.getEmail(this));
        box.addView(e);
        EditText code = new EditText(this);
        code.setHint("Código de recuperação");
        code.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(code);
        EditText newPass = new EditText(this);
        newPass.setHint("Nova senha");
        newPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(newPass);
        new AlertDialog.Builder(this)
                .setTitle("Redefinir senha")
                .setMessage("Informe o e-mail cadastrado, o código de recuperação e a nova senha.")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Redefinir", (d, w) -> {
                    if (newPass.getText().toString().length() < 6) {
                        Toast.makeText(this, "A nova senha precisa ter pelo menos 6 caracteres.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    boolean ok = DoctorAuthStore.resetWithRecovery(this, e.getText().toString(), code.getText().toString().trim(), newPass.getText().toString());
                    Toast.makeText(this, ok ? "Senha redefinida." : "E-mail ou código de recuperação inválido.", Toast.LENGTH_LONG).show();
                }).show();
    }

    private boolean validEmail(String value) {
        return value != null && value.contains("@") && value.indexOf('@') > 0 && value.lastIndexOf('.') > value.indexOf('@') + 1;
    }

    private void openDoctorArea() {
        startActivity(new Intent(this, DoctorAreaActivity.class));
        finish();
    }
}
