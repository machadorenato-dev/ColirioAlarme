package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ProtocolEditActivity extends Activity {
    private SurgeryProtocol protocol;
    private EditText name;
    private LinearLayout medicationList;
    private TextView guidanceLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        load();
        if (protocol == null) {
            finish();
            return;
        }
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
        if (medicationList != null && protocol != null) {
            renderMedications();
            renderGuidance();
        }
    }

    private void load() {
        protocol = ProtocolStore.getById(this, getIntent().getStringExtra("protocolId"));
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> {
            saveName();
            finish();
        });
        page.addView(back);
        page.addView(Ui.title(this, "Editar protocolo"));

        name = new EditText(this);
        name.setText(protocol.name);
        name.setTextSize(20);
        name.setHint("Nome do protocolo");
        page.addView(name);
        page.addView(Ui.space(this, 8));

        Button saveName = Ui.primaryButton(this, "Salvar");
        saveName.setOnClickListener(v -> saveName());
        page.addView(saveName);

        page.addView(Ui.sectionTitle(this, "Colírios, duração e horários"));
        medicationList = new LinearLayout(this);
        medicationList.setOrientation(LinearLayout.VERTICAL);
        page.addView(medicationList);
        renderMedications();

        Button addMedicine = Ui.primaryButton(this, "+ Adicionar colírio");
        addMedicine.setOnClickListener(v -> chooseMedicine());
        page.addView(addMedicine);

        page.addView(Ui.sectionTitle(this, "Orientação pós-operatória"));
        guidanceLabel = new TextView(this);
        guidanceLabel.setTextSize(17);
        guidanceLabel.setTextColor(Ui.TEXT);
        page.addView(guidanceLabel);
        renderGuidance();

        Button chooseGuidance = Ui.secondaryButton(this, "Escolher orientação");
        chooseGuidance.setOnClickListener(v -> chooseGuidance());
        page.addView(chooseGuidance);

        page.addView(Ui.space(this, 18));
        Button delete = Ui.dangerButton(this, "Excluir protocolo");
        delete.setOnClickListener(v -> confirmDelete());
        page.addView(delete);
        setContentView(scroll);
    }

    private void saveName() {
        String value = name == null ? protocol.name : name.getText().toString().trim();
        if (value.isEmpty()) {
            Toast.makeText(this, "Digite um nome para o protocolo.", Toast.LENGTH_SHORT).show();
            return;
        }
        protocol.name = value;
        ProtocolStore.save(this, protocol);
        Toast.makeText(this, "Protocolo salvo.", Toast.LENGTH_SHORT).show();
    }

    private void renderMedications() {
        medicationList.removeAllViews();
        if (protocol.medications.isEmpty()) {
            medicationList.addView(Ui.subtitle(this, "Nenhum colírio cadastrado."));
            return;
        }
        for (ProtocolMedication med : protocol.medications) {
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(med.medicine);
            title.setTextSize(18);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            card.addView(title);
            TextView times = new TextView(this);
            times.setText(TreatmentText.phasesSummary(med.phases) + (med.startsAfterMedicine != null && !med.startsAfterMedicine.isEmpty() ? "\nInicia após " + med.startsAfterMedicine : (med.startDelayDays > 0 ? "\nInicia após " + med.startDelayDays + " dia(s)" : "")));
            times.setTextSize(16);
            times.setTextColor(Ui.MUTED);
            times.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 6));
            card.addView(times);

            Button edit = Ui.secondaryButton(this, "Editar esquema / desmame");
            edit.setOnClickListener(v -> {
                Intent intent = new Intent(this, ProtocolMedicationActivity.class);
                intent.putExtra("protocolId", protocol.id);
                intent.putExtra("medicine", med.medicine);
                startActivity(intent);
            });
            card.addView(edit);
            card.addView(Ui.space(this, 5));

            Button remove = Ui.dangerButton(this, "Remover do protocolo");
            remove.setOnClickListener(v -> removeMedicine(med.medicine));
            card.addView(remove);
            medicationList.addView(card);
        }
    }

    private void chooseMedicine() {
        List<String> medicines = PlanStore.getMedicines(this);
        ArrayList<String> available = new ArrayList<>();
        for (String item : medicines) {
            boolean exists = false;
            for (ProtocolMedication med : protocol.medications) if (med.medicine.equalsIgnoreCase(item)) exists = true;
            if (!exists) available.add(item);
        }
        if (available.isEmpty()) {
            Toast.makeText(this, "Não há outros colírios disponíveis.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] choices = available.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Adicionar colírio")
                .setItems(choices, (d, which) -> {
                    ProtocolMedication med = new ProtocolMedication(choices[which], new ArrayList<>());
                    protocol.medications.add(med);
                    ProtocolStore.save(this, protocol);
                    Intent intent = new Intent(this, ProtocolMedicationActivity.class);
                    intent.putExtra("protocolId", protocol.id);
                    intent.putExtra("medicine", med.medicine);
                    startActivity(intent);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void removeMedicine(String medicine) {
        new AlertDialog.Builder(this)
                .setTitle("Remover " + medicine + "?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Remover", (d, w) -> {
                    protocol.medications.removeIf(m -> m.medicine.equalsIgnoreCase(medicine));
                    ProtocolStore.save(this, protocol);
                    renderMedications();
                }).show();
    }

    private void renderGuidance() {
        Guidance g = GuidanceStore.getById(this, protocol.guidanceId);
        guidanceLabel.setText(g == null ? "Nenhuma orientação vinculada" : g.title);
    }

    private void chooseGuidance() {
        List<Guidance> all = GuidanceStore.getAll(this);
        ArrayList<String> labels = new ArrayList<>();
        labels.add("Nenhuma");
        for (Guidance g : all) labels.add(g.title);
        String[] choices = labels.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Orientação do protocolo")
                .setItems(choices, (d, which) -> {
                    protocol.guidanceId = which == 0 ? "" : all.get(which - 1).id;
                    ProtocolStore.save(this, protocol);
                    renderGuidance();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir protocolo?")
                .setMessage("O modelo será excluído. Programações já aplicadas não serão alteradas.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> {
                    ProtocolStore.delete(this, protocol.id);
                    finish();
                }).show();
    }
}
