package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ReminderStore {
    private static final String PREFS = "reminders";
    private static final String KEY = "items";

    public static List<Reminder> getAll(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> raw = sp.getStringSet(KEY, new HashSet<>());
        List<Reminder> result = new ArrayList<>();
        for (String s : raw) {
            Reminder r = Reminder.parse(s);
            if (r != null) result.add(r);
        }
        result.sort((a, b) -> {
            int c = Integer.compare(a.hour * 60 + a.minute, b.hour * 60 + b.minute);
            return c != 0 ? c : a.name.compareToIgnoreCase(b.name);
        });
        return result;
    }

    public static void add(Context context, Reminder reminder) {
        List<Reminder> all = getAll(context);
        all.add(reminder);
        save(context, all);
    }

    public static void remove(Context context, int id) {
        List<Reminder> all = getAll(context);
        all.removeIf(r -> r.id == id);
        save(context, all);
    }

    private static void save(Context context, List<Reminder> reminders) {
        Set<String> raw = new HashSet<>();
        for (Reminder r : reminders) raw.add(r.serialize());
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY, raw).apply();
    }
}
