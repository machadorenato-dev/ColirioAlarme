package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PatientDetailActivity extends Activity {
    private String patientId;
    private Patient patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        patientId = getIntent().getStringExtra("patientId");
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        patient = PatientStore.getById(this, patientId);
        if (patient == null) { finish(); return; }
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Pacientes");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, patient.name));
        page.addView(Ui.subtitle(this, patient.phone.isEmpty() ? "Telefone não informado" : patient.phone));

        Button edit = Ui.secondaryButton(this, "Editar dados do paciente");
        edit.setOnClickListener(v -> editPatient());
        page.addView(edit);
        page.addView(Ui.space(this, 10));

        Button addProtocol = Ui.primaryButton(this, "+ Adicionar protocolo");
        addProtocol.setOnClickListener(v -> chooseProtocol());
        page.addView(addProtocol);
        page.addView(Ui.space(this, 8));

        Button send = Ui.primaryButton(this, "Enviar protocolo");
        send.setOnClickListener(v -> chooseAssignmentToSend());
        page.addView(send);
        page.addView(Ui.space(this, 8));

        Button follow = Ui.secondaryButton(this, "Acompanhamento");
        follow.setOnClickListener(v -> {
            Intent intent = new Intent(this, PatientFollowUpActivity.class);
            intent.putExtra("patientId", patient.id);
            startActivity(intent);
        });
        page.addView(follow);

        page.addView(Ui.sectionTitle(this, "Protocolos do paciente"));
        if (patient.assignments.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this, "Nenhum protocolo associado."));
            page.addView(card);
        } else {
            for (PatientAssignment assignment : patient.assignments) {
                LinearLayout card = Ui.card(this);
                TextView title = new TextView(this);
                title.setText(assignment.protocolName);
                title.setTextSize(19);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextColor(Ui.TEXT);
                card.addView(title);
                String date = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(assignment.assignedAt));
                card.addView(Ui.subtitle(this, assignment.eye + " • adicionado em " + date));
                TextView meds = new TextView(this);
                meds.setText(medicinesSummary(assignment));
                meds.setTextSize(15);
                meds.setTextColor(Ui.BLUE_DARK);
                meds.setPadding(0, 0, 0, Ui.dp(this, 8));
                card.addView(meds);
                Button oneSend = Ui.secondaryButton(this, "Enviar este protocolo");
                oneSend.setOnClickListener(v -> ProgramTransfer.sharePatient(this, patient, assignment));
                card.addView(oneSend);
                card.addView(Ui.space(this, 6));
                Button remove = Ui.dangerButton(this, "Remover do paciente");
                remove.setOnClickListener(v -> confirmRemove(assignment));
                card.addView(remove);
                page.addView(card);
            }
        }

        page.addView(Ui.space(this, 10));
        Button delete = Ui.dangerButton(this, "Excluir paciente");
        delete.setOnClickListener(v -> confirmDeletePatient());
        page.addView(delete);
        setContentView(scroll);
    }

    private String medicinesSummary(PatientAssignment assignment) {
        ArrayList<String> names = new ArrayList<>();
        for (ProtocolMedication med : assignment.medications) names.add(med.medicine);
        if (names.isEmpty()) return "Sem colírios cadastrados no protocolo";
        return String.join(" • ", names);
    }

    private void chooseProtocol() {
        List<SurgeryProtocol> protocols = ProtocolStore.getAll(this);
        if (protocols.isEmpty()) {
            Toast.makeText(this, "Cadastre primeiro um protocolo cirúrgico.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[protocols.size()];
        for (int i = 0; i < protocols.size(); i++) names[i] = protocols.get(i).name;
        new AlertDialog.Builder(this).setTitle("Escolha o protocolo")
                .setItems(names, (d, which) -> chooseEye(protocols.get(which)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void chooseEye(SurgeryProtocol protocol) {
        String[] eyes = {"Olho direito", "Olho esquerdo", "Ambos os olhos"};
        new AlertDialog.Builder(this).setTitle("Qual olho?")
                .setItems(eyes, (d, which) -> addProtocol(protocol, eyes[which]))
                .setNegativeButton("Cancelar", null).show();
    }

    private void addProtocol(SurgeryProtocol protocol, String eye) {
        Guidance guidance = GuidanceStore.getById(this, protocol.guidanceId);
        PatientAssignment assignment = new PatientAssignment(protocol.id, protocol.name, eye,
                protocol.medications,
                guidance == null ? "" : guidance.title,
                guidance == null ? "" : guidance.text);
        patient.assignments.add(assignment);
        PatientStore.save(this, patient);
        Toast.makeText(this, "Protocolo adicionado ao paciente.", Toast.LENGTH_SHORT).show();
        render();
    }

    private void chooseAssignmentToSend() {
        if (patient.assignments.isEmpty()) {
            Toast.makeText(this, "Adicione um protocolo antes de enviar.", Toast.LENGTH_LONG).show();
            return;
        }
        if (patient.assignments.size() == 1) {
            ProgramTransfer.sharePatient(this, patient, patient.assignments.get(0));
            return;
        }
        String[] names = new String[patient.assignments.size()];
        for (int i = 0; i < patient.assignments.size(); i++) {
            PatientAssignment a = patient.assignments.get(i);
            names[i] = a.protocolName + " — " + a.eye;
        }
        new AlertDialog.Builder(this).setTitle("Qual protocolo enviar?")
                .setItems(names, (d, which) -> ProgramTransfer.sharePatient(this, patient, patient.assignments.get(which)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void editPatient() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 6), pad, 0);
        EditText name = new EditText(this);
        name.setHint("Nome");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        name.setText(patient.name);
        EditText phone = new EditText(this);
        phone.setHint("Telefone");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        phone.setText(patient.phone);
        box.addView(name); box.addView(phone);
        new AlertDialog.Builder(this).setTitle("Editar paciente").setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) return;
                    patient.name = n;
                    patient.phone = phone.getText().toString().trim();
                    PatientStore.save(this, patient);
                    render();
                }).show();
    }

    private void confirmRemove(PatientAssignment assignment) {
        new AlertDialog.Builder(this).setTitle("Remover protocolo?")
                .setMessage("O protocolo será removido apenas deste paciente. O modelo original será mantido.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Remover", (d, w) -> {
                    patient.assignments.removeIf(a -> a.id.equals(assignment.id));
                    PatientStore.save(this, patient);
                    render();
                }).show();
    }

    private void confirmDeletePatient() {
        new AlertDialog.Builder(this).setTitle("Excluir paciente?")
                .setMessage("O cadastro e os protocolos associados a este paciente serão removidos deste aparelho.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> {
                    PatientStore.delete(this, patient.id);
                    finish();
                }).show();
    }
}
