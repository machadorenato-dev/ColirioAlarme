package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PatientDetailActivity extends Activity {
    private String patientId;
    private Patient patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        patientId = getIntent().getStringExtra("patientId");
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        patient = PatientStore.getById(this, patientId);
        if (patient == null) { finish(); return; }
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Pacientes");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, patient.name));
        String date = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(patient.surgeryDateMillis));
        String details = (patient.phone.isEmpty() ? "Telefone não informado" : patient.phone)
                + "\n" + (patient.surgeryType.isEmpty() ? "Cirurgia não informada" : patient.surgeryType)
                + " • " + patient.operatedEye + "\nData da cirurgia: " + date;
        page.addView(Ui.subtitle(this, details));

        Button edit = Ui.secondaryButton(this, "Editar dados do paciente");
        edit.setOnClickListener(v -> PatientFormDialog.show(this, patient, (updated, surgeryDateChanged) -> {
            PatientStore.save(this, updated);
            if (surgeryDateChanged && !updated.assignments.isEmpty()) {
                PatientAssignment active = updated.assignments.get(updated.assignments.size() - 1);
                ProgramTransfer.publishPatientUpdate(this, updated, active, (ok, msg) -> runOnUiThread(() -> {
                    Toast.makeText(this,
                            ok ? "Data alterada. A programação online foi recalculada a partir da nova data da cirurgia."
                                    : "Data alterada. A atualização online será reenviada quando houver conexão.",
                            Toast.LENGTH_LONG).show();
                }));
            }
            render();
        }));
        page.addView(edit);
        page.addView(Ui.space(this, 10));

        Button addProtocol = Ui.primaryButton(this, "+ Adicionar protocolo");
        addProtocol.setOnClickListener(v -> chooseProtocol());
        page.addView(addProtocol);
        page.addView(Ui.space(this, 8));

        Button follow = Ui.secondaryButton(this, "Acompanhamento");
        follow.setOnClickListener(v -> {
            Intent intent = new Intent(this, PatientFollowUpActivity.class);
            intent.putExtra("patientId", patient.id);
            startActivity(intent);
        });
        page.addView(follow);

        page.addView(Ui.sectionTitle(this, "Protocolos do paciente"));
        if (patient.assignments.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this, "Nenhum protocolo associado."));
            page.addView(card);
        } else {
            for (PatientAssignment assignment : patient.assignments) {
                LinearLayout card = Ui.card(this);
                TextView title = new TextView(this);
                title.setText(assignment.protocolName);
                title.setTextSize(19);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextColor(Ui.TEXT);
                card.addView(title);
                String added = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(assignment.assignedAt));
                card.addView(Ui.subtitle(this, assignment.eye + " • adicionado em " + added));
                TextView meds = new TextView(this);
                meds.setText(medicinesSummary(assignment));
                meds.setTextSize(15);
                meds.setTextColor(Ui.BLUE_DARK);
                meds.setPadding(0, 0, 0, Ui.dp(this, 8));
                card.addView(meds);
                Button remove = Ui.dangerButton(this, "Remover do paciente");
                remove.setOnClickListener(v -> confirmRemove(assignment));
                card.addView(remove);
                page.addView(card);
            }
        }

        page.addView(Ui.space(this, 10));
        Button delete = Ui.dangerButton(this, "Excluir paciente");
        delete.setOnClickListener(v -> confirmDeletePatient());
        page.addView(delete);
        setContentView(scroll);
    }

    private String medicinesSummary(PatientAssignment assignment) {
        ArrayList<String> names = new ArrayList<>();
        for (ProtocolMedication med : assignment.medications) names.add(med.medicine);
        if (names.isEmpty()) return "Sem medicamentos cadastrados no protocolo";
        return String.join(" • ", names);
    }

    private void chooseProtocol() {
        List<SurgeryProtocol> protocols = ProtocolStore.getAll(this);
        if (protocols.isEmpty()) {
            Toast.makeText(this, "Cadastre primeiro um protocolo.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[protocols.size()];
        for (int i = 0; i < protocols.size(); i++) names[i] = protocols.get(i).name;
        new AlertDialog.Builder(this).setTitle("Escolha o protocolo")
                .setItems(names, (d, which) -> addProtocol(protocols.get(which)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void addProtocol(SurgeryProtocol protocol) {
        Guidance guidance = GuidanceStore.getById(this, protocol.guidanceId);
        String eye = patient.operatedEye == null || patient.operatedEye.trim().isEmpty() ? "Ambos os olhos" : patient.operatedEye;
        PatientAssignment assignment = new PatientAssignment(protocol.id, protocol.name, eye,
                protocol.medications,
                guidance == null ? "" : guidance.title,
                guidance == null ? "" : guidance.text);
        patient.assignments.add(assignment);
        PatientStore.save(this, patient);

        String surgeryDate = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(patient.surgeryDateMillis));
        new AlertDialog.Builder(this)
                .setTitle("Protocolo adicionado")
                .setMessage(protocol.name + " foi adicionado para " + patient.name
                        + ".\n\nOs alarmes começarão a partir de " + surgeryDate + ".")
                .setNegativeButton("Enviar depois", (d, w) -> render())
                .setPositiveButton("Enviar protocolo", (d, w) -> ProgramTransfer.sharePatient(this, patient, assignment))
                .show();
        render();
    }

    private void confirmRemove(PatientAssignment assignment) {
        new AlertDialog.Builder(this).setTitle("Remover protocolo?")
                .setMessage("O protocolo será removido apenas deste paciente. O modelo original será mantido.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Remover", (d, w) -> {
                    patient.assignments.removeIf(a -> a.id.equals(assignment.id));
                    PatientStore.save(this, patient);
                    render();
                }).show();
    }

    private void confirmDeletePatient() {
        new AlertDialog.Builder(this).setTitle("Excluir paciente?")
                .setMessage("O cadastro e os protocolos associados a este paciente serão removidos deste aparelho e da sua conta online.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> {
                    PatientStore.delete(this, patient.id);
                    finish();
                }).show();
    }
}
