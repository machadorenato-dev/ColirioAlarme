package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PatientDetailActivity extends Activity {
    private String patientId;
    private Patient patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        patientId = getIntent().getStringExtra("patientId");
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        patient = PatientStore.getById(this, patientId);
        if (patient == null) { finish(); return; }
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Pacientes");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, patient.name));
        String date = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(patient.surgeryDateMillis));
        String details = (patient.surgeryType.isEmpty() ? "Cirurgia não informada" : patient.surgeryType)
                + " • " + patient.operatedEye + "\nData da cirurgia: " + date;
        page.addView(Ui.subtitle(this, details));

        Button edit = Ui.secondaryButton(this, "Editar dados do paciente");
        edit.setOnClickListener(v -> {
            final String oldToken = patient.linkToken == null ? "" : patient.linkToken;
            PatientFormDialog.show(this, patient, (updated, surgeryDateChanged) -> {
                boolean tokenChanged = !oldToken.equals(updated.linkToken == null ? "" : updated.linkToken);
                if (tokenChanged && !oldToken.isEmpty()) FirebaseRepository.deactivatePatientLink(this, oldToken, null);
                PatientStore.save(this, updated);
                if ((surgeryDateChanged || tokenChanged) && PatientAccessUtil.hasPassword(updated)) {
                    ProgramTransfer.publishPatientState(this, updated, true, (ok, msg) -> runOnUiThread(() ->
                            Toast.makeText(this,
                                    ok ? "Dados atualizados e enviados ao paciente."
                                            : "Dados salvos. A atualização online será tentada novamente depois.",
                                    Toast.LENGTH_LONG).show()));
                }
                render();
            });
        });
        page.addView(edit);
        page.addView(Ui.space(this, 10));

        Button addProtocol = Ui.primaryButton(this, "+ Adicionar protocolo");
        addProtocol.setOnClickListener(v -> chooseProtocol());
        page.addView(addProtocol);
        page.addView(Ui.space(this, 8));

        Button addMedicine = Ui.primaryButton(this, "Adicionar medicamentos");
        addMedicine.setOnClickListener(v -> chooseAssignmentForMedicine());
        page.addView(addMedicine);
        page.addView(Ui.space(this, 8));

        Button sendGuidance = Ui.primaryButton(this, "Enviar orientações");
        sendGuidance.setOnClickListener(v -> chooseGuidanceToSend());
        page.addView(sendGuidance);
        page.addView(Ui.space(this, 8));

        Button follow = Ui.secondaryButton(this, "Acompanhamento");
        follow.setOnClickListener(v -> {
            Intent intent = new Intent(this, PatientFollowUpActivity.class);
            intent.putExtra("patientId", patient.id);
            startActivity(intent);
        });
        page.addView(follow);

        page.addView(Ui.sectionTitle(this, "Protocolos do paciente"));
        if (patient.assignments.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this, "Nenhum protocolo associado."));
            page.addView(card);
        } else {
            for (PatientAssignment assignment : patient.assignments) {
                LinearLayout card = Ui.card(this);
                TextView title = new TextView(this);
                title.setText(assignment.protocolName);
                title.setTextSize(19);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextColor(Ui.TEXT);
                card.addView(title);
                String added = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date(assignment.assignedAt));
                card.addView(Ui.subtitle(this, assignment.eye + " • adicionado em " + added));

                if (assignment.medications.isEmpty()) {
                    card.addView(Ui.subtitle(this, "Sem medicamentos cadastrados."));
                } else {
                    TextView meds = new TextView(this);
                    meds.setText(medicinesSummary(assignment));
                    meds.setTextSize(15);
                    meds.setTextColor(Ui.BLUE_DARK);
                    meds.setPadding(0, 0, 0, Ui.dp(this, 8));
                    card.addView(meds);
                    for (ProtocolMedication med : new ArrayList<>(assignment.medications)) {
                        Button replace = Ui.secondaryButton(this, "Trocar " + med.medicine);
                        replace.setOnClickListener(v -> chooseReplacement(assignment, med));
                        card.addView(replace);
                        card.addView(Ui.space(this, 6));
                    }
                }

                Button remove = Ui.dangerButton(this, "Remover do paciente");
                remove.setOnClickListener(v -> confirmRemove(assignment));
                card.addView(remove);
                page.addView(card);
            }
        }

        page.addView(Ui.space(this, 10));
        Button delete = Ui.dangerButton(this, "Excluir paciente");
        delete.setOnClickListener(v -> confirmDeletePatient());
        page.addView(delete);
        setContentView(scroll);
    }

    private String medicinesSummary(PatientAssignment assignment) {
        ArrayList<String> names = new ArrayList<>();
        for (ProtocolMedication med : assignment.medications) names.add(med.medicine);
        if (names.isEmpty()) return "Sem medicamentos cadastrados no protocolo";
        return String.join(" • ", names);
    }

    private void chooseProtocol() {
        List<SurgeryProtocol> protocols = ProtocolStore.getAll(this);
        if (protocols.isEmpty()) {
            Toast.makeText(this, "Cadastre primeiro um protocolo.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[protocols.size()];
        for (int i = 0; i < protocols.size(); i++) names[i] = protocols.get(i).name;
        new AlertDialog.Builder(this).setTitle("Escolha o protocolo")
                .setItems(names, (d, which) -> addProtocol(protocols.get(which)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void addProtocol(SurgeryProtocol protocol) {
        Guidance guidance = GuidanceStore.getById(this, protocol.guidanceId);
        String eye = patient.operatedEye == null || patient.operatedEye.trim().isEmpty() ? "Ambos os olhos" : patient.operatedEye;
        PatientAssignment assignment = new PatientAssignment(protocol.id, protocol.name, eye,
                protocol.medications,
                guidance == null ? "" : guidance.title,
                guidance == null ? "" : guidance.text);
        patient.assignments.add(assignment);
        PatientStore.save(this, patient);

        String surgeryDate = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR")).format(new Date(patient.surgeryDateMillis));
        new AlertDialog.Builder(this)
                .setTitle("Protocolo adicionado")
                .setMessage(protocol.name + " foi adicionado para " + patient.name
                        + ".\n\nOs alarmes começarão a partir de " + surgeryDate + ".")
                .setNegativeButton("Enviar depois", (d, w) -> render())
                .setPositiveButton("Enviar protocolo", (d, w) -> ProgramTransfer.sharePatient(this, patient, assignment))
                .show();
        render();
    }

    private void chooseGuidanceToSend() {
        List<Guidance> all = GuidanceStore.getAll(this);
        if (all.isEmpty()) {
            Toast.makeText(this, "Cadastre primeiro uma orientação na página Orientações.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[all.size()];
        for (int i = 0; i < all.size(); i++) names[i] = all.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle("Enviar orientações")
                .setItems(names, (d, which) -> {
                    Guidance guidance = all.get(which);
                    patient.guidanceTitle = guidance.title;
                    patient.guidanceText = guidance.text;
                    PatientStore.save(this, patient);
                    ProgramTransfer.publishPatientState(this, patient, true,
                            (ok, msg) -> runOnUiThread(() -> Toast.makeText(this,
                                    ok ? "Orientações enviadas ao paciente."
                                            : "Orientações salvas. Não foi possível enviá-las agora.",
                                    Toast.LENGTH_LONG).show()));
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void chooseAssignmentForMedicine() {
        if (patient.assignments.isEmpty()) {
            chooseMedicine(null);
            return;
        }
        if (patient.assignments.size() == 1) {
            chooseMedicine(patient.assignments.get(0));
            return;
        }
        String[] choices = new String[patient.assignments.size()];
        for (int i = 0; i < patient.assignments.size(); i++) choices[i] = patient.assignments.get(i).protocolName;
        new AlertDialog.Builder(this).setTitle("Adicionar a qual protocolo?")
                .setItems(choices, (d, which) -> chooseMedicine(patient.assignments.get(which)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void chooseMedicine(PatientAssignment assignment) {
        ArrayList<String> available = new ArrayList<>();
        for (String name : PlanStore.getMedicines(this)) {
            boolean exists = false;
            if (assignment != null) {
                for (ProtocolMedication med : assignment.medications) if (med.medicine.equalsIgnoreCase(name)) exists = true;
            }
            if (!exists) available.add(name);
        }
        if (available.isEmpty()) {
            Toast.makeText(this, "Não há outro medicamento disponível. Cadastre-o primeiro na página Medicamentos.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] choices = available.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Adicionar medicamento")
                .setItems(choices, (d, which) -> {
                    PatientAssignment target = assignment;
                    if (target == null) {
                        String eye = patient.operatedEye == null || patient.operatedEye.trim().isEmpty() ? "Ambos os olhos" : patient.operatedEye;
                        target = new PatientAssignment("", "Medicamentos adicionais", eye, new ArrayList<>(), "", "");
                        patient.assignments.add(target);
                        PatientStore.save(this, patient);
                    }
                    openPatientMedicationEditor(target, choices[which]);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void openPatientMedicationEditor(PatientAssignment assignment, String medicine) {
        Intent intent = new Intent(this, PatientMedicationActivity.class);
        intent.putExtra("patientId", patient.id);
        intent.putExtra("assignmentId", assignment.id);
        intent.putExtra("medicine", medicine);
        startActivity(intent);
    }

    private void chooseReplacement(PatientAssignment assignment, ProtocolMedication medication) {
        ArrayList<String> available = new ArrayList<>();
        for (String name : PlanStore.getMedicines(this)) {
            if (name.equalsIgnoreCase(medication.medicine)) continue;
            boolean alreadyUsed = false;
            for (ProtocolMedication med : assignment.medications) {
                if (med != medication && med.medicine.equalsIgnoreCase(name)) alreadyUsed = true;
            }
            if (!alreadyUsed) available.add(name);
        }
        if (available.isEmpty()) {
            Toast.makeText(this, "Cadastre primeiro o medicamento substituto na página Medicamentos.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] choices = available.toArray(new String[0]);
        final String oldName = medication.medicine;
        new AlertDialog.Builder(this)
                .setTitle("Trocar " + oldName)
                .setMessage("Os horários, duração, desmame e início serão mantidos. Escolha apenas o novo medicamento.")
                .setItems(choices, (d, which) -> {
                    String newName = choices[which];
                    medication.medicine = newName;
                    for (ProtocolMedication med : assignment.medications) {
                        if (oldName.equalsIgnoreCase(med.startsAfterMedicine)) med.startsAfterMedicine = newName;
                    }
                    PatientStore.save(this, patient);
                    ProgramTransfer.publishPatientMedicineReplacement(this, patient, assignment, oldName, newName,
                            (ok, msg) -> runOnUiThread(() -> Toast.makeText(this,
                                    ok ? oldName + " foi trocado por " + newName + "."
                                            : "A troca foi salva. A atualização online será tentada novamente depois.",
                                    Toast.LENGTH_LONG).show()));
                    render();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void confirmRemove(PatientAssignment assignment) {
        new AlertDialog.Builder(this).setTitle("Remover protocolo?")
                .setMessage("O protocolo será removido apenas deste paciente. O modelo original será mantido e o celular do paciente receberá a exclusão.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Remover", (d, w) -> {
                    patient.assignments.removeIf(a -> a.id.equals(assignment.id));
                    PatientStore.save(this, patient);
                    ProgramTransfer.publishPatientState(this, patient, true,
                            (ok, msg) -> runOnUiThread(() -> Toast.makeText(this,
                                    ok ? "Protocolo removido e atualização enviada ao paciente."
                                            : "Protocolo removido. Não foi possível atualizar o celular do paciente agora.",
                                    Toast.LENGTH_LONG).show()));
                    render();
                }).show();
    }

    private void confirmDeletePatient() {
        new AlertDialog.Builder(this).setTitle("Excluir paciente?")
                .setMessage("O cadastro e os protocolos associados a este paciente serão removidos deste aparelho e da sua conta online.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> {
                    PatientStore.delete(this, patient.id);
                    finish();
                }).show();
    }
}
