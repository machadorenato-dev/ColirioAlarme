package com.renato.colirioalarme;

import android.content.Context;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public final class TreatmentUtils {
    public static class NextDose {
        public final long whenMillis;
        public final String time;
        public final int phaseIndex;
        public NextDose(long whenMillis, String time, int phaseIndex) {
            this.whenMillis = whenMillis;
            this.time = time;
            this.phaseIndex = phaseIndex;
        }
    }

    private TreatmentUtils() {}

    public static long midnight(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static long resolveStartMillis(Context context, MedicationPlan plan) {
        return resolveStartMillis(context, plan, new HashSet<>());
    }

    private static long resolveStartMillis(Context context, MedicationPlan plan, Set<String> visited) {
        if (plan == null) return Long.MAX_VALUE;
        if (plan.id != null && !visited.add(plan.id)) return Long.MAX_VALUE;
        long base = plan.anchorDateMillis > 0 ? midnight(plan.anchorDateMillis) : midnight(System.currentTimeMillis());
        if (plan.startsAfterMedicine != null && !plan.startsAfterMedicine.trim().isEmpty()) {
            MedicationPlan dependency = PlanStore.getPlanForMedicine(context, plan.startsAfterMedicine);
            if (dependency != null && (plan.id == null || !dependency.id.equals(plan.id))) {
                long end = endExclusiveMillis(context, dependency, visited);
                if (end != Long.MAX_VALUE) return end;
                return Long.MAX_VALUE;
            }
            // Se a programação depende de outro colírio que não existe mais, não inicia por engano.
            return Long.MAX_VALUE;
        }
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(base);
        c.add(Calendar.DAY_OF_YEAR, Math.max(0, plan.startDelayDays));
        return c.getTimeInMillis();
    }

    public static long endExclusiveMillis(Context context, MedicationPlan plan) {
        return endExclusiveMillis(context, plan, new HashSet<>());
    }

    private static long endExclusiveMillis(Context context, MedicationPlan plan, Set<String> visited) {
        long start = resolveStartMillis(context, plan, visited);
        if (start == Long.MAX_VALUE) return Long.MAX_VALUE;
        int total = 0;
        if (plan.phases == null || plan.phases.isEmpty()) return start;
        for (TreatmentPhase phase : plan.phases) {
            if (phase.days <= 0) return Long.MAX_VALUE;
            total += phase.days;
        }
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(start);
        c.add(Calendar.DAY_OF_YEAR, total);
        return c.getTimeInMillis();
    }

    public static NextDose nextDose(Context context, MedicationPlan plan, long afterMillis) {
        if (plan == null || plan.phases == null || plan.phases.isEmpty()) return null;
        long start = resolveStartMillis(context, plan);
        if (start == Long.MAX_VALUE) return null;

        long firstDay = Math.max(midnight(afterMillis), start);
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(firstDay);
        for (int scan = 0; scan < 1095; scan++) {
            long dayMillis = midnight(day.getTimeInMillis());
            int dayOffset = daysBetween(start, dayMillis);
            if (dayOffset >= 0) {
                int phaseIndex = phaseIndexForDay(plan, dayOffset);
                if (phaseIndex < 0) return null;
                TreatmentPhase phase = plan.phases.get(phaseIndex);
                long best = Long.MAX_VALUE;
                String bestTime = null;
                for (String time : phase.times) {
                    long candidate = atTime(dayMillis, time);
                    if (candidate > afterMillis && candidate < best) {
                        best = candidate;
                        bestTime = time;
                    }
                }
                if (bestTime != null) return new NextDose(best, bestTime, phaseIndex);
            }
            day.add(Calendar.DAY_OF_YEAR, 1);
        }
        return null;
    }

    private static int phaseIndexForDay(MedicationPlan plan, int dayOffset) {
        int remaining = dayOffset;
        for (int i = 0; i < plan.phases.size(); i++) {
            TreatmentPhase p = plan.phases.get(i);
            if (p.days <= 0) return i;
            if (remaining < p.days) return i;
            remaining -= p.days;
        }
        return -1;
    }

    private static int daysBetween(long startMidnight, long dayMidnight) {
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(startMidnight);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(dayMidnight);
        int days = 0;
        while (a.before(b) && days < 2000) {
            a.add(Calendar.DAY_OF_YEAR, 1);
            days++;
        }
        return days;
    }

    private static long atTime(long dayMillis, String time) {
        String[] parts = time == null ? new String[0] : time.split(":");
        if (parts.length != 2) return Long.MIN_VALUE;
        try {
            int hour = Integer.parseInt(parts[0]);
            int minute = Integer.parseInt(parts[1]);
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(dayMillis);
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, minute);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            return c.getTimeInMillis();
        } catch (Exception e) {
            return Long.MIN_VALUE;
        }
    }
}
