package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class AdherenceStore {
    private static final String PREFS = "colirio_doctor_adherence_v5";
    private static final String KEY = "reports";

    private AdherenceStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void saveReport(Context context, String patientId, JSONArray logs, JSONArray plans) {
        if (patientId == null || patientId.isEmpty()) return;
        try {
            JSONObject reports = new JSONObject(prefs(context).getString(KEY, "{}"));
            JSONObject report = new JSONObject();
            report.put("receivedAt", System.currentTimeMillis());
            report.put("logs", logs == null ? new JSONArray() : new JSONArray(logs.toString()));
            report.put("plans", plans == null ? new JSONArray() : new JSONArray(plans.toString()));
            reports.put(patientId, report);
            prefs(context).edit().putString(KEY, reports.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static List<JSONObject> getEntries(Context context, String patientId) {
        ArrayList<JSONObject> result = new ArrayList<>();
        JSONArray arr = getArray(context, patientId, "logs");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj != null) result.add(obj);
        }
        return result;
    }

    public static JSONArray getPlans(Context context, String patientId) {
        return getArray(context, patientId, "plans");
    }

    private static JSONArray getArray(Context context, String patientId, String field) {
        try {
            JSONObject reports = new JSONObject(prefs(context).getString(KEY, "{}"));
            Object stored = reports.opt(patientId == null ? "" : patientId);
            if (stored instanceof JSONObject) {
                JSONArray arr = ((JSONObject) stored).optJSONArray(field);
                return arr == null ? new JSONArray() : new JSONArray(arr.toString());
            }
            // Compatibilidade com um relatório inicial que guardava diretamente o array de logs.
            if ("logs".equals(field) && stored instanceof JSONArray) return new JSONArray(stored.toString());
        } catch (Exception ignored) {}
        return new JSONArray();
    }
}
