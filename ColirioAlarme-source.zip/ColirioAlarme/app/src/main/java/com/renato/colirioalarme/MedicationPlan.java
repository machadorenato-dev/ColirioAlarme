package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MedicationPlan {
    public String id;
    public String medicine;
    public String eye;
    public ArrayList<String> times;
    public ArrayList<TreatmentPhase> phases;
    public int startDelayDays;
    public String startsAfterMedicine;
    public long anchorDateMillis;

    public MedicationPlan(String medicine, String eye, List<String> times) {
        this(UUID.randomUUID().toString(), medicine, eye,
                makeLegacyPhases(times), 0, "", System.currentTimeMillis());
    }

    public MedicationPlan(String id, String medicine, String eye, List<String> times) {
        this(id, medicine, eye, makeLegacyPhases(times), 0, "", System.currentTimeMillis());
    }

    public MedicationPlan(String medicine, String eye, List<TreatmentPhase> phases,
                          int startDelayDays, String startsAfterMedicine, long anchorDateMillis) {
        this(UUID.randomUUID().toString(), medicine, eye, phases,
                startDelayDays, startsAfterMedicine, anchorDateMillis);
    }

    public MedicationPlan(String id, String medicine, String eye, List<TreatmentPhase> phases,
                          int startDelayDays, String startsAfterMedicine, long anchorDateMillis) {
        this.id = id;
        this.medicine = medicine;
        this.eye = eye;
        this.phases = new ArrayList<>();
        if (phases != null) {
            for (TreatmentPhase phase : phases) this.phases.add(phase.copy());
        }
        if (this.phases.isEmpty()) this.phases.add(new TreatmentPhase(7, new ArrayList<>()));
        this.startDelayDays = Math.max(0, startDelayDays);
        this.startsAfterMedicine = startsAfterMedicine == null ? "" : startsAfterMedicine;
        this.anchorDateMillis = anchorDateMillis > 0 ? anchorDateMillis : System.currentTimeMillis();
        syncLegacyTimes();
    }

    public void syncLegacyTimes() {
        this.times = new ArrayList<>();
        if (phases != null && !phases.isEmpty()) this.times.addAll(phases.get(0).times);
    }

    public ArrayList<String> allTimes() {
        ArrayList<String> result = new ArrayList<>();
        if (phases != null) {
            for (TreatmentPhase phase : phases) {
                for (String time : phase.times) if (!result.contains(time)) result.add(time);
            }
        }
        return result;
    }

    private static ArrayList<TreatmentPhase> makeLegacyPhases(List<String> times) {
        ArrayList<TreatmentPhase> result = new ArrayList<>();
        result.add(new TreatmentPhase(0, times));
        return result;
    }
}
