package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MedicationPlan {
    public String id;
    public String medicine;
    public String eye;
    public ArrayList<String> times;

    public MedicationPlan(String medicine, String eye, List<String> times) {
        this(UUID.randomUUID().toString(), medicine, eye, times);
    }

    public MedicationPlan(String id, String medicine, String eye, List<String> times) {
        this.id = id;
        this.medicine = medicine;
        this.eye = eye;
        this.times = new ArrayList<>(times);
    }
}
