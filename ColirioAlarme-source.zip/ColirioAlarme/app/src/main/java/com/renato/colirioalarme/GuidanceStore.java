package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class GuidanceStore {
    private static final String PREFS = "colirio_programacao_v3";
    private static final String KEY_GUIDANCES = "guidances";
    private static final String KEY_ACTIVE = "active_guidance";

    private GuidanceStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<Guidance> getAll(Context context) {
        ArrayList<Guidance> result = new ArrayList<>();
        String raw = prefs(context).getString(KEY_GUIDANCES, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String id = obj.optString("id", "");
                String title = obj.optString("title", "").trim();
                String text = obj.optString("text", "");
                if (!id.isEmpty() && !title.isEmpty()) result.add(new Guidance(id, title, text));
            }
        } catch (Exception ignored) {}
        final Collator collator = Collator.getInstance(new Locale("pt", "BR"));
        collator.setStrength(Collator.PRIMARY);
        result.sort((a, b) -> collator.compare(a.title, b.title));
        return result;
    }

    public static Guidance getById(Context context, String id) {
        if (id == null || id.isEmpty()) return null;
        for (Guidance g : getAll(context)) if (id.equals(g.id)) return g;
        return null;
    }

    public static void save(Context context, Guidance guidance) {
        List<Guidance> all = getAll(context);
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(guidance.id)) {
                all.set(i, guidance);
                replaced = true;
                break;
            }
        }
        if (!replaced) all.add(guidance);
        saveAll(context, all);
    }

    public static void delete(Context context, String id) {
        List<Guidance> all = getAll(context);
        all.removeIf(g -> g.id.equals(id));
        saveAll(context, all);
        if (id != null && id.equals(prefs(context).getString(KEY_ACTIVE, ""))) clearActive(context);
    }

    private static void saveAll(Context context, List<Guidance> all) {
        JSONArray arr = new JSONArray();
        try {
            for (Guidance g : all) {
                JSONObject obj = new JSONObject();
                obj.put("id", g.id);
                obj.put("title", g.title);
                obj.put("text", g.text);
                arr.put(obj);
            }
        } catch (Exception ignored) {}
        prefs(context).edit().putString(KEY_GUIDANCES, arr.toString()).apply();
    }

    public static void setActive(Context context, String id) {
        prefs(context).edit().putString(KEY_ACTIVE, id == null ? "" : id).apply();
    }

    public static Guidance getActive(Context context) {
        return getById(context, prefs(context).getString(KEY_ACTIVE, ""));
    }

    public static void clearActive(Context context) {
        prefs(context).edit().remove(KEY_ACTIVE).apply();
    }

    public static Guidance importAndActivate(Context context, String title, String text) {
        String cleanTitle = title == null ? "" : title.trim();
        if (cleanTitle.isEmpty()) return null;
        for (Guidance existing : getAll(context)) {
            if (existing.title.equalsIgnoreCase(cleanTitle) && existing.text.equals(text == null ? "" : text)) {
                setActive(context, existing.id);
                return existing;
            }
        }
        Guidance g = new Guidance(cleanTitle, text == null ? "" : text);
        save(context, g);
        setActive(context, g.id);
        return g;
    }
}
