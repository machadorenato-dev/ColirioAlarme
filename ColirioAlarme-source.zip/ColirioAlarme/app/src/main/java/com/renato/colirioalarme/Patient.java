package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Patient {
    public String id;
    public String name;
    public String phone;
    /** Token aleatório usado para vincular com segurança o aparelho do paciente sem exigir senha. */
    public String linkToken;
    public ArrayList<PatientAssignment> assignments;

    public Patient(String name, String phone) {
        this(UUID.randomUUID().toString(), name, phone, UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", ""), new ArrayList<>());
    }

    public Patient(String id, String name, String phone, List<PatientAssignment> assignments) {
        this(id, name, phone, "", assignments);
    }

    public Patient(String id, String name, String phone, String linkToken, List<PatientAssignment> assignments) {
        this.id = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
        this.name = name == null ? "" : name.trim();
        this.phone = phone == null ? "" : phone.trim();
        this.linkToken = linkToken == null || linkToken.isEmpty()
                ? UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")
                : linkToken;
        this.assignments = new ArrayList<>();
        if (assignments != null) this.assignments.addAll(assignments);
    }
}
