package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Patient {
    public String id;
    public String name;
    public String phone;
    public ArrayList<PatientAssignment> assignments;

    public Patient(String name, String phone) {
        this(UUID.randomUUID().toString(), name, phone, new ArrayList<>());
    }

    public Patient(String id, String name, String phone, List<PatientAssignment> assignments) {
        this.id = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
        this.name = name == null ? "" : name.trim();
        this.phone = phone == null ? "" : phone.trim();
        this.assignments = new ArrayList<>();
        if (assignments != null) this.assignments.addAll(assignments);
    }
}
