package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Patient {
    public String id;
    public String name;
    public String phone;
    public String surgeryType;
    public String operatedEye;
    public long surgeryDateMillis;
    /** Token aleatório usado para vincular com segurança o aparelho do paciente sem exigir senha. */
    public String linkToken;
    public ArrayList<PatientAssignment> assignments;

    public Patient(String name, String phone) {
        this(name, phone, "", "Ambos os olhos", System.currentTimeMillis());
    }

    public Patient(String name, String phone, String surgeryType, String operatedEye, long surgeryDateMillis) {
        this(UUID.randomUUID().toString(), name, phone, surgeryType, operatedEye, surgeryDateMillis,
                UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", ""), new ArrayList<>());
    }

    public Patient(String id, String name, String phone, List<PatientAssignment> assignments) {
        this(id, name, phone, "", "Ambos os olhos", System.currentTimeMillis(), "", assignments);
    }

    public Patient(String id, String name, String phone, String linkToken, List<PatientAssignment> assignments) {
        this(id, name, phone, "", "Ambos os olhos", System.currentTimeMillis(), linkToken, assignments);
    }

    public Patient(String id, String name, String phone, String surgeryType, String operatedEye,
                   long surgeryDateMillis, String linkToken, List<PatientAssignment> assignments) {
        this.id = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
        this.name = name == null ? "" : name.trim();
        this.phone = phone == null ? "" : phone.trim();
        this.surgeryType = surgeryType == null ? "" : surgeryType.trim();
        this.operatedEye = operatedEye == null || operatedEye.trim().isEmpty() ? "Ambos os olhos" : operatedEye.trim();
        this.surgeryDateMillis = TreatmentUtils.midnight(surgeryDateMillis > 0 ? surgeryDateMillis : System.currentTimeMillis());
        this.linkToken = linkToken == null || linkToken.isEmpty()
                ? UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")
                : linkToken;
        this.assignments = new ArrayList<>();
        if (assignments != null) this.assignments.addAll(assignments);
    }
}
