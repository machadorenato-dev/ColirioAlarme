package com.renato.colirioalarme;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Patient {
    public String id;
    public String name;
    /** Mantido apenas para compatibilidade com cadastros antigos. Novos cadastros não usam telefone. */
    public String phone;
    public String surgeryType;
    public String operatedEye;
    public long surgeryDateMillis;
    /** Identificador de acesso usado no vínculo do aparelho do paciente. */
    public String linkToken;
    /** Hash da senha do paciente; a senha em texto aberto não é armazenada. */
    public String passwordHash;
    /** Orientação enviada diretamente ao paciente, independente do modelo do protocolo. */
    public String guidanceTitle;
    public String guidanceText;
    public ArrayList<PatientAssignment> assignments;

    public Patient(String name, String phone) {
        this(name, phone, "", "Ambos os olhos", System.currentTimeMillis());
    }

    public Patient(String name, String phone, String surgeryType, String operatedEye, long surgeryDateMillis) {
        this(UUID.randomUUID().toString(), name, phone, surgeryType, operatedEye, surgeryDateMillis,
                "", "", "", "", new ArrayList<>());
    }

    public Patient(String id, String name, String phone, List<PatientAssignment> assignments) {
        this(id, name, phone, "", "Ambos os olhos", System.currentTimeMillis(), "", "", "", "", assignments);
    }

    public Patient(String id, String name, String phone, String linkToken, List<PatientAssignment> assignments) {
        this(id, name, phone, "", "Ambos os olhos", System.currentTimeMillis(), linkToken, "", "", "", assignments);
    }

    public Patient(String id, String name, String phone, String surgeryType, String operatedEye,
                   long surgeryDateMillis, String linkToken, List<PatientAssignment> assignments) {
        this(id, name, phone, surgeryType, operatedEye, surgeryDateMillis, linkToken, "", "", "", assignments);
    }

    public Patient(String id, String name, String phone, String surgeryType, String operatedEye,
                   long surgeryDateMillis, String linkToken, String passwordHash, List<PatientAssignment> assignments) {
        this(id, name, phone, surgeryType, operatedEye, surgeryDateMillis, linkToken, passwordHash,
                "", "", assignments);
    }

    public Patient(String id, String name, String phone, String surgeryType, String operatedEye,
                   long surgeryDateMillis, String linkToken, String passwordHash,
                   String guidanceTitle, String guidanceText, List<PatientAssignment> assignments) {
        this.id = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
        this.name = name == null ? "" : name.trim();
        this.phone = phone == null ? "" : phone.trim();
        this.surgeryType = surgeryType == null ? "" : surgeryType.trim();
        this.operatedEye = operatedEye == null || operatedEye.trim().isEmpty() ? "Ambos os olhos" : operatedEye.trim();
        this.surgeryDateMillis = TreatmentUtils.midnight(surgeryDateMillis > 0 ? surgeryDateMillis : System.currentTimeMillis());
        this.linkToken = linkToken == null ? "" : linkToken.trim();
        this.passwordHash = passwordHash == null ? "" : passwordHash.trim();
        this.guidanceTitle = guidanceTitle == null ? "" : guidanceTitle.trim();
        this.guidanceText = guidanceText == null ? "" : guidanceText;
        // Mantém tokens antigos para compatibilidade. Ao definir a senha do paciente, passa a usar token derivado da senha.
        if (this.linkToken.isEmpty() && this.passwordHash.isEmpty()) {
            this.linkToken = UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "");
        }
        this.assignments = new ArrayList<>();
        if (assignments != null) this.assignments.addAll(assignments);
    }
}
