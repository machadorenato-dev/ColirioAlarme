package com.renato.colirioalarme;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String medicine = intent.getStringExtra("medicine");
        String eye = intent.getStringExtra("eye");
        String planId = intent.getStringExtra("planId");
        String time = intent.getStringExtra("time");
        boolean unanswered = intent.getBooleanExtra("unanswered", false);
        boolean snooze = intent.getBooleanExtra("snooze", false);

        Intent service = new Intent(context, AlarmService.class);
        service.putExtra("medicine", medicine);
        service.putExtra("eye", eye);
        service.putExtra("planId", planId);
        service.putExtra("time", time);
        service.putExtra("unanswered", unanswered);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) {}

        // Além do full-screen intent da notificação, tenta trazer a tela de alarme à frente
        // imediatamente. Em aparelhos que bloquearem essa abertura, a notificação de alarme
        // permanece e uma nova tentativa é feita após um minuto.
        try {
            Intent alarm = new Intent(context, AlarmActivity.class);
            alarm.putExtra("medicine", medicine);
            alarm.putExtra("eye", eye);
            alarm.putExtra("planId", planId);
            alarm.putExtra("time", time);
            alarm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            context.startActivity(alarm);
        } catch (Exception ignored) {}

        // Enquanto não houver FEITO ou ADIAR, toca e tenta reabrir novamente após 1 minuto.
        AlarmScheduler.scheduleUnanswered(context, planId, medicine, eye, time);

        // O alarme normal é de uma única ocorrência. Já prepara a próxima dose do tratamento.
        if (!unanswered && !snooze && planId != null) {
            MedicationPlan plan = PlanStore.getPlanById(context, planId);
            if (plan != null) AlarmScheduler.schedulePlan(context, plan);
        }
    }
}
