package com.renato.colirioalarme;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String medicine = intent.getStringExtra("medicine");
        String eye = intent.getStringExtra("eye");
        String planId = intent.getStringExtra("planId");

        Intent service = new Intent(context, AlarmService.class);
        service.putExtra("medicine", medicine);
        service.putExtra("eye", eye);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }

        if (planId != null) {
            MedicationPlan plan = PlanStore.getPlanById(context, planId);
            if (plan != null) AlarmScheduler.schedulePlan(context, plan);
        }
    }
}
