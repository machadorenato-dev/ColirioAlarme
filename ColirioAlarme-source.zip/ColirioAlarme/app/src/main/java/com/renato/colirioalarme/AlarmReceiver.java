package com.renato.colirioalarme;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", 0);
        String name = intent.getStringExtra("name");
        String message = intent.getStringExtra("message");
        int hour = intent.getIntExtra("hour", 0);
        int minute = intent.getIntExtra("minute", 0);

        Intent service = new Intent(context, AlarmService.class);
        service.putExtra("id", id);
        service.putExtra("name", name);
        service.putExtra("message", message);
        context.startForegroundService(service);

        AlarmScheduler.schedule(context, new Reminder(id, name == null ? "colírio" : name, hour, minute,
                message == null ? "" : message));
    }
}
