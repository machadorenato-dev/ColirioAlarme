package com.renato.colirioalarme;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

public class AlarmReceiver extends BroadcastReceiver {
    private static PowerManager.WakeLock screenWakeLock;
    @Override
    public void onReceive(Context context, Intent intent) {
        String medicine = intent.getStringExtra("medicine");
        String eye = intent.getStringExtra("eye");
        String planId = intent.getStringExtra("planId");
        String time = intent.getStringExtra("time");
        boolean unanswered = intent.getBooleanExtra("unanswered", false);
        boolean snooze = intent.getBooleanExtra("snooze", false);
        boolean test = intent.getBooleanExtra("test", false);

        if (medicine == null || medicine.trim().isEmpty()) medicine = "Colírio";
        if (eye == null || eye.trim().isEmpty()) eye = "Ambos os olhos";
        if (time == null || time.trim().isEmpty()) time = "Agora";

        boolean wasInteractive = true;
        boolean keyguardLocked = false;
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wasInteractive = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH
                    ? pm.isInteractive() : pm.isScreenOn();
            wakeScreen(pm);
        }
        KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        if (km != null) keyguardLocked = km.isKeyguardLocked();

        if (unanswered) DoseLog.addUnansweredOnce(context, medicine, eye, time);

        Intent service = new Intent(context, AlarmService.class);
        service.putExtra("medicine", medicine);
        service.putExtra("eye", eye);
        service.putExtra("planId", planId);
        service.putExtra("time", time);
        service.putExtra("unanswered", unanswered);
        service.putExtra("snooze", snooze);
        service.putExtra("test", test);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) {}

        // Com a tela bloqueada/apagada, tenta abrir a Activity imediatamente. O full-screen
        // intent da notificação faz uma segunda tentativa pelo mecanismo oficial do Android.
        // Quando o aparelho está desbloqueado e há permissão de sobreposição, o serviço mostra
        // uma janela por cima do aplicativo que estiver em uso.
        boolean overlayAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context);
        if (!wasInteractive || keyguardLocked || !overlayAllowed) {
            try {
                Intent alarm = new Intent(context, AlarmActivity.class);
                alarm.putExtra("medicine", medicine);
                alarm.putExtra("eye", eye);
                alarm.putExtra("planId", planId);
                alarm.putExtra("time", time);
                alarm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(alarm);
            } catch (Exception ignored) {}
        }

        // Enquanto não houver FEITO ou ADIAR, repete em 1 minuto.
        AlarmScheduler.scheduleUnanswered(context, planId, medicine, eye, time, test);

        // O disparo normal é uma única ocorrência. Agenda a próxima dose do tratamento.
        if (!unanswered && !snooze && !test && planId != null) {
            MedicationPlan plan = PlanStore.getPlanById(context, planId);
            if (plan != null) AlarmScheduler.schedulePlan(context, plan);
        }
    }

    @SuppressWarnings("deprecation")
    private synchronized void wakeScreen(PowerManager pm) {
        try {
            if (screenWakeLock != null && screenWakeLock.isHeld()) screenWakeLock.release();
        } catch (Exception ignored) {}
        try {
            screenWakeLock = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                            | PowerManager.ACQUIRE_CAUSES_WAKEUP
                            | PowerManager.ON_AFTER_RELEASE,
                    "ColirioAlarme:AlarmWake");
            // Timeout evita manter a tela/CPU acordada caso algo dê errado.
            screenWakeLock.acquire(15_000L);
        } catch (Exception ignored) {
            screenWakeLock = null;
        }
    }
}
