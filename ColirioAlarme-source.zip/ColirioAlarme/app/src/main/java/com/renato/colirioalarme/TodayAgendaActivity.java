package com.renato.colirioalarme;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TodayAgendaActivity extends Activity {
    private static class AgendaItem {
        long whenMillis;
        String time;
        String medicine;
        String eye;

        AgendaItem(long whenMillis, String time, String medicine, String eye) {
            this.whenMillis = whenMillis;
            this.time = time;
            this.medicine = medicine;
            this.eye = eye;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Agenda de hoje"));

        String date = new SimpleDateFormat("EEEE, dd/MM/yyyy", new Locale("pt", "BR"))
                .format(new Date());
        page.addView(Ui.subtitle(this, capitalize(date)));
        page.addView(Ui.space(this, 10));

        List<AgendaItem> items = loadTodayItems();
        if (items.isEmpty()) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.subtitle(this, "Nenhum medicamento programado para hoje."));
            page.addView(card);
        } else {
            for (AgendaItem item : items) {
                LinearLayout card = Ui.card(this);
                TextView line = new TextView(this);
                line.setText(item.time + " — " + item.medicine);
                line.setTextSize(19);
                line.setTypeface(null, android.graphics.Typeface.BOLD);
                line.setTextColor(Ui.TEXT);
                card.addView(line);
                if (item.eye != null && !item.eye.trim().isEmpty()) {
                    card.addView(Ui.subtitle(this, item.eye));
                }
                page.addView(card);
            }
        }
        setContentView(scroll);
    }

    private List<AgendaItem> loadTodayItems() {
        ArrayList<AgendaItem> result = new ArrayList<>();
        long start = TreatmentUtils.midnight(System.currentTimeMillis());
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.setTimeInMillis(start);
        tomorrow.add(Calendar.DAY_OF_YEAR, 1);
        long end = tomorrow.getTimeInMillis();

        for (MedicationPlan plan : PlanStore.getPlans(this)) {
            long cursor = start - 1;
            int guard = 0;
            while (guard++ < 100) {
                TreatmentUtils.NextDose next = TreatmentUtils.nextDose(this, plan, cursor);
                if (next == null || next.whenMillis >= end) break;
                if (next.whenMillis >= start) {
                    result.add(new AgendaItem(next.whenMillis, next.time, plan.medicine, plan.eye));
                }
                cursor = next.whenMillis;
            }
        }
        result.sort(Comparator.comparingLong(a -> a.whenMillis));
        return result;
    }

    private String capitalize(String value) {
        if (value == null || value.isEmpty()) return "";
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }
}
