package com.renato.colirioalarme;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;

public class PatientHomeActivity extends Activity {
    private LinearLayout page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AlarmScheduler.scheduleAll(this);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AlarmScheduler.scheduleAll(this);
        if (page != null) render();
        FirebasePatientSync.refreshProgram(this, (ok, msg) -> {
            if (ok && "ATUALIZADO".equals(msg)) runOnUiThread(() -> {
                AlarmScheduler.scheduleAll(this);
                Toast.makeText(this, "Programação atualizada pelo médico.", Toast.LENGTH_LONG).show();
                if (!isFinishing()) render();
            });
        });
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        page = Ui.verticalPage(this);
        scroll.addView(page);

        page.addView(Ui.title(this, greeting()));
        page.addView(Ui.subtitle(this, "Seus colírios, horários e orientações pós-operatórias."));

        Guidance active = GuidanceStore.getActive(this);
        if (active != null) {
            Button guidance = Ui.primaryButton(this, "Orientações pós-operatórias");
            guidance.setOnClickListener(v -> showGuidance(active));
            page.addView(guidance);
            page.addView(Ui.space(this, 10));
        }

        page.addView(Ui.sectionTitle(this, "Horários cadastrados"));
        List<MedicationPlan> plans = PlanStore.getPlans(this);
        if (plans.isEmpty()) {
            LinearLayout emptyCard = Ui.card(this);
            emptyCard.addView(Ui.subtitle(this, "Nenhum colírio programado."));
            page.addView(emptyCard);
        } else {
            for (MedicationPlan plan : plans) addPlanCard(plan);
            Button adjust = Ui.primaryButton(this, "Ajustar meus horários");
            adjust.setOnClickListener(v -> startActivity(new Intent(this, PatientScheduleAdjustActivity.class)));
            page.addView(adjust);
            page.addView(Ui.space(this, 12));
        }

        if (!PatientProfileStore.getId(this).isEmpty()) {
            page.addView(Ui.sectionTitle(this, "Acompanhamento"));
            Button sendFollowUp = Ui.secondaryButton(this, "Enviar acompanhamento ao médico");
            sendFollowUp.setOnClickListener(v -> ProgramTransfer.shareAdherence(this));
            page.addView(sendFollowUp);
        }

        page.addView(Ui.space(this, 14));
        addPermissionButtons();

        Button testAlarm = Ui.secondaryButton(this, "Testar alarme com tela apagada");
        testAlarm.setOnClickListener(v -> testAlarm());
        page.addView(testAlarm);

        setContentView(scroll);
    }

    private String greeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String greeting;
        if (hour >= 5 && hour < 12) greeting = "Bom dia";
        else if (hour >= 12 && hour < 18) greeting = "Boa tarde";
        else greeting = "Boa noite";
        String firstName = PatientProfileStore.getFirstName(this);
        return firstName.isEmpty() ? "Bem-vindo" : greeting + ", " + firstName;
    }

    private void addPlanCard(MedicationPlan plan) {
        LinearLayout card = Ui.card(this);
        TextView name = new TextView(this);
        name.setText(plan.medicine);
        name.setTextSize(20);
        name.setTextColor(Ui.TEXT);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(name);

        TextView eye = new TextView(this);
        eye.setText(plan.eye + " • " + TreatmentText.startSummary(plan));
        eye.setTextSize(15);
        eye.setTextColor(Ui.MUTED);
        eye.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 5));
        card.addView(eye);

        TextView details = new TextView(this);
        details.setText(TreatmentText.phasesSummary(plan.phases));
        details.setTextSize(16);
        details.setTextColor(Ui.BLUE_DARK);
        details.setPadding(0, 0, 0, Ui.dp(this, 4));
        card.addView(details);
        page.addView(card);
    }

    private void showGuidance(Guidance guidance) {
        new AlertDialog.Builder(this)
                .setTitle("Orientações pós-operatórias")
                .setMessage(guidance.text == null || guidance.text.trim().isEmpty()
                        ? "Nenhuma orientação cadastrada." : guidance.text)
                .setPositiveButton("Fechar", null)
                .show();
    }

    private void addPermissionButtons() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Button notification = Ui.primaryButton(this, "Permitir notificações");
            notification.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001));
            page.addView(notification);
            page.addView(Ui.space(this, 8));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (manager != null && !manager.canScheduleExactAlarms()) {
                Button exact = Ui.primaryButton(this, "Permitir alarmes exatos");
                exact.setOnClickListener(v -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as permissões do aplicativo e autorize alarmes e lembretes.", Toast.LENGTH_LONG).show();
                    }
                });
                page.addView(exact);
                page.addView(Ui.space(this, 8));
            }
        }

        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                Button full = Ui.primaryButton(this, "Permitir alarme em tela cheia");
                full.setOnClickListener(v -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as permissões especiais e autorize alarmes em tela cheia.", Toast.LENGTH_LONG).show();
                    }
                });
                page.addView(full);
                page.addView(Ui.space(this, 8));
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Button overlay = Ui.primaryButton(this, "Permitir janela sobre outros apps");
            overlay.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "Abra as permissões especiais e permita aparecer sobre outros aplicativos.", Toast.LENGTH_LONG).show();
                }
            });
            page.addView(overlay);
            page.addView(Ui.space(this, 8));
        }
    }

    private void testAlarm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permissão necessária")
                    .setMessage("Para que o alarme apareça por cima de outros aplicativos, autorize primeiro 'Aparecer sobre outros apps'. Depois volte e faça o teste novamente.")
                    .setPositiveButton("Abrir configuração", (d, w) -> {
                        try {
                            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(intent);
                        } catch (Exception ignored) {}
                    })
                    .setNegativeButton("Agora não", null)
                    .show();
            return;
        }
        AlarmScheduler.scheduleTest(this, 1);
        new AlertDialog.Builder(this)
                .setTitle("Teste programado")
                .setMessage("O alarme de teste tocará em aproximadamente 1 minuto. Bloqueie o telefone e deixe a tela apagada. A tela deverá acender sozinha e mostrar o alarme.")
                .setPositiveButton("OK", null)
                .show();
    }

}
