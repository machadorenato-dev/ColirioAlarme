package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MedicineListActivity extends Activity {
    private LinearLayout listContainer;
    private EditText newMedicine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (listContainer != null) renderMedicines();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);

        page.addView(Ui.title(this, "Medicamentos"));
        page.addView(Ui.subtitle(this, "Toque no nome de um colírio para programar, editar ou removê-lo da lista."));

        Button protocols = Ui.primaryButton(this, "Protocolos");
        protocols.setOnClickListener(v -> startActivity(new Intent(this, ProtocolListActivity.class)));
        page.addView(protocols);
        page.addView(Ui.space(this, 8));

        Button guidances = Ui.primaryButton(this, "Orientações");
        guidances.setOnClickListener(v -> startActivity(new Intent(this, GuidanceListActivity.class)));
        page.addView(guidances);

        page.addView(Ui.sectionTitle(this, "Cadastrar novo medicamento"));
        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.VERTICAL);

        newMedicine = new EditText(this);
        newMedicine.setHint("Nome do novo colírio");
        newMedicine.setSingleLine(true);
        newMedicine.setTextSize(17);
        addRow.addView(newMedicine);

        Button add = Ui.primaryButton(this, "Cadastrar");
        add.setOnClickListener(v -> addMedicine());
        addRow.addView(add);
        page.addView(addRow);

        page.addView(Ui.sectionTitle(this, "Medicamentos"));
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        page.addView(listContainer);
        renderMedicines();

        setContentView(scroll);
    }

    private void addMedicine() {
        String name = newMedicine.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "Digite o nome do colírio.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!PlanStore.addCustomMedicine(this, name)) {
            Toast.makeText(this, "Esse colírio já está cadastrado.", Toast.LENGTH_SHORT).show();
            MedicationPlan existing = PlanStore.getPlanForMedicine(this, name);
            showMedicineActions(existing != null ? existing.medicine : name);
            return;
        }
        newMedicine.setText("");
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(newMedicine.getWindowToken(), 0);
        renderMedicines();
        openSchedule(name);
    }

    private void renderMedicines() {
        listContainer.removeAllViews();
        List<String> medicines = PlanStore.getMedicines(this);
        for (String medicine : medicines) {
            MedicationPlan plan = PlanStore.getPlanForMedicine(this, medicine);
            LinearLayout card = Ui.card(this);

            Button select = Ui.secondaryButton(this, medicine + (plan != null ? "   ✓" : ""));
            select.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            select.setOnClickListener(v -> showMedicineActions(medicine));
            card.addView(select);

            if (plan != null) {
                TextView programmed = new TextView(this);
                programmed.setText("Programado: " + plan.eye + " • " + TreatmentText.startSummary(plan) + "\n" + TreatmentText.phasesSummary(plan.phases));
                programmed.setTextSize(14);
                programmed.setTextColor(Ui.MUTED);
                programmed.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), 0, 0);
                card.addView(programmed);
            }
            listContainer.addView(card);
        }
    }

    private void showMedicineActions(String medicine) {
        boolean custom = PlanStore.isCustomMedicine(this, medicine);
        String[] options = custom
                ? new String[]{"Programar / editar tratamento", "Editar nome", "Excluir colírio da lista"}
                : new String[]{"Programar / editar tratamento", "Excluir colírio da lista"};

        new AlertDialog.Builder(this)
                .setTitle(medicine)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        openSchedule(medicine);
                    } else if (custom && which == 1) {
                        showRenameDialog(medicine);
                    } else {
                        confirmHideMedicine(medicine);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void confirmHideMedicine(String medicine) {
        MedicationPlan plan = PlanStore.getPlanForMedicine(this, medicine);
        String message = plan == null
                ? "O colírio deixará de aparecer na lista de cadastro."
                : "O colírio deixará de aparecer na lista de cadastro. A programação e os alarmes já existentes serão mantidos.";
        new AlertDialog.Builder(this)
                .setTitle("Excluir " + medicine + " da lista?")
                .setMessage(message)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> {
                    PlanStore.hideMedicine(this, medicine);
                    renderMedicines();
                    Toast.makeText(this, "Colírio removido da lista.", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showRenameDialog(String oldName) {
        EditText input = new EditText(this);
        input.setText(oldName);
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Editar nome do colírio")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String updated = input.getText().toString().trim();
                    if (!updated.isEmpty()) {
                        MedicationPlan oldPlan = PlanStore.getPlanForMedicine(this, oldName);
                        if (oldPlan != null) AlarmScheduler.cancelPlan(this, oldPlan);
                        PlanStore.renameCustomMedicine(this, oldName, updated);
                        MedicationPlan newPlan = PlanStore.getPlanForMedicine(this, updated);
                        if (newPlan != null) AlarmScheduler.schedulePlan(this, newPlan);
                        renderMedicines();
                    }
                }).show();
    }

    private void openSchedule(String medicine) {
        MedicationPlan plan = PlanStore.getPlanForMedicine(this, medicine);
        Intent intent = new Intent(this, ScheduleActivity.class);
        intent.putExtra("medicine", medicine);
        if (plan != null) intent.putExtra("planId", plan.id);
        startActivity(intent);
    }
}
