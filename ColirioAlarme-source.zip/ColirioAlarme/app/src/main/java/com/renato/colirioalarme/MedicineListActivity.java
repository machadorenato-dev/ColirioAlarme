package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MedicineListActivity extends Activity {
    private LinearLayout listContainer;
    private EditText newMedicine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (listContainer != null) renderMedicines();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = new Button(this);
        back.setText("‹ Voltar");
        back.setAllCaps(false);
        back.setOnClickListener(v -> finish());
        page.addView(back);

        page.addView(Ui.title(this, "Cadastro de colírios"));
        page.addView(Ui.subtitle(this, "Selecione um colírio da lista ou cadastre outro. A lista é exibida em ordem alfabética."));

        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);
        addRow.setGravity(Gravity.CENTER_VERTICAL);

        newMedicine = new EditText(this);
        newMedicine.setHint("Nome do novo colírio");
        newMedicine.setSingleLine(true);
        addRow.addView(newMedicine, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Button add = new Button(this);
        add.setText("Cadastrar");
        add.setAllCaps(false);
        add.setOnClickListener(v -> addMedicine());
        addRow.addView(add);
        page.addView(addRow);

        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.dp(this, 12)));
        page.addView(spacer);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        page.addView(listContainer);
        renderMedicines();

        setContentView(scroll);
    }

    private void addMedicine() {
        String name = newMedicine.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "Digite o nome do colírio.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!PlanStore.addCustomMedicine(this, name)) {
            Toast.makeText(this, "Esse colírio já está cadastrado.", Toast.LENGTH_SHORT).show();
            MedicationPlan existing = PlanStore.getPlanForMedicine(this, name);
            openSchedule(existing != null ? existing.medicine : name);
            return;
        }
        newMedicine.setText("");
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(newMedicine.getWindowToken(), 0);
        renderMedicines();
        openSchedule(name);
    }

    private void renderMedicines() {
        listContainer.removeAllViews();
        List<String> medicines = PlanStore.getMedicines(this);
        for (String medicine : medicines) {
            MedicationPlan plan = PlanStore.getPlanForMedicine(this, medicine);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));

            Button select = Ui.primaryButton(this, medicine + (plan != null ? "   ✓" : ""));
            select.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            select.setOnClickListener(v -> openSchedule(medicine));
            row.addView(select);

            if (plan != null) {
                TextView programmed = new TextView(this);
                programmed.setText("Programado: " + plan.eye + " • " + String.join(" | ", plan.times));
                programmed.setTextSize(14);
                programmed.setPadding(Ui.dp(this, 10), Ui.dp(this, 2), 0, 0);
                row.addView(programmed);
            }

            if (PlanStore.isCustomMedicine(this, medicine)) {
                Button rename = new Button(this);
                rename.setText("Editar nome");
                rename.setAllCaps(false);
                rename.setOnClickListener(v -> showRenameDialog(medicine));
                row.addView(rename);
            }

            listContainer.addView(row);
            listContainer.addView(Ui.divider(this));
        }
    }

    private void showRenameDialog(String oldName) {
        EditText input = new EditText(this);
        input.setText(oldName);
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Editar nome do colírio")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String updated = input.getText().toString().trim();
                    if (!updated.isEmpty()) {
                        MedicationPlan oldPlan = PlanStore.getPlanForMedicine(this, oldName);
                        if (oldPlan != null) AlarmScheduler.cancelPlan(this, oldPlan);
                        PlanStore.renameCustomMedicine(this, oldName, updated);
                        MedicationPlan newPlan = PlanStore.getPlanForMedicine(this, updated);
                        if (newPlan != null) AlarmScheduler.schedulePlan(this, newPlan);
                        renderMedicines();
                    }
                }).show();
    }

    private void openSchedule(String medicine) {
        MedicationPlan plan = PlanStore.getPlanForMedicine(this, medicine);
        Intent intent = new Intent(this, ScheduleActivity.class);
        intent.putExtra("medicine", medicine);
        if (plan != null) intent.putExtra("planId", plan.id);
        startActivity(intent);
    }
}
