package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class GuidanceEditActivity extends Activity {
    private Guidance guidance;
    private EditText title;
    private EditText text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        guidance = GuidanceStore.getById(this, getIntent().getStringExtra("guidanceId"));
        if (guidance == null) {
            finish();
            return;
        }
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Editar orientação"));

        title = new EditText(this);
        title.setHint("Título");
        title.setText(guidance.title);
        title.setTextSize(18);
        page.addView(title);

        page.addView(Ui.space(this, 10));
        text = new EditText(this);
        text.setHint("Escreva aqui as orientações pós-operatórias que deseja enviar ao paciente.");
        text.setText(guidance.text);
        text.setTextSize(17);
        text.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        text.setMinLines(10);
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        page.addView(text);

        page.addView(Ui.space(this, 14));
        Button save = Ui.primaryButton(this, "Salvar orientação");
        save.setOnClickListener(v -> save());
        page.addView(save);
        page.addView(Ui.space(this, 8));

        Button delete = Ui.dangerButton(this, "Excluir orientação");
        delete.setOnClickListener(v -> confirmDelete());
        page.addView(delete);
        setContentView(scroll);
    }

    private void save() {
        String t = title.getText().toString().trim();
        if (t.isEmpty()) {
            Toast.makeText(this, "Digite um título.", Toast.LENGTH_SHORT).show();
            return;
        }
        guidance.title = t;
        guidance.text = text.getText().toString().trim();
        GuidanceStore.save(this, guidance);
        Toast.makeText(this, "Orientação salva.", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Excluir orientação?")
                .setMessage("Essa orientação será removida da lista.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> {
                    GuidanceStore.delete(this, guidance.id);
                    finish();
                }).show();
    }
}
