package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** Tela inicial de escolha do perfil de acesso. */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AlarmScheduler.scheduleAll(this);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);

        page.addView(Ui.title(this, "Colírio Alarme"));
        page.addView(Ui.subtitle(this, "Escolha como deseja entrar."));
        page.addView(Ui.space(this, 18));

        Button patient = Ui.primaryButton(this, "Sou paciente");
        patient.setOnClickListener(v -> startActivity(new Intent(this, PatientLoginActivity.class)));
        page.addView(patient);
        page.addView(Ui.space(this, 12));

        Button doctor = Ui.primaryButton(this, "Sou médico");
        doctor.setOnClickListener(v -> startActivity(new Intent(this, DoctorLoginActivity.class)));
        page.addView(doctor);

        setContentView(scroll);
    }
}
