package com.renato.colirioalarme;

import android.Manifest;
import android.app.AlarmManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText nameInput, messageInput;
    private Button timeButton;
    private LinearLayout list;
    private int selectedHour = -1, selectedMinute = -1;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.medicineName);
        messageInput = findViewById(R.id.customMessage);
        timeButton = findViewById(R.id.timeButton);
        list = findViewById(R.id.reminderList);

        requestNotificationPermission();
        timeButton.setOnClickListener(v -> chooseTime());
        findViewById(R.id.addButton).setOnClickListener(v -> addReminder());
        findViewById(R.id.testVoiceButton).setOnClickListener(v -> testVoice());
        findViewById(R.id.exactAlarmButton).setOnClickListener(v -> requestExactAlarmPermission());
        renderList();
    }

    @Override protected void onResume() {
        super.onResume();
        AlarmScheduler.scheduleAll(this);
    }

    private void chooseTime() {
        Calendar now = Calendar.getInstance();
        int h = selectedHour >= 0 ? selectedHour : now.get(Calendar.HOUR_OF_DAY);
        int m = selectedMinute >= 0 ? selectedMinute : now.get(Calendar.MINUTE);
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            selectedHour = hourOfDay;
            selectedMinute = minute;
            timeButton.setText(String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute));
        }, h, m, true).show();
    }

    private void addReminder() {
        String name = nameInput.getText().toString().trim();
        String message = messageInput.getText().toString().trim();
        if (name.isEmpty()) { Toast.makeText(this, "Digite o nome do colírio.", Toast.LENGTH_SHORT).show(); return; }
        if (selectedHour < 0) { Toast.makeText(this, "Escolha o horário.", Toast.LENGTH_SHORT).show(); return; }

        int id = (int) (System.currentTimeMillis() & 0x7fffffff);
        Reminder reminder = new Reminder(id, name, selectedHour, selectedMinute, message);
        ReminderStore.add(this, reminder);
        AlarmScheduler.schedule(this, reminder);

        nameInput.setText("");
        messageInput.setText("");
        selectedHour = selectedMinute = -1;
        timeButton.setText("Escolher horário");
        renderList();
        Toast.makeText(this, "Lembrete adicionado.", Toast.LENGTH_SHORT).show();
    }

    private void renderList() {
        list.removeAllViews();
        for (Reminder r : ReminderStore.getAll(this)) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 12, 0, 12);

            TextView text = new TextView(this);
            text.setText(String.format(Locale.getDefault(), "%02d:%02d  —  %s", r.hour, r.minute, r.name));
            text.setTextSize(17);
            text.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button del = new Button(this);
            del.setText("Excluir");
            del.setOnClickListener(v -> {
                AlarmScheduler.cancel(this, r.id);
                ReminderStore.remove(this, r.id);
                renderList();
            });
            row.addView(text);
            row.addView(del);
            list.addView(row);
        }
        if (list.getChildCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Nenhum lembrete cadastrado.");
            empty.setTextSize(16);
            empty.setPadding(0, 12, 0, 12);
            list.addView(empty);
        }
    }

    private void testVoice() {
        String name = nameInput.getText().toString().trim();
        String custom = messageInput.getText().toString().trim();
        String phrase = !custom.isEmpty() ? custom : (name.isEmpty() ? "Está na hora do seu colírio" : "Está na hora do seu colírio " + name);
        final TextToSpeech[] holder = new TextToSpeech[1];
        holder[0] = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                holder[0].setLanguage(new Locale("pt", "BR"));
                holder[0].speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "test");
                new android.os.Handler(getMainLooper()).postDelayed(holder[0]::shutdown, 8000);
            } else {
                Toast.makeText(this, "Não foi possível iniciar a voz do Android.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                }
            } else {
                Toast.makeText(this, "Alarmes exatos já estão permitidos.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Seu Android não exige essa permissão.", Toast.LENGTH_SHORT).show();
        }
    }
}
