package com.renato.colirioalarme;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private static final int OPEN_PROGRAM = 3001;
    private LinearLayout page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (page != null) render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        page = Ui.verticalPage(this);
        scroll.addView(page);

        page.addView(Ui.title(this, "Colírio Alarme"));
        page.addView(Ui.subtitle(this, "Seus colírios e horários do dia, de forma simples."));

        page.addView(Ui.sectionTitle(this, "Horários cadastrados"));
        List<MedicationPlan> plans = PlanStore.getPlans(this);
        if (plans.isEmpty()) {
            LinearLayout emptyCard = Ui.card(this);
            emptyCard.addView(Ui.subtitle(this, "Nenhum colírio programado. Use o botão Programação no fim da tela para começar."));
            page.addView(emptyCard);
        } else {
            for (MedicationPlan plan : plans) addPlanCard(plan);
        }

        Guidance active = GuidanceStore.getActive(this);
        if (active != null) {
            page.addView(Ui.sectionTitle(this, "Orientações pós-operatórias"));
            LinearLayout card = Ui.card(this);
            TextView title = new TextView(this);
            title.setText(active.title);
            title.setTextSize(18);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setTextColor(Ui.TEXT);
            card.addView(title);
            Button view = Ui.secondaryButton(this, "Ver orientações");
            view.setOnClickListener(v -> showGuidance(active));
            card.addView(view);
            page.addView(card);
        }

        page.addView(Ui.sectionTitle(this, "Enviar ou receber"));
        Button share = Ui.primaryButton(this, "Enviar programação ao paciente");
        share.setOnClickListener(v -> ProgramTransfer.share(this));
        page.addView(share);
        page.addView(Ui.space(this, 8));

        Button importProgram = Ui.secondaryButton(this, "Importar programação recebida");
        importProgram.setOnClickListener(v -> chooseProgramFile());
        page.addView(importProgram);

        page.addView(Ui.space(this, 14));
        addPermissionButtons();

        Button testVoice = Ui.secondaryButton(this, "Testar alarme");
        testVoice.setOnClickListener(v -> testVoice());
        page.addView(testVoice);

        page.addView(Ui.space(this, 24));
        Button programming = Ui.primaryButton(this, "Programação");
        programming.setOnClickListener(v -> startActivity(new Intent(this, MedicineListActivity.class)));
        page.addView(programming);

        setContentView(scroll);
    }

    private void addPlanCard(MedicationPlan plan) {
        LinearLayout card = Ui.card(this);

        TextView name = new TextView(this);
        name.setText(plan.medicine);
        name.setTextSize(20);
        name.setTextColor(Ui.TEXT);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(name);

        TextView eye = new TextView(this);
        eye.setText(plan.eye);
        eye.setTextSize(16);
        eye.setTextColor(Ui.MUTED);
        eye.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 4));
        card.addView(eye);

        TextView details = new TextView(this);
        details.setText(String.join("   •   ", plan.times));
        details.setTextSize(18);
        details.setTextColor(Ui.BLUE_DARK);
        details.setTypeface(null, android.graphics.Typeface.BOLD);
        details.setPadding(0, 0, 0, Ui.dp(this, 8));
        card.addView(details);

        Button edit = Ui.secondaryButton(this, "Editar horário");
        edit.setOnClickListener(v -> {
            Intent intent = new Intent(this, ScheduleActivity.class);
            intent.putExtra("planId", plan.id);
            intent.putExtra("medicine", plan.medicine);
            startActivity(intent);
        });
        card.addView(edit);
        page.addView(card);
    }

    private void showGuidance(Guidance guidance) {
        new AlertDialog.Builder(this)
                .setTitle(guidance.title)
                .setMessage(guidance.text == null || guidance.text.trim().isEmpty()
                        ? "Nenhum texto cadastrado nesta orientação." : guidance.text)
                .setPositiveButton("Fechar", null)
                .show();
    }

    private void addPermissionButtons() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Button notification = Ui.primaryButton(this, "Permitir notificações");
            notification.setOnClickListener(v -> requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001));
            page.addView(notification);
            page.addView(Ui.space(this, 8));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (manager != null && !manager.canScheduleExactAlarms()) {
                Button exact = Ui.primaryButton(this, "Permitir alarmes exatos");
                exact.setOnClickListener(v -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as permissões do aplicativo e autorize alarmes e lembretes.", Toast.LENGTH_LONG).show();
                    }
                });
                page.addView(exact);
                page.addView(Ui.space(this, 8));
            }
        }

        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                Button full = Ui.primaryButton(this, "Permitir alarme em tela cheia");
                full.setOnClickListener(v -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as permissões especiais e autorize alarmes em tela cheia.", Toast.LENGTH_LONG).show();
                    }
                });
                page.addView(full);
                page.addView(Ui.space(this, 8));
            }
        }
    }

    private void testVoice() {
        Intent service = new Intent(this, AlarmService.class);
        service.putExtra("medicine", "de teste");
        service.putExtra("eye", "Ambos os olhos");
        service.putExtra("time", "Agora");
        service.putExtra("planId", "test");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível iniciar o alarme. Verifique as permissões do aplicativo.", Toast.LENGTH_LONG).show();
        }
    }

    private void chooseProgramFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, OPEN_PROGRAM);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OPEN_PROGRAM && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Intent open = new Intent(this, ImportActivity.class);
            open.putExtra("uri", data.getData().toString());
            startActivity(open);
        }
    }
}
