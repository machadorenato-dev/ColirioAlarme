package com.renato.colirioalarme;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (page != null) render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        page = Ui.verticalPage(this);
        scroll.addView(page);

        page.addView(Ui.title(this, "Colírio Alarme"));
        page.addView(Ui.subtitle(this, "Organize os colírios, o olho em que serão usados e todos os horários de cada um."));

        Button programming = Ui.primaryButton(this, "Programação");
        programming.setOnClickListener(v -> startActivity(new Intent(this, MedicineListActivity.class)));
        page.addView(programming);

        addSpace(14);
        TextView heading = new TextView(this);
        heading.setText("Programações cadastradas");
        heading.setTextSize(19);
        heading.setPadding(0, 0, 0, Ui.dp(this, 8));
        page.addView(heading);

        List<MedicationPlan> plans = PlanStore.getPlans(this);
        if (plans.isEmpty()) {
            TextView empty = Ui.subtitle(this, "Nenhum colírio programado. Toque em Programação para começar.");
            page.addView(empty);
        } else {
            for (MedicationPlan plan : plans) addPlanCard(plan);
        }

        addSpace(14);
        addPermissionButtons();

        Button testVoice = Ui.primaryButton(this, "Testar voz do alarme");
        testVoice.setOnClickListener(v -> testVoice());
        page.addView(testVoice);

        setContentView(scroll);
    }

    private void addPlanCard(MedicationPlan plan) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));

        TextView name = new TextView(this);
        name.setText(plan.medicine);
        name.setTextSize(18);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(name);

        TextView details = new TextView(this);
        details.setText(plan.eye + "  •  " + String.join("  |  ", plan.times));
        details.setTextSize(15);
        details.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 6));
        card.addView(details);

        Button edit = new Button(this);
        edit.setText("Editar programação");
        edit.setAllCaps(false);
        edit.setOnClickListener(v -> {
            Intent intent = new Intent(this, ScheduleActivity.class);
            intent.putExtra("planId", plan.id);
            intent.putExtra("medicine", plan.medicine);
            startActivity(intent);
        });
        card.addView(edit);
        page.addView(card);
        page.addView(Ui.divider(this));
    }

    private void addPermissionButtons() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Button notification = Ui.primaryButton(this, "Permitir notificações");
            notification.setOnClickListener(v -> requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001));
            page.addView(notification);
            addSpace(8);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (manager != null && !manager.canScheduleExactAlarms()) {
                Button exact = Ui.primaryButton(this, "Permitir alarmes exatos");
                exact.setOnClickListener(v -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(this, "Abra as permissões do aplicativo e autorize alarmes e lembretes.", Toast.LENGTH_LONG).show();
                    }
                });
                page.addView(exact);
                addSpace(8);
            }
        }
    }

    private void testVoice() {
        Intent service = new Intent(this, AlarmService.class);
        service.putExtra("medicine", "de teste");
        service.putExtra("eye", "Ambos os olhos");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível iniciar a voz. Verifique as permissões do aplicativo.", Toast.LENGTH_LONG).show();
        }
    }

    private void addSpace(int dp) {
        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.dp(this, dp)));
        page.addView(space);
    }
}
