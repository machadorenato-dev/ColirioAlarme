package com.renato.colirioalarme;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/** Aplica uma programação recebida por arquivo ou Firebase e recalcula os alarmes. */
public final class ProgramImportService {
    private ProgramImportService() {}

    public static int apply(Context context, JSONObject imported) throws Exception {
        if (imported == null || !ProgramTransfer.MARKER.equals(imported.optString("app"))) {
            throw new Exception("Programação não reconhecida");
        }

        boolean preservePatientTimes = imported.optBoolean("preservePatientTimes", false);
        JSONObject patient = imported.optJSONObject("patient");
        if (patient != null) {
            PatientProfileStore.save(context,
                    patient.optString("id", ""),
                    patient.optString("name", ""),
                    patient.optString("phone", ""));
            long surgeryDate = imported.optLong("surgeryDateMillis",
                    patient.optLong("surgeryDateMillis", System.currentTimeMillis()));
            PatientProfileStore.saveSurgery(context,
                    patient.optString("surgeryType", ""),
                    patient.optString("operatedEye", ""),
                    surgeryDate);
            String firebaseToken = imported.optString("firebaseToken", "").trim();
            if (!firebaseToken.isEmpty()) PatientProfileStore.saveLinkToken(context, firebaseToken);

            // Programação nominal substitui a anterior; numa alteração só da data preserva os horários escolhidos pelo paciente.
            if (!preservePatientTimes) {
                for (MedicationPlan oldPlan : new ArrayList<>(PlanStore.getPlans(context))) {
                    AlarmScheduler.cancelPlan(context, oldPlan);
                    PlanStore.deletePlan(context, oldPlan.id);
                }
            }
        }

        JSONArray plans = imported.optJSONArray("plans");
        ArrayList<MedicationPlan> importedPlans = new ArrayList<>();
        int importedCount = 0;
        long rootAnchor = imported.optLong("surgeryDateMillis", 0L);
        if (rootAnchor <= 0 && patient != null) rootAnchor = patient.optLong("surgeryDateMillis", 0L);
        if (rootAnchor <= 0) rootAnchor = System.currentTimeMillis();
        rootAnchor = TreatmentUtils.midnight(rootAnchor);

        if (preservePatientTimes) {
            int count = 0;
            for (MedicationPlan old : new ArrayList<>(PlanStore.getPlans(context))) {
                AlarmScheduler.cancelPlan(context, old);
                MedicationPlan shifted = new MedicationPlan(old.id, old.medicine, old.eye, old.phases,
                        old.startDelayDays, old.startsAfterMedicine, rootAnchor);
                PlanStore.savePlan(context, shifted);
                count++;
            }
            AlarmScheduler.scheduleAll(context);
            PatientProfileStore.saveLastRemoteProgramCreatedAt(context, imported.optLong("createdAt", System.currentTimeMillis()));
            FirebasePatientSync.uploadCurrentPlans(context);
            return count;
        }

        if (plans != null) {
            for (int i = 0; i < plans.length(); i++) {
                JSONObject obj = plans.optJSONObject(i);
                if (obj == null) continue;
                String medicine = obj.optString("medicine", "").trim();
                String eye = obj.optString("eye", "Ambos os olhos");
                ArrayList<TreatmentPhase> phases = PlanStore.readPhases(obj);
                if (phases.isEmpty()) phases.add(new TreatmentPhase(0, PlanStore.readTimes(obj.optJSONArray("times"))));
                boolean hasTime = false;
                for (TreatmentPhase p : phases) if (!p.times.isEmpty()) hasTime = true;
                if (medicine.isEmpty() || !hasTime) continue;

                int delay = Math.max(0, obj.optInt("startDelayDays", 0));
                String after = obj.optString("startsAfterMedicine", "");
                long anchor = obj.optLong("anchorDateMillis", rootAnchor);
                if (anchor <= 0) anchor = rootAnchor;
                MedicationPlan old = PlanStore.getPlanForMedicine(context, medicine);
                if (old != null) AlarmScheduler.cancelPlan(context, old);
                MedicationPlan plan = old == null
                        ? new MedicationPlan(medicine, eye, phases, delay, after, anchor)
                        : new MedicationPlan(old.id, medicine, eye, phases, delay, after, anchor);
                PlanStore.savePlan(context, plan);
                importedPlans.add(plan);
                importedCount++;
            }
            for (MedicationPlan plan : importedPlans) AlarmScheduler.schedulePlan(context, plan);
        }

        JSONObject guidance = imported.optJSONObject("guidance");
        if (guidance != null && !guidance.optString("text", "").trim().isEmpty()) {
            String internalTitle = guidance.optString("title", "Orientações");
            if (internalTitle.trim().isEmpty()) internalTitle = "Orientações";
            GuidanceStore.importAndActivate(context, internalTitle, guidance.optString("text", ""));
        } else GuidanceStore.clearActive(context);

        PatientProfileStore.saveLastRemoteProgramCreatedAt(context, imported.optLong("createdAt", System.currentTimeMillis()));
        FirebasePatientSync.uploadCurrentPlans(context);
        return importedCount;
    }
}
