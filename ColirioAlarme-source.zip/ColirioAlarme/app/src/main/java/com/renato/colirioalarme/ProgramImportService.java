package com.renato.colirioalarme;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Aplica uma programação recebida por arquivo ou Firebase e recalcula os alarmes. */
public final class ProgramImportService {
    private ProgramImportService() {}

    /** Remove do aparelho do paciente a programação que foi retirada pelo médico. */
    public static void clearPatientProgram(Context context) {
        List<MedicationPlan> local = new ArrayList<>(PlanStore.getPlans(context));
        for (MedicationPlan old : local) {
            AlarmScheduler.cancelPlan(context, old);
            PlanStore.deletePlan(context, old.id);
        }
        GuidanceStore.clearActive(context);
        AlarmScheduler.scheduleAll(context);
        FirebasePatientSync.uploadCurrentPlans(context);
    }

    public static int apply(Context context, JSONObject imported) throws Exception {
        if (imported == null || !ProgramTransfer.MARKER.equals(imported.optString("app"))) {
            throw new Exception("Programação não reconhecida");
        }

        List<MedicationPlan> localBefore = new ArrayList<>(PlanStore.getPlans(context));
        boolean preservePatientTimes = imported.optBoolean("preservePatientTimes", false) && !localBefore.isEmpty();
        JSONObject patient = imported.optJSONObject("patient");
        if (patient != null) {
            PatientProfileStore.save(context,
                    patient.optString("id", ""),
                    patient.optString("name", ""),
                    patient.optString("phone", ""));
            long surgeryDate = imported.optLong("surgeryDateMillis",
                    patient.optLong("surgeryDateMillis", System.currentTimeMillis()));
            PatientProfileStore.saveSurgery(context,
                    patient.optString("surgeryType", ""),
                    patient.optString("operatedEye", ""),
                    surgeryDate);
            String firebaseToken = imported.optString("firebaseToken", "").trim();
            if (!firebaseToken.isEmpty()) PatientProfileStore.saveLinkToken(context, firebaseToken);
        }

        JSONArray plans = imported.optJSONArray("plans");
        int importedCount;
        long rootAnchor = imported.optLong("surgeryDateMillis", 0L);
        if (rootAnchor <= 0 && patient != null) rootAnchor = patient.optLong("surgeryDateMillis", 0L);
        if (rootAnchor <= 0) rootAnchor = System.currentTimeMillis();
        rootAnchor = TreatmentUtils.midnight(rootAnchor);

        if (preservePatientTimes) {
            importedCount = mergeRemotePreservingPatientTimes(context, plans, localBefore, imported, rootAnchor);
        } else {
            importedCount = replaceWithRemoteProgram(context, plans, localBefore, rootAnchor);
        }

        applyGuidance(context, imported.optJSONObject("guidance"));
        PatientProfileStore.saveLastRemoteProgramCreatedAt(context,
                imported.optLong("createdAt", System.currentTimeMillis()));
        AlarmScheduler.scheduleAll(context);
        FirebasePatientSync.uploadCurrentPlans(context);
        return importedCount;
    }

    private static int replaceWithRemoteProgram(Context context, JSONArray plans,
                                                List<MedicationPlan> localBefore, long rootAnchor) {
        for (MedicationPlan old : localBefore) {
            AlarmScheduler.cancelPlan(context, old);
            PlanStore.deletePlan(context, old.id);
        }
        if (plans == null) return 0;
        int count = 0;
        for (int i = 0; i < plans.length(); i++) {
            JSONObject obj = plans.optJSONObject(i);
            MedicationPlan plan = planFromRemote(obj, null, rootAnchor);
            if (plan == null) continue;
            PlanStore.savePlan(context, plan);
            count++;
        }
        return count;
    }

    /**
     * Mantém somente os horários escolhidos pelo paciente. Duração, olho, data de início,
     * dependências e lista de medicamentos continuam sendo definidos pelo médico.
     */
    private static int mergeRemotePreservingPatientTimes(Context context, JSONArray plans,
                                                          List<MedicationPlan> localBefore,
                                                          JSONObject imported, long rootAnchor) {
        if (plans == null) return 0;
        String renameFrom = imported.optString("replaceMedicineFrom", "").trim();
        String renameTo = imported.optString("replaceMedicineTo", "").trim();

        for (MedicationPlan old : localBefore) {
            AlarmScheduler.cancelPlan(context, old);
            PlanStore.deletePlan(context, old.id);
        }

        int count = 0;
        for (int i = 0; i < plans.length(); i++) {
            JSONObject obj = plans.optJSONObject(i);
            if (obj == null) continue;
            String remoteName = obj.optString("medicine", "").trim();
            if (remoteName.isEmpty()) continue;

            MedicationPlan matchingLocal = findByMedicine(localBefore, remoteName);
            if (matchingLocal == null && !renameFrom.isEmpty() && !renameTo.isEmpty()
                    && remoteName.equalsIgnoreCase(renameTo)) {
                matchingLocal = findByMedicine(localBefore, renameFrom);
            }

            MedicationPlan merged = planFromRemote(obj, matchingLocal, rootAnchor);
            if (merged == null) continue;
            PlanStore.savePlan(context, merged);
            count++;
        }
        return count;
    }

    private static MedicationPlan planFromRemote(JSONObject obj, MedicationPlan localTimes, long rootAnchor) {
        if (obj == null) return null;
        String medicine = obj.optString("medicine", "").trim();
        if (medicine.isEmpty()) return null;
        String eye = obj.optString("eye", "Ambos os olhos");
        ArrayList<TreatmentPhase> remotePhases = PlanStore.readPhases(obj);
        if (remotePhases.isEmpty()) remotePhases.add(new TreatmentPhase(0, PlanStore.readTimes(obj.optJSONArray("times"))));

        if (localTimes != null) {
            for (int i = 0; i < remotePhases.size() && i < localTimes.phases.size(); i++) {
                TreatmentPhase localPhase = localTimes.phases.get(i);
                if (localPhase != null && !localPhase.times.isEmpty()) {
                    remotePhases.get(i).times.clear();
                    remotePhases.get(i).times.addAll(localPhase.times);
                }
            }
        }

        boolean hasTime = false;
        for (TreatmentPhase p : remotePhases) if (!p.times.isEmpty()) hasTime = true;
        if (!hasTime) return null;

        int delay = Math.max(0, obj.optInt("startDelayDays", 0));
        String after = obj.optString("startsAfterMedicine", "");
        long anchor = obj.optLong("anchorDateMillis", rootAnchor);
        if (rootAnchor > 0) anchor = rootAnchor;
        if (anchor <= 0) anchor = System.currentTimeMillis();

        return localTimes == null
                ? new MedicationPlan(medicine, eye, remotePhases, delay, after, anchor)
                : new MedicationPlan(localTimes.id, medicine, eye, remotePhases, delay, after, anchor);
    }

    private static MedicationPlan findByMedicine(List<MedicationPlan> plans, String medicine) {
        if (medicine == null) return null;
        for (MedicationPlan plan : plans) if (medicine.equalsIgnoreCase(plan.medicine)) return plan;
        return null;
    }

    private static void applyGuidance(Context context, JSONObject guidance) {
        if (guidance != null && !guidance.optString("text", "").trim().isEmpty()) {
            String internalTitle = guidance.optString("title", "Orientações");
            if (internalTitle.trim().isEmpty()) internalTitle = "Orientações";
            GuidanceStore.importAndActivate(context, internalTitle, guidance.optString("text", ""));
        } else {
            GuidanceStore.clearActive(context);
        }
    }
}
