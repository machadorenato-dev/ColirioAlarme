package com.renato.colirioalarme;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SignatureDrawActivity extends Activity {
    public static final String EXTRA_SIGNATURE_BASE64 = "signatureBase64";
    private SignatureView signatureView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = Ui.verticalPage(this);
        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Criar assinatura"));
        page.addView(Ui.subtitle(this, "Assine no espaço abaixo usando o dedo ou uma caneta compatível."));

        signatureView = new SignatureView(this);
        LinearLayout.LayoutParams canvasParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 260));
        canvasParams.setMargins(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        page.addView(signatureView, canvasParams);

        TextView note = Ui.subtitle(this, "A assinatura salva será usada visualmente nas receitas em PDF. Ela não substitui uma assinatura digital por certificado.");
        page.addView(note);

        Button clear = Ui.secondaryButton(this, "Limpar / refazer");
        clear.setOnClickListener(v -> signatureView.clear());
        page.addView(clear);
        page.addView(Ui.space(this, 10));

        Button save = Ui.primaryButton(this, "Salvar assinatura");
        save.setOnClickListener(v -> saveSignature());
        page.addView(save);
        setContentView(page);
    }

    private void saveSignature() {
        if (signatureView == null || !signatureView.hasInk()) {
            Toast.makeText(this, "Faça sua assinatura antes de salvar.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Bitmap bitmap = signatureView.toBitmap();
            String base64 = ImageDataUtil.bitmapToBase64(bitmap, Bitmap.CompressFormat.JPEG, 88, 900, 350);
            bitmap.recycle();
            Intent result = new Intent();
            result.putExtra(EXTRA_SIGNATURE_BASE64, base64);
            setResult(RESULT_OK, result);
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível salvar a assinatura.", Toast.LENGTH_LONG).show();
        }
    }

    private static final class SignatureView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private boolean hasInk = false;

        SignatureView(Activity context) {
            super(context);
            setBackgroundColor(Color.WHITE);
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(context, 3));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            setContentDescription("Área para desenhar a assinatura");
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawPath(path, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX();
            float y = event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    path.moveTo(x, y);
                    hasInk = true;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    path.lineTo(x, y);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    path.lineTo(x, y);
                    invalidate();
                    performClick();
                    return true;
                default:
                    return true;
            }
        }

        @Override
        public boolean performClick() {
            super.performClick();
            return true;
        }

        void clear() {
            path.reset();
            hasInk = false;
            invalidate();
        }

        boolean hasInk() { return hasInk; }

        Bitmap toBitmap() {
            int w = Math.max(1, getWidth());
            int h = Math.max(1, getHeight());
            Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            canvas.drawPath(path, paint);
            return bitmap;
        }
    }
}
