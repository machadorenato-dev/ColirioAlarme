package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class PatientScheduleAdjustActivity extends Activity {
    private List<MedicationPlan> currentPlans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    private void render() {
        currentPlans = PlanStore.getPlans(this);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Ajustar meus horários"));
        page.addView(Ui.subtitle(this,
                "Você pode adiantar ou atrasar todos os horários sem alterar os medicamentos, a duração ou o desmame definidos pelo médico."));

        LinearLayout card = Ui.card(this);
        card.addView(Ui.sectionTitle(this, "Horários atuais"));
        card.addView(Ui.subtitle(this, currentRange(currentPlans)));
        page.addView(card);

        Button shift = Ui.primaryButton(this, "Adiantar / atrasar horários");
        shift.setOnClickListener(v -> showShiftDialog());
        page.addView(shift);
        setContentView(scroll);
    }

    private void showShiftDialog() {
        if (earliestMinute(currentPlans) < 0) {
            Toast.makeText(this, "Não há horários para ajustar.", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 22);
        box.setPadding(pad, Ui.dp(this, 8), pad, 0);

        RadioGroup direction = new RadioGroup(this);
        direction.setOrientation(RadioGroup.VERTICAL);
        RadioButton advance = new RadioButton(this);
        advance.setText("Adiantar");
        advance.setId(android.view.View.generateViewId());
        RadioButton delay = new RadioButton(this);
        delay.setText("Atrasar");
        delay.setId(android.view.View.generateViewId());
        direction.addView(advance);
        direction.addView(delay);
        delay.setChecked(true);
        box.addView(direction);

        EditText hours = new EditText(this);
        hours.setHint("Quantas horas? Ex.: 2 ou 0,5");
        hours.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(hours);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Alterar todos os horários")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Continuar", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String raw = hours.getText().toString().trim().replace(',', '.');
            double value;
            try { value = Double.parseDouble(raw); }
            catch (Exception e) { value = 0; }
            if (value <= 0 || value > 23.99) {
                Toast.makeText(this, "Digite uma quantidade válida de horas.", Toast.LENGTH_LONG).show();
                return;
            }
            int minutes = (int) Math.round(value * 60.0);
            boolean isAdvance = direction.getCheckedRadioButtonId() == advance.getId();
            int delta = isAdvance ? -minutes : minutes;
            dialog.dismiss();

            ArrayList<MedicationPlan> adjusted = copyPlans(currentPlans);
            boolean crossed = shiftAll(adjusted, delta);
            String action = isAdvance ? "Adiantar" : "Atrasar";
            showPreview(adjusted, action + " todos os horários em " + formatAmount(minutes) + "?",
                    crossed ? "Atenção: algum horário atravessará a meia-noite. Confira a prévia antes de confirmar." : "");
        }));
        dialog.show();
    }

    private void showPreview(ArrayList<MedicationPlan> adjusted, String title, String warning) {
        StringBuilder text = new StringBuilder();
        if (warning != null && !warning.isEmpty()) text.append(warning).append("\n\n");
        for (MedicationPlan plan : adjusted) {
            text.append(plan.medicine).append("\n");
            for (int i = 0; i < plan.phases.size(); i++) {
                TreatmentPhase phase = plan.phases.get(i);
                text.append(plan.phases.size() > 1 ? "Etapa " + (i + 1) + ": " : "");
                text.append(String.join(", ", phase.times)).append("\n");
            }
            text.append("\n");
        }
        new AlertDialog.Builder(this).setTitle(title).setMessage(text.toString().trim())
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Confirmar", (d, w) -> apply(adjusted)).show();
    }

    private void apply(List<MedicationPlan> adjusted) {
        for (MedicationPlan old : PlanStore.getPlans(this)) AlarmScheduler.cancelPlan(this, old);
        for (MedicationPlan plan : adjusted) PlanStore.savePlan(this, plan);
        AlarmScheduler.scheduleAll(this);
        FirebasePatientSync.uploadCurrentPlans(this);
        Toast.makeText(this, "Todos os horários foram ajustados.", Toast.LENGTH_LONG).show();
        render();
    }

    private ArrayList<MedicationPlan> copyPlans(List<MedicationPlan> source) {
        ArrayList<MedicationPlan> result = new ArrayList<>();
        for (MedicationPlan p : source) {
            result.add(new MedicationPlan(p.id, p.medicine, p.eye, p.phases,
                    p.startDelayDays, p.startsAfterMedicine, p.anchorDateMillis));
        }
        return result;
    }

    private boolean shiftAll(List<MedicationPlan> plans, int delta) {
        boolean crossed = false;
        for (MedicationPlan plan : plans) {
            for (TreatmentPhase phase : plan.phases) {
                ArrayList<String> next = new ArrayList<>();
                for (String time : phase.times) {
                    int old = parseMinute(time);
                    if (old < 0) continue;
                    int raw = old + delta;
                    if (raw < 0 || raw >= 1440) crossed = true;
                    int normalized = ((raw % 1440) + 1440) % 1440;
                    String value = formatMinute(normalized);
                    if (!next.contains(value)) next.add(value);
                }
                Collections.sort(next);
                phase.times.clear();
                phase.times.addAll(next);
            }
            plan.syncLegacyTimes();
        }
        return crossed;
    }

    private int earliestMinute(List<MedicationPlan> plans) {
        int best = Integer.MAX_VALUE;
        for (MedicationPlan plan : plans) for (TreatmentPhase phase : plan.phases)
            for (String time : phase.times) {
                int v = parseMinute(time);
                if (v >= 0 && v < best) best = v;
            }
        return best == Integer.MAX_VALUE ? -1 : best;
    }

    private int latestMinute(List<MedicationPlan> plans) {
        int best = -1;
        for (MedicationPlan plan : plans) for (TreatmentPhase phase : plan.phases)
            for (String time : phase.times) best = Math.max(best, parseMinute(time));
        return best;
    }

    private String currentRange(List<MedicationPlan> plans) {
        int first = earliestMinute(plans), last = latestMinute(plans);
        if (first < 0 || last < 0) return "Nenhum horário cadastrado.";
        return "Primeiro horário: " + formatMinute(first) + "\nÚltimo horário: " + formatMinute(last);
    }

    private int parseMinute(String time) {
        try {
            String[] p = time.split(":");
            if (p.length != 2) return -1;
            int h = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
            if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
            return h * 60 + m;
        } catch (Exception e) { return -1; }
    }

    private String formatMinute(int minute) {
        int v = ((minute % 1440) + 1440) % 1440;
        return String.format(Locale.getDefault(), "%02d:%02d", v / 60, v % 60);
    }

    private String formatAmount(int minutes) {
        int h = minutes / 60;
        int m = minutes % 60;
        if (m == 0) return h + (h == 1 ? " hora" : " horas");
        if (h == 0) return m + " minutos";
        return h + (h == 1 ? " hora e " : " horas e ") + m + " minutos";
    }
}
