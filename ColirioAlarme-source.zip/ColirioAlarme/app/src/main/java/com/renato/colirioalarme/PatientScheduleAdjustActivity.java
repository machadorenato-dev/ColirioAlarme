package com.renato.colirioalarme;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class PatientScheduleAdjustActivity extends Activity {
    private List<MedicationPlan> currentPlans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    private void render() {
        currentPlans = PlanStore.getPlans(this);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.verticalPage(this);
        scroll.addView(page);
        Button back = Ui.secondaryButton(this, "‹ Voltar");
        back.setOnClickListener(v -> finish());
        page.addView(back);
        page.addView(Ui.title(this, "Ajustar meus horários"));
        page.addView(Ui.subtitle(this,
                "Você pode adaptar os horários ao seu sono sem alterar os colírios, a duração ou o desmame definidos pelo médico."));

        String range = currentRange(currentPlans);
        LinearLayout card = Ui.card(this);
        card.addView(Ui.sectionTitle(this, "Horários atuais"));
        card.addView(Ui.subtitle(this, range));
        page.addView(card);

        Button shift = Ui.primaryButton(this, "Mudar o primeiro horário do dia");
        shift.setOnClickListener(v -> pickNewFirstTime());
        page.addView(shift);
        page.addView(Ui.space(this, 9));

        Button redistribute = Ui.primaryButton(this, "Definir início e término do dia");
        redistribute.setOnClickListener(v -> pickStartTime());
        page.addView(redistribute);
        page.addView(Ui.space(this, 12));

        LinearLayout info = Ui.card(this);
        info.addView(Ui.subtitle(this,
                "Exemplo: se o primeiro horário for 06:00 e você escolher 08:00, todos os horários serão deslocados em +2 horas. Na opção início/término, as aplicações de cada etapa são distribuídas uniformemente dentro do intervalo escolhido."));
        page.addView(info);
        setContentView(scroll);
    }

    private void pickNewFirstTime() {
        int earliest = earliestMinute(currentPlans);
        if (earliest < 0) {
            Toast.makeText(this, "Não há horários para ajustar.", Toast.LENGTH_LONG).show();
            return;
        }
        new TimePickerDialog(this, (view, h, m) -> {
            int newFirst = h * 60 + m;
            int delta = newFirst - earliest;
            ArrayList<MedicationPlan> adjusted = copyPlans(currentPlans);
            boolean crossed = shiftAll(adjusted, delta);
            showPreview(adjusted,
                    "Deslocar todos os horários em " + signedMinutes(delta) + "?",
                    crossed ? "Atenção: algum horário atravessa a meia-noite. Confira a prévia antes de confirmar." : "");
        }, earliest / 60, earliest % 60, true).show();
    }

    private void pickStartTime() {
        int earliest = earliestMinute(currentPlans);
        if (earliest < 0) earliest = 8 * 60;
        final int suggested = earliest;
        new TimePickerDialog(this, (view, h, m) -> {
            int start = h * 60 + m;
            pickEndTime(start);
        }, suggested / 60, suggested % 60, true).show();
    }

    private void pickEndTime(int start) {
        int latest = latestMinute(currentPlans);
        if (latest <= start) latest = Math.min(23 * 60, start + 12 * 60);
        final int suggested = latest;
        new TimePickerDialog(this, (view, h, m) -> {
            int end = h * 60 + m;
            if (end <= start) {
                Toast.makeText(this, "O horário final deve ser depois do horário inicial no mesmo dia.", Toast.LENGTH_LONG).show();
                return;
            }
            ArrayList<MedicationPlan> adjusted = copyPlans(currentPlans);
            redistribute(adjusted, start, end);
            showPreview(adjusted,
                    "Usar o intervalo " + formatMinute(start) + "–" + formatMinute(end) + "?", "");
        }, suggested / 60, suggested % 60, true).show();
    }

    private void showPreview(ArrayList<MedicationPlan> adjusted, String title, String warning) {
        StringBuilder text = new StringBuilder();
        if (warning != null && !warning.isEmpty()) text.append(warning).append("\n\n");
        for (MedicationPlan plan : adjusted) {
            text.append(plan.medicine).append("\n");
            for (int i = 0; i < plan.phases.size(); i++) {
                TreatmentPhase phase = plan.phases.get(i);
                text.append(plan.phases.size() > 1 ? "Etapa " + (i + 1) + ": " : "");
                text.append(String.join(", ", phase.times)).append("\n");
            }
            text.append("\n");
        }
        new AlertDialog.Builder(this).setTitle(title).setMessage(text.toString().trim())
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Confirmar", (d, w) -> apply(adjusted)).show();
    }

    private void apply(List<MedicationPlan> adjusted) {
        for (MedicationPlan old : PlanStore.getPlans(this)) AlarmScheduler.cancelPlan(this, old);
        for (MedicationPlan plan : adjusted) PlanStore.savePlan(this, plan);
        AlarmScheduler.scheduleAll(this);
        FirebasePatientSync.uploadCurrentPlans(this);
        Toast.makeText(this, "Horários ajustados e enviados ao acompanhamento do médico.", Toast.LENGTH_LONG).show();
        render();
    }

    private ArrayList<MedicationPlan> copyPlans(List<MedicationPlan> source) {
        ArrayList<MedicationPlan> result = new ArrayList<>();
        for (MedicationPlan p : source) {
            result.add(new MedicationPlan(p.id, p.medicine, p.eye, p.phases,
                    p.startDelayDays, p.startsAfterMedicine, p.anchorDateMillis));
        }
        return result;
    }

    private boolean shiftAll(List<MedicationPlan> plans, int delta) {
        boolean crossed = false;
        for (MedicationPlan plan : plans) {
            for (TreatmentPhase phase : plan.phases) {
                ArrayList<String> next = new ArrayList<>();
                for (String time : phase.times) {
                    int old = parseMinute(time);
                    if (old < 0) continue;
                    int raw = old + delta;
                    if (raw < 0 || raw >= 1440) crossed = true;
                    int normalized = ((raw % 1440) + 1440) % 1440;
                    String value = formatMinute(normalized);
                    if (!next.contains(value)) next.add(value);
                }
                Collections.sort(next);
                phase.times.clear();
                phase.times.addAll(next);
            }
            plan.syncLegacyTimes();
        }
        return crossed;
    }

    private void redistribute(List<MedicationPlan> plans, int start, int end) {
        for (MedicationPlan plan : plans) {
            for (TreatmentPhase phase : plan.phases) {
                int count = phase.times.size();
                if (count <= 0) continue;
                ArrayList<String> next = new ArrayList<>();
                if (count == 1) {
                    next.add(formatMinute(start));
                } else {
                    double step = (end - start) / (double) (count - 1);
                    for (int i = 0; i < count; i++) {
                        int minute = (int) Math.round(start + step * i);
                        String value = formatMinute(minute);
                        if (!next.contains(value)) next.add(value);
                    }
                }
                phase.times.clear();
                phase.times.addAll(next);
            }
            plan.syncLegacyTimes();
        }
    }

    private int earliestMinute(List<MedicationPlan> plans) {
        int best = Integer.MAX_VALUE;
        for (MedicationPlan plan : plans) for (TreatmentPhase phase : plan.phases)
            for (String time : phase.times) {
                int v = parseMinute(time);
                if (v >= 0 && v < best) best = v;
            }
        return best == Integer.MAX_VALUE ? -1 : best;
    }

    private int latestMinute(List<MedicationPlan> plans) {
        int best = -1;
        for (MedicationPlan plan : plans) for (TreatmentPhase phase : plan.phases)
            for (String time : phase.times) best = Math.max(best, parseMinute(time));
        return best;
    }

    private String currentRange(List<MedicationPlan> plans) {
        int first = earliestMinute(plans), last = latestMinute(plans);
        if (first < 0 || last < 0) return "Nenhum horário cadastrado.";
        return "Primeiro horário: " + formatMinute(first) + "\nÚltimo horário: " + formatMinute(last);
    }

    private int parseMinute(String time) {
        try {
            String[] p = time.split(":");
            if (p.length != 2) return -1;
            int h = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
            if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
            return h * 60 + m;
        } catch (Exception e) { return -1; }
    }

    private String formatMinute(int minute) {
        int v = Math.max(0, Math.min(1439, minute));
        return String.format(Locale.getDefault(), "%02d:%02d", v / 60, v % 60);
    }

    private String signedMinutes(int delta) {
        int abs = Math.abs(delta);
        int h = abs / 60, m = abs % 60;
        String amount = h > 0 ? h + "h" + (m > 0 ? " " + m + "min" : "") : m + "min";
        return (delta >= 0 ? "+" : "-") + amount;
    }
}
