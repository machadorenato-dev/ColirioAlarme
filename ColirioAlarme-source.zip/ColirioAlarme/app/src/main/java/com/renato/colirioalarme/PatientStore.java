package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PatientStore {
    private static final String PREFS = "colirio_doctor_patients_v5";
    private static final String KEY = "patients";

    private PatientStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<Patient> getAll(Context context) {
        ArrayList<Patient> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(context).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                String id = obj.optString("id", "");
                String name = obj.optString("name", "").trim();
                if (name.isEmpty()) continue;
                ArrayList<PatientAssignment> assignments = new ArrayList<>();
                JSONArray a = obj.optJSONArray("assignments");
                if (a != null) {
                    for (int j = 0; j < a.length(); j++) {
                        JSONObject as = a.optJSONObject(j);
                        if (as == null) continue;
                        ArrayList<ProtocolMedication> meds = new ArrayList<>();
                        JSONArray m = as.optJSONArray("medications");
                        if (m != null) {
                            for (int k = 0; k < m.length(); k++) {
                                JSONObject mo = m.optJSONObject(k);
                                if (mo == null) continue;
                                String medicine = mo.optString("medicine", "").trim();
                                if (medicine.isEmpty()) continue;
                                ArrayList<TreatmentPhase> phases = PlanStore.readPhases(mo);
                                if (phases.isEmpty()) phases.add(new TreatmentPhase(0,
                                        PlanStore.readTimes(mo.optJSONArray("times"))));
                                meds.add(new ProtocolMedication(medicine, phases,
                                        Math.max(0, mo.optInt("startDelayDays", 0)),
                                        mo.optString("startsAfterMedicine", "")));
                            }
                        }
                        assignments.add(new PatientAssignment(
                                as.optString("id", ""),
                                as.optString("protocolId", ""),
                                as.optString("protocolName", ""),
                                as.optString("eye", "Ambos os olhos"),
                                as.optLong("assignedAt", System.currentTimeMillis()),
                                meds,
                                as.optString("guidanceTitle", ""),
                                as.optString("guidanceText", "")));
                    }
                }
                result.add(new Patient(id, name, obj.optString("phone", ""), assignments));
            }
        } catch (Exception ignored) {}
        Collator collator = Collator.getInstance(new Locale("pt", "BR"));
        collator.setStrength(Collator.PRIMARY);
        result.sort((a, b) -> collator.compare(a.name, b.name));
        return result;
    }

    public static Patient getById(Context context, String id) {
        if (id == null) return null;
        for (Patient patient : getAll(context)) if (id.equals(patient.id)) return patient;
        return null;
    }

    public static void save(Context context, Patient patient) {
        List<Patient> all = getAll(context);
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(patient.id)) {
                all.set(i, patient);
                replaced = true;
                break;
            }
        }
        if (!replaced) all.add(patient);
        saveAll(context, all);
    }

    public static void delete(Context context, String id) {
        List<Patient> all = getAll(context);
        all.removeIf(p -> p.id.equals(id));
        saveAll(context, all);
    }

    private static void saveAll(Context context, List<Patient> all) {
        JSONArray arr = new JSONArray();
        try {
            for (Patient patient : all) {
                JSONObject obj = new JSONObject();
                obj.put("id", patient.id);
                obj.put("name", patient.name);
                obj.put("phone", patient.phone);
                JSONArray assignments = new JSONArray();
                for (PatientAssignment assignment : patient.assignments) {
                    JSONObject as = new JSONObject();
                    as.put("id", assignment.id);
                    as.put("protocolId", assignment.protocolId);
                    as.put("protocolName", assignment.protocolName);
                    as.put("eye", assignment.eye);
                    as.put("assignedAt", assignment.assignedAt);
                    as.put("guidanceTitle", assignment.guidanceTitle);
                    as.put("guidanceText", assignment.guidanceText);
                    JSONArray meds = new JSONArray();
                    for (ProtocolMedication med : assignment.medications) {
                        med.syncLegacyTimes();
                        JSONObject mo = new JSONObject();
                        mo.put("medicine", med.medicine);
                        mo.put("startDelayDays", med.startDelayDays);
                        mo.put("startsAfterMedicine", med.startsAfterMedicine == null ? "" : med.startsAfterMedicine);
                        mo.put("phases", PlanStore.phasesToJson(med.phases));
                        JSONArray times = new JSONArray();
                        for (String time : med.times) times.put(time);
                        mo.put("times", times);
                        meds.put(mo);
                    }
                    as.put("medications", meds);
                    assignments.put(as);
                }
                obj.put("assignments", assignments);
                arr.put(obj);
            }
        } catch (Exception ignored) {}
        prefs(context).edit().putString(KEY, arr.toString()).apply();
    }
}
