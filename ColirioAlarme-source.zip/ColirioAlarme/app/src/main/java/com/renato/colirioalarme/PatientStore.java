package com.renato.colirioalarme;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PatientStore {
    private static final String PREFS = "colirio_doctor_patients_v5";
    private static final String KEY = "patients";

    private PatientStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static List<Patient> getAll(Context context) {
        ArrayList<Patient> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(context).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                Patient patient = fromJson(obj);
                if (patient != null) result.add(patient);
            }
        } catch (Exception ignored) {}
        sort(result);
        return result;
    }

    public static Patient getById(Context context, String id) {
        if (id == null) return null;
        for (Patient patient : getAll(context)) if (id.equals(patient.id)) return patient;
        return null;
    }

    public static void save(Context context, Patient patient) {
        saveLocal(context, patient);
        FirebaseRepository.syncPatient(context, patient, null);
    }

    public static void saveLocal(Context context, Patient patient) {
        if (patient == null) return;
        List<Patient> all = getAll(context);
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(patient.id)) {
                all.set(i, patient);
                replaced = true;
                break;
            }
        }
        if (!replaced) all.add(patient);
        saveAllLocal(context, all);
    }

    public static void mergeFromCloud(Context context, List<Patient> cloud) {
        List<Patient> all = getAll(context);
        for (Patient incoming : cloud) {
            boolean found = false;
            for (int i = 0; i < all.size(); i++) {
                if (all.get(i).id.equals(incoming.id)) {
                    all.set(i, incoming);
                    found = true;
                    break;
                }
            }
            if (!found) all.add(incoming);
        }
        saveAllLocal(context, all);
    }

    public static void delete(Context context, String id) {
        List<Patient> all = getAll(context);
        all.removeIf(p -> p.id.equals(id));
        saveAllLocal(context, all);
        FirebaseRepository.deletePatient(context, id, null);
    }

    private static void saveAllLocal(Context context, List<Patient> all) {
        JSONArray arr = new JSONArray();
        for (Patient patient : all) {
            try { arr.put(toJson(patient)); } catch (Exception ignored) {}
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply();
    }

    public static JSONObject toJson(Patient patient) throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("id", patient.id);
        obj.put("name", patient.name);
        obj.put("phone", patient.phone);
        obj.put("linkToken", patient.linkToken == null ? "" : patient.linkToken);
        JSONArray assignments = new JSONArray();
        for (PatientAssignment assignment : patient.assignments) {
            JSONObject as = new JSONObject();
            as.put("id", assignment.id);
            as.put("protocolId", assignment.protocolId);
            as.put("protocolName", assignment.protocolName);
            as.put("eye", assignment.eye);
            as.put("assignedAt", assignment.assignedAt);
            as.put("guidanceTitle", assignment.guidanceTitle);
            as.put("guidanceText", assignment.guidanceText);
            JSONArray meds = new JSONArray();
            for (ProtocolMedication med : assignment.medications) {
                med.syncLegacyTimes();
                JSONObject mo = new JSONObject();
                mo.put("medicine", med.medicine);
                mo.put("startDelayDays", med.startDelayDays);
                mo.put("startsAfterMedicine", med.startsAfterMedicine == null ? "" : med.startsAfterMedicine);
                mo.put("phases", PlanStore.phasesToJson(med.phases));
                JSONArray times = new JSONArray();
                for (String time : med.times) times.put(time);
                mo.put("times", times);
                meds.put(mo);
            }
            as.put("medications", meds);
            assignments.put(as);
        }
        obj.put("assignments", assignments);
        return obj;
    }

    public static Patient fromJson(JSONObject obj) {
        try {
            if (obj == null) return null;
            String id = obj.optString("id", "");
            String name = obj.optString("name", "").trim();
            if (name.isEmpty()) return null;
            ArrayList<PatientAssignment> assignments = new ArrayList<>();
            JSONArray a = obj.optJSONArray("assignments");
            if (a != null) {
                for (int j = 0; j < a.length(); j++) {
                    JSONObject as = a.optJSONObject(j);
                    if (as == null) continue;
                    ArrayList<ProtocolMedication> meds = new ArrayList<>();
                    JSONArray m = as.optJSONArray("medications");
                    if (m != null) {
                        for (int k = 0; k < m.length(); k++) {
                            JSONObject mo = m.optJSONObject(k);
                            if (mo == null) continue;
                            String medicine = mo.optString("medicine", "").trim();
                            if (medicine.isEmpty()) continue;
                            ArrayList<TreatmentPhase> phases = PlanStore.readPhases(mo);
                            if (phases.isEmpty()) phases.add(new TreatmentPhase(0, PlanStore.readTimes(mo.optJSONArray("times"))));
                            meds.add(new ProtocolMedication(medicine, phases,
                                    Math.max(0, mo.optInt("startDelayDays", 0)), mo.optString("startsAfterMedicine", "")));
                        }
                    }
                    assignments.add(new PatientAssignment(
                            as.optString("id", ""), as.optString("protocolId", ""),
                            as.optString("protocolName", ""), as.optString("eye", "Ambos os olhos"),
                            as.optLong("assignedAt", System.currentTimeMillis()), meds,
                            as.optString("guidanceTitle", ""), as.optString("guidanceText", "")));
                }
            }
            return new Patient(id, name, obj.optString("phone", ""), obj.optString("linkToken", ""), assignments);
        } catch (Exception e) {
            return null;
        }
    }

    private static void sort(List<Patient> result) {
        Collator collator = Collator.getInstance(new Locale("pt", "BR"));
        collator.setStrength(Collator.PRIMARY);
        result.sort((a, b) -> collator.compare(a.name, b.name));
    }
}
