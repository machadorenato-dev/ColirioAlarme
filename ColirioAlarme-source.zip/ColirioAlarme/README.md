# Colírio Alarme

App Android simples para lembretes diários de colírios, com notificação e voz em português do Brasil.

## Recursos
- vários colírios e horários;
- mensagem falada personalizada ou automática;
- notificação de alta prioridade;
- reprogramação automática diária;
- restauração dos alarmes após reiniciar o celular;
- botão para solicitar permissão de alarmes exatos.

## Compilação
O GitHub Actions em `.github/workflows/build-apk.yml` compila `app-debug.apk` e publica o APK como artefato `ColirioAlarme-apk`.
